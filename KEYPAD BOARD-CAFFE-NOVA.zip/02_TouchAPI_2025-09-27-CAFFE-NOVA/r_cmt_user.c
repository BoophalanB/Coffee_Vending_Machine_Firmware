/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only intended for use with Renesas products.
* No other uses are authorized. This software is owned by Renesas Electronics Corporation and is protected under all
* applicable laws, including copyright laws. 
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIESREGARDING THIS SOFTWARE, WHETHER EXPRESS, IMPLIED
* OR STATUTORY, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
* NON-INFRINGEMENT.  ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY
* LAW, NEITHER RENESAS ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE FOR ANY DIRECT,
* INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR
* ITS AFFILIATES HAVE BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software and to discontinue the availability 
* of this software. By using this software, you agree to the additional terms and conditions found by accessing the 
* following link:
* http://www.renesas.com/disclaimer
*
* Copyright (C) 2015, 2017 Renesas Electronics Corporation. All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_cmt_user.c
* Version      : Code Generator for RX130 V1.01.00.04 [26 May 2017]
* Device(s)    : R5F51303AxFL
* Tool-Chain   : CCRX
* Description  : This file implements device driver for CMT module.
* Creation Date: 05-09-2017
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cmt.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
/* End user code. Do not edit comment generated here */
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
extern void uart1_data_send_fn();
extern void uart_send();
extern void error_update_display(unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char);
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: r_cmt_cmi1_interrupt
* Description  : None
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
#if FAST_INTERRUPT_VECTOR == VECT_CMT1_CMI1
#pragma interrupt r_cmt_cmi1_interrupt(vect=VECT(CMT1,CMI1),fint)
#else
#pragma interrupt r_cmt_cmi1_interrupt(vect=VECT(CMT1,CMI1))
#endif
static void r_cmt_cmi1_interrupt(void)
{
    /* Start user code. Do not edit comment generated here */
    //1msec isr
    
	if(++fifty_ms_count>50)//1000)
	{
	      fifty_ms_count=0; 
	      
	      if(send_delay>0)
		send_delay--;
	      if(dis_delay>0)
	        dis_delay--;	      
	      if(led_delay>0)
		led_delay--;
	      if(wait_delay>0)
                 wait_delay--;
	      if(delay_flag)
		delay_debouncing_time++;
	      if(touch_uart_error_clear_count>0)
	      {
		      touch_uart_error_clear_count--;
		      if(touch_uart_error_clear_count<=0)
		      {	
			R_SCI12_Serial_Receive(temp1_touch_rx_buffer,9);
		      }
	      }

	      if(++half_sec_timer>10)
	      {
	      	    half_sec_timer=0;
	  	    if(half_sec_delay_1>0)
	   	    half_sec_delay_1--;
	      }
	      if((!re_err_flag)&&(!ht_err_flag))
	      {
		     if(++one_min_timer>2400)//1200//4800
		     {
			   one_min_timer=0;
			   if(heart_beat_flag)
			   {
				heart_beat_flag=0;   
			   }
			   else
			   {
				 home_sc_flag=0;
				 led_flag=0;
				 led_blink_flag=0;
				 led =1; 
				 comm_err_flag=1;
			   }
		     } 
	      }
	     if((increment_decrement_flag)||(disp_id1 == SETTINGG)||(menuu))
	     {
		     if(!f_key_data)
		     {
			   if(++two_min_timer>2400)//2400
		           {
			         two_min_timer=0;
			         if((disp_id1 == BREW)||(disp_id1 == SETTINGG)||(disp_id1 == BREW_SETT)||(disp_id1 == DRINK_SETT)||(disp_id1 == OT_SETT)||(disp_id2 == PASSWORD)||(disp_id1 == TEA_SETT)||(disp_id1 == COFF_SETT)||(disp_id1 == MILK_SETT)||(disp_id1 == HW_SETT)||(menuu))
				 {
					 disp_id1 = disp_id2 = disp_id3 = pre_disp_id = 0;
					 value_browser_point = 00;
					 val_flag=0;
			                 menuu  = brew = sett=0;
			                 long_press_flag=short_press_flag=increment_decrement_flag=password_flag=0;
			                 next_dis_id=pre_disp_id=0;
			                 error_update_display(0,0,0,0,1,1,1,1);//CLEAR 
			                 home_sc_flag=1; 
				 }
	         	   }
		     }
		     else
		     two_min_timer =0;
	     }
	     else
	     two_min_timer =0;
	}
    /* End user code. Do not edit comment generated here */
}

/* Start user code for adding. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */
