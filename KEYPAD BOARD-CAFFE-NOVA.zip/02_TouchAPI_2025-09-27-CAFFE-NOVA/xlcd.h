extern const unsigned char err_mesg[][20];
extern const unsigned char lcd_code[][20];
extern const unsigned int menu_pattern[];
extern const unsigned char nxt_id_pattern[][1];