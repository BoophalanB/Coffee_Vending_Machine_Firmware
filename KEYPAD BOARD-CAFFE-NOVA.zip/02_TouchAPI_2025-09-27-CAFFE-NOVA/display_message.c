#include "r_cg_macrodriver.h"
#include "XVARIABLES.H"
#include "MACROS.H"
#include "lcd.h"

extern void lcd_write(unsigned char , unsigned char);
extern void delay(unsigned char dly);
extern void delay1(unsigned char);
void display_message1(unsigned char count, unsigned char data1);
void display_data(unsigned char lcd_addr, unsigned char data1);

void display_message1(unsigned char count, unsigned char data1)
{
	if(data1 == '~')
	data1=223;		//ascii for degeree symble 
	if(count == 0)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_1);	//Select address for first line
		delay1(0xFF);
	}
	if(count == 20)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_2);	//Select address for first line
		delay1(0xFF);
	}
	if(count == 40)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_3);	//Select address for first line
		delay1(0xFF);
	}
	if(count == 60)	
	{
		lcd_write(INST,CURSOR_OFF);	//DISP_CURS_ON;
		delay1(0xFF);
		lcd_write(INST,DDRAM_ADDR_4);	//Select address for first line
		delay1(0xFF);
	}
	lcd_write(RAM,data1);			//Write the data in DDRAM
	delay1(0xFF);
}




void display_data(unsigned char lcd_addr, unsigned char data1)
{
		lcd_write(INST,CURSOR_OFF);
		delay1(0xFF);	
		lcd_write(INST,(lcd_addr|0x80));
		//lcd_write(INST,lcd_addr);
		delay1(0xFF);
		lcd_write(RAM,data1);
		delay1(0xFF);
}
void update_cursor(unsigned char lcd_addr)
{
	 // To update the cursor 
	lcd_write(INST,DISP_CURS_ON);    // To switch on the cursor
	delay1(0xff);
	lcd_write(INST,lcd_addr|0x80);    // Select address for first line
	delay1(0xff);                        
} 