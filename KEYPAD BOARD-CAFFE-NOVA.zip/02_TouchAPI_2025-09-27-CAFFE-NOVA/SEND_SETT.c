#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "string.h"
#include "stdio.h"

void send_sett();
void sett_conv(unsigned char ssid, unsigned int value);

extern unsigned char check_sum(unsigned char tx_length);
extern unsigned char add_stuff_byte(unsigned char tx_length);

void send_sett()
{
    unsigned char chk_sum = 0;
    unsigned int  tx_length=0;


    tx_buff =0;
    memset(gui_tx_buff, 0,sizeof(gui_tx_buff));
    gui_tx_buff[tx_buff++] = 0x2A;       //START
    gui_tx_buff[tx_buff++] = 0x80;       //HEADER
    gui_tx_buff[tx_buff++] = 0;          //RESERVED
    gui_tx_buff[tx_buff++] = 0;//LENGTH
    gui_tx_buff[tx_buff++] = 0x06;       //APP ID
    gui_tx_buff[tx_buff++] = 0x01;       //FUN ID
     
    if(coff_sett_flag)
    {
	    sett_conv(1,setting[SC_DEC_ON_TIME]);
	    sett_conv(2,setting[SC_MK_ON_TIME]);
	    sett_conv(3,setting[LC_DEC_ON_TIME]);
	    sett_conv(4,setting[LC_MK_ON_TIME]);
	    sett_conv(5,setting[BC_DEC_ON_TIME]);
	    sett_conv(6,setting[BC_WAT_ON_TIME]);
	    sett_conv(7,setting[COFFEE_DEC_REV]);
	    coff_sett_flag=0;
    }
    else if(tea_sett_flag)
    {
	    sett_conv(8,setting[LT_DEC_ON_TIME]);
	    sett_conv(9,setting[LT_MK_ON_TIME]);
	    sett_conv(10,setting[BT_DEC_ON_TIME]);
	    sett_conv(11,setting[BT_WAT_ON_TIME]);
	    sett_conv(12,setting[TEA_DEC_REV]);
	    tea_sett_flag=0;
    }
    else if(mk_sett_flag)
    {
	    sett_conv(13,setting[MK_ON_TIME]);
	    sett_conv(14,setting[MK_EX_TIME]);
	    sett_conv(15,setting[MK_REV_TIME]);
	    mk_sett_flag=0;
    }
    else if(hw_sett_flag)
    {
            sett_conv(16,setting[HW_ON_TIME]);
	    hw_sett_flag=0;
    }
    else if(brew_sett_flag)
    {
	  sett_conv(17,setting[TEA_DEC_LTR]);
	  sett_conv(18,setting[TEA_DEC_1LTR_TM]);
	  sett_conv(19,setting[TEA_DEC_3LTR_TM]);
	  sett_conv(20,setting[COFFEE_DEC_LTR]);
	  sett_conv(21,setting[COFF_DEC_1LTR_TM]);
	  sett_conv(22,setting[COFF_DEC_3LTR_TM]);
	  brew_sett_flag=0;  
    }
    else if(ot_sett_flag)
    {
	    sett_conv(23,setting[HTR_ERR_TM]);
	    sett_conv(24,setting[BLR_DRN_TM]);
	    ot_sett_flag=0;
    }
    tx_length = tx_buff;
    gui_tx_buff[3] = tx_length-6;
    chk_sum = (unsigned char)check_sum(tx_length);
    gui_tx_buff[tx_length++] = chk_sum;
    memcpy(temp_tx_buff,gui_tx_buff,sizeof(gui_tx_buff));
    txx_buff=add_stuff_byte(tx_length);
    gui_tx_buff[txx_buff++] = 0x23;
    R_SCI12_Serial_Send(gui_tx_buff,(txx_buff));
}

void sett_conv(unsigned char ssid, unsigned int value)
{
   unsigned  char temp[20];
   unsigned int len;

    len = sprintf((char *)temp, "%u:%u|", ssid, value);

    for (int i = 0; i < len; i++)
        gui_tx_buff[tx_buff++] = temp[i];
}




