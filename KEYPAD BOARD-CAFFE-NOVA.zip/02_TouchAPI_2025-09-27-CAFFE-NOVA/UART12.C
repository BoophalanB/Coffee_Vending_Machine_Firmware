#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "string.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"
#include "stdio.h"
#include <stdlib.h>

void uart_rx();
void uart_prcs();
void uart_receive_process();
void check_app_fun_id();
void gui_msg_send_fun(int a_val, char app_id, char fun_id);
unsigned char check_sum(unsigned char tx_length);
unsigned char add_stuff_byte(unsigned char tx_length);
void uart_send();
void string_convert();
void settings();


extern void error_update_display(unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char);
extern void led_sequence_on();
extern void home_screen();


MD_STATUS R_SCI12_Serial_Send(uint8_t * const tx_buf, uint16_t tx_num);
MD_STATUS R_SCI12_Serial_Receive(uint8_t * const rx_buf, uint16_t rx_num);

char *datas[]={
                       "HANDSHAKE",        //0                      0
		       "ACK",              //1                      1
		       "C01",              //STRONG coffee          2
		       "C02",              //LIGHT coffee           3
		       "C03",              //TEA                    4 
		       "C04",              //BLACK TEA              5
		       "C05",              //BLACK COFFEE           6
		       "C06",              //MILK                   7
		       "C07",              //HOT WATER              8
		       "C08",              //STEAM                  9
		       "C10",              //TEA BREW               10
		       "C20",              //COFFE BREW             11
		       "C30",              //TEA COFFEE BREW        12
		       "C501",             //TEA CLEAN              13
		       "C502",             //COFF CLEAN             14
		       "C503",             //MILK CLEAN             15
		       "C504",             //BOILER DRAIN           16
		       "RESET_C01",        //DAILY COUNT RESET      17
		       "RESET_C02",        //TOTAL COUNT RESET      18
		       "RESET_C03",        //BREW COUNT RESET       19
		       "KEYPAD_BOARD_VERSION_1.0", //VERSION        20
		       "READ",              //INIT SETT             21
		       "REQ"  ,             //REQ                   22
		       "REFILL",            //REFILL                23
		       "HEATING",           //HEATING               24
		       "STOP",              //STOP                  25
            }; 
char *datum_data;


void uart_rx()
{
           uart_main_buf[rx_data]=SCI12.RDR;
           if(rx_data < 500)
           rx_data++;
           if(uart_main_buf[0]==START_BYTE)
           {
               if(uart_main_buf[rx_data-1]==END_BYTE)
               {
		   communication_err_timer=0;
                   buf_length=rx_data;
                   rx_data=0;
		   memcpy(processed_buffer, uart_main_buf, sizeof(uart_main_buf));                    
		   receive_complete_flag=SET;
                }
           }
           else
            rx_data=0;
}

void uart_prcs()
{
     if(receive_complete_flag)
     {
         uart_receive_process();
	 receive_complete_flag=chk_sum_flag=CLEAR;
     }
}
void uart_receive_process()
{
    unsigned char receive_check_sum;
    unsigned int i,j;
    
    rx_data=0;
    
    
    //remove stuff bytes
    
    for(i=0,j=0;i<buf_length;i++,j++)
    {
        if(uart_main_buf[i]==0X1C)
	{
            uart_backup_buf[j] = (~uart_main_buf[++i]);
	}
        else if(uart_main_buf[i]==0X23)
        {
            uart_backup_buf[j] = uart_main_buf[i];
            total_length=j+1;
        }
        else 
            uart_backup_buf[j] = uart_main_buf[i];
    }
    no_of_bytes=uart_main_buf[2]<<8; //left swift
    no_of_bytes=no_of_bytes|uart_main_buf[3];
    memset(uart_main_buf, 0, sizeof(uart_main_buf));
    if(no_of_bytes>800)
        receive_err_flag=1;
    
	 //checksum
	
     if(!receive_err_flag)
    {
        for(i=2,j=0,receive_check_sum=0; i<total_length-2; i++,j++)
            receive_check_sum += (j ^ uart_backup_buf[i]);
        receive_check_sum += uart_backup_buf[1];
        receive_check_sum = ~receive_check_sum;
        if(receive_check_sum == uart_backup_buf[total_length-2])
        chk_sum_flag=0;
        else
            chk_sum_flag=1;
    }
    else
        memset(uart_backup_buf, 0, sizeof(uart_backup_buf));
    check_app_fun_id();
     
    //receive actual data


    if((!chk_sum_flag)&&(app_id_flag)&&(fun_id_flag)&&(!receive_err_flag))
    {
	    if(((app_id==0x01)&&(fun_id==0x05))||((app_id==0x07)&&(fun_id==0x01)))
	    {    
		 memset(string_data,0,sizeof(string_data));
		 for(i=6,j=0;i<total_length-2;i++,j++)
                 string_data[j] = uart_backup_buf[i];
                 string_convert();
		 set_received_flag =1;
	    }
	    else
	    {
	            for(i=6,j=0;i<total_length-2;i++,j++)
	                process_data_buf[j] = uart_backup_buf[i];
	    }
        
        memset(uart_backup_buf, 0, sizeof(uart_backup_buf));
        process_data_rcvd_success_flag=1;
    }
}

void check_app_fun_id()
{
  unsigned char i,j,app_fun_id[20][20]={
                                    {0x01,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0x08,0x09,0x0a},
                                    {0x02,0x01,0x02,0x03},
                                    {0x03,0x01,0x02},
                                    {0x04,0x01,0x02},
				    {0x05,0x01,0x02,0x03,0x04},
				    {0x06,0x01},
				    {0x07,0x01},
				    {0x08,0x01,0x02,0x03,0x04},
  };
  app_id = uart_backup_buf[4];
  fun_id = uart_backup_buf[5];
  if((app_id>0)&&(fun_id>0))
        {
          for(i=0;i<20;i++)
          {
              if(app_fun_id[i][0]==app_id)
              {
                  app_id_flag = 1;
                  for(j=0;j<20;j++)
                  {
                      if(app_fun_id[i][j]==fun_id)
                      {
                          fun_id_flag = 1;
                          break;
                      }
                      else
                          fun_id_flag = 0;
                  }
                  break;
              }
              else
                  app_id_flag = 0;
          }
        }
}

void receive_data_process_fun(unsigned char app_id, unsigned char fun_id)
{
	switch(app_id)
        {
            case 1://INITIALIZING PROCESS 

                switch(fun_id)
                {
			case 1://ACK FOR HANSHAKE

				if(strcmp((char *)process_data_buf ,"ACK") == 0)
				{
					handshake_send_flag=CLEAR;
					if(!dis_delay)
					{
						retry_flag = retry_count= 0;
						error_update_display(0,12,0,0,1,1,1,1);   //BOOTING
						dis_delay = 25;
					}
				}

			break;

			case 2: //M VERSION
				if(!dis_delay)
				{
					gui_msg_send_fun(1,0x01,0x02); //ACK
					ack_flag=1;
					error_update_display(14,0,24,0,1,1,1,1); //M VERSION
					dis_delay = 25;
					gui_msg_send_fun(20,0x01,0x03);//K VERSION
				}
			break;

			case 3: //ACK FOR K VERSION
				if(strcmp((char *)process_data_buf ,"ACK") == 0)
				{
					if(!dis_delay)
					{
						retry_flag =retry_count= 0;
						error_update_display(13,0,25,0,1,1,1,1); //K VERSION
						dis_delay = 20;
						gui_msg_send_fun(21,0x01,0x04);	//init sett
					}
				}
			break;

			case 4://DONE FOR INIT SETT
					if(!dis_delay)
					{
						retry_flag = retry_count=0;
						error_update_display(0,20,21,0,1,1,1,1);//initializing
						//dis_delay =5;
						gui_msg_send_fun(22,0x01,0x05);	//REQ
					}
			break;

			case 5:// AFTER SETT VALUE REC
					if(!dis_delay)
					{
						if(set_received_flag)
						{
							retry_flag = retry_count=0;
							gui_msg_send_fun(23,0x01,0x07);	//REfill
							error_update_display(0,20,15,0,1,1,1,1); //REFILLING 
							ALL_KEY_LED_OFF;
							led=1;
							led_flag=1;
							led_sequence_on();
							dis_delay =10;
						}
					}
			break;

			case 6: //IF DEFAULT VALUES LOADING....
				{
					gui_msg_send_fun(1,0x01,0x06);	//ACK
					ack_flag=1;
					error_update_display(20,22,23,0,1,1,1,1);//default values
					//dis_delay =5;
					
				}

			break;

			case 7://HEATING
				if(!dis_delay)
				{
					retry_flag = retry_count=0;
					gui_msg_send_fun(24,0x01,0x08);//HEATING
					error_update_display(0,20,17,0,1,1,1,1);//HEATING
					ALL_KEY_LED_OFF;
					led_flag =1;
					led=1;
					led_sequence_on();
					dis_delay =10;
					
					
				}
			break;

			case 8://HEATING DONE
                                retry_flag = retry_count=0;
				
			break;

			case 9://MACHINE READY
				if(!dis_delay)
				{
					retry_flag = retry_count=0;
					gui_msg_send_fun(1,0x01,0x09); //ACK
					ack_flag=1;
					home_sc_flag=1;
					led_flag=0;
					machine_ready_flag=1;
					     
				}
			break;

			case 10://HEART BEAT
				//gui_msg_send_fun(1,0x01,0x0a); //ACK
				ack_flag=1;
				heart_beat_flag=1;
				
			break;
		}
		break; 
		case 2://DRINK PROCESS
		
			switch(fun_id)
			{
				case 1://DISPENSE START
				       retry_flag = 0;
				       home_sc_flag=0;
				       dis_delay =0;
					if(process_data_buf[0] == 'C')
					{
					  if(process_data_buf[1] == '0')
					   {
					     if(process_data_buf[2] == '1')
					      {
						led=1;
						led_blink_flag=1;//FOR LED PURPOSE
					        error_update_display(0,5,26,0,1,1,1,1);//S COFFEE
					        process_id =1;
						drink_process_flag =1;
					      }
					      if(process_data_buf[2] == '2')
					      {
						led=2;     
						led_blink_flag=1;//FOR LED PURPOSE
					        error_update_display(0,3,26,0,1,1,1,1);//L COFFEE
					        process_id =2;
						drink_process_flag =1;
					      }
					      if(process_data_buf[2] == '3')
					      {
						led=3;
						led_blink_flag=1;//FOR LED PURPOSE      
					        error_update_display(0,4,26,0,1,1,1,1);//L TEA
					        process_id =3;
						drink_process_flag =1;
					      }
					      if(process_data_buf[2] == '4')
					      {
						led=4;      
						led_blink_flag=1;//FOR LED PURPOSE      
					        error_update_display(0,7,26,0,1,1,1,1);// B TEA
					        process_id =4;
						drink_process_flag =1;
					      }
					      if(process_data_buf[2] == '5')
					      {
						led=5;      
						led_blink_flag=1;//FOR LED PURPOSE
					        error_update_display(0,6,26,0,1,1,1,1);//B COFFEE
					        process_id =5;
						drink_process_flag =1;
					      }
					      if(process_data_buf[2] == '6')
					      {
						led=6;      
						led_blink_flag=1;//FOR LED PURPOSE
					        error_update_display(0,8,26,0,1,1,1,1);//MILK
					        process_id =6;
						drink_process_flag =1;
					      }
					      if(process_data_buf[2] == '7')
					      {
						led=7;      
						led_blink_flag=1;//FOR LED PURPOSE      
					        error_update_display(0,9,26,0,1,1,1,1);//HOT WATER
					        process_id =7;
						drink_process_flag =1;
					      }
					    }
					   
				
					}
				break;
				case 2://STOP DISPENSE
				      if(strcmp((char *)process_data_buf ,"ACK") == 0)
				      {      
					      if(!dis_delay)
					      {
						retry_flag = retry_count=0;
						led=0;      
					        led_blink_flag=0;//FOR LED PURPOSE
					      	error_update_display(0,26,27,0,1,1,1,1);//STOP
						dis_delay =10;
						home_sc_flag=1;
						process_id=0;
	   				        drink_process_flag=short_press_flag=0;
					      }
					     
				      }
				break;
				case 3://COMPLETED DISPENSE
				      if(!dis_delay)
				      {
					retry_flag = retry_count=0;
					led=0;      
					led_blink_flag=0;//FOR LED PURPOSE      
					gui_msg_send_fun(1,0x01,0x10); //ACK
					ack_flag=1;
				      	error_update_display(0,28,0,0,1,1,1,1);//THANK YOU
					home_sc_flag=1;
					dis_delay =15;
				        drink_process_flag=short_press_flag=0;
				        process_id=0;
					
				      }
				break;
			}	
		break;
		case 3:  //BREW PROCESS
		
			switch(fun_id)
			{
				case 1:
				      retry_flag = retry_count=0;
				      if(!dis_delay)
				      {
				      	error_update_display(0,29,0,0,1,1,1,1);//TEA BREW
					home_sc_flag=1;
					dis_delay =15;
					
				      }
				break;
				case 2:
				        retry_flag = retry_count=0;
					if(!dis_delay)
					      {
					      	error_update_display(0,30,0,0,1,1,1,1);//COFF BREW
						home_sc_flag=1;
						dis_delay =15;
						
					      }
				break;
				case 3:
				        retry_flag = retry_count=0;
					if(!dis_delay)
					      {
					      	error_update_display(0,31,0,0,1,1,1,1);//TEA COFF BREW
						home_sc_flag=1;
						dis_delay =15;
						
						
					      }
				break;
				case 4:
					gui_msg_send_fun(1,0x01,0x10); //ACK
					ack_flag=1;
					
					
				break;
			}
		break;
		case 4:
			switch(fun_id)
			{
				case 1:
				      gui_msg_send_fun(1,0x01,0x10); //ACK
				      ack_flag=1;
				      home_sc_flag=0;
				      led_flag=led_blink_flag=0;
				      led=1;
				      re_err_flag=1;
				      error_update_display(0,37,36,0,1,1,1,1);//REFILLING ERROR	
				      
				      
				break;
				case 2:
				      gui_msg_send_fun(1,0x01,0x10); //ACK
				      ack_flag=1;
				      home_sc_flag=0;
				      led_flag=led_blink_flag=0;
				      led=1;
				      ht_err_flag=1;
				      error_update_display(0,38,36,0,1,1,1,1);//HEATING ERROR
				      
				     
				break;	
			}
		break;
		case 5:
			switch(fun_id)
			{
				case 1://TEA CLEAN
					retry_flag = retry_count=0;
					if(strcmp((char *)process_data_buf ,"ACK") == 0)
					  tea_clean_flag=1;	
					else if(strcmp((char *)process_data_buf ,"STOP") == 0)
					  tea_clean_flag=0;	
				        home_sc_flag=1;
					
					
				break;
				case 2://COFF CLEAN
					retry_flag = retry_count=0;
					if(strcmp((char *)process_data_buf ,"ACK") == 0)
					  coff_clean_flag=1;
					else if(strcmp((char *)process_data_buf ,"STOP") == 0)
					  coff_clean_flag=0;	
					home_sc_flag=1;
					
					
				break;
				case 3://MILK CLEAN
					retry_flag = retry_count=0;
					if(strcmp((char *)process_data_buf ,"ACK") == 0)
					  milk_clean_flag=1;
					else if(strcmp((char *)process_data_buf ,"STOP") == 0)
					  milk_clean_flag=0;
					home_sc_flag=1;
					
					
				break;
				case 4://BOILER DRAIN
					retry_flag = retry_count=0;
					if(strcmp((char *)process_data_buf ,"ACK") == 0)
					  boiler_drain_flag=1;
					else if(strcmp((char *)process_data_buf ,"STOP") == 0)
					  boiler_drain_flag=0;
					else if(strcmp((char *)process_data_buf ,"STOP1") == 0)
					{
					  boiler_drain_flag=0;
					  machine_restart_flag=1;
					}
					home_sc_flag=1;
					
					
				break;
				
				
			}
		break;
		case 8:
		       switch(fun_id)
		       {
			       case 1:
			              retry_flag = retry_count=0;
				      if(!dis_delay)
				      {
				      	//error_update_display(0,51,0,0,1,1,1,1);//COUNT RESETING
					//dis_delay =15;
					disp_id1 = disp_id2 = disp_id3 = 0;
					key_block_flag=menuu=short_press_flag=0;
					home_sc_flag=1;
				      }
			       break;
			       case 2:
			              retry_flag = retry_count=0;
				      if(!dis_delay)
				      {
					sett=0;
				      	//error_update_display(0,51,0,0,1,1,1,1);//COUNT RESETING
					//dis_delay =15;
					disp_id1 = disp_id2 = disp_id3 = 0;
					key_block_flag=menuu=short_press_flag=0;
					home_sc_flag=1;
				      }
			       break;
			       case 3:
			              retry_flag = retry_count=0;
				      if(!dis_delay)
				      {
					sett=0;
				      	//error_update_display(0,51,0,0,1,1,1,1);//COUNT RESETING
					//dis_delay =15;
					disp_id1 = disp_id2 = disp_id3 = 0;
					key_block_flag=menuu=short_press_flag=0;
					home_sc_flag=1;
				      }
			       break;     
		       }
		break; 
	}
	memset(process_data_buf ,0,sizeof(process_data_buf));
	memset(processed_buffer,0, sizeof(processed_buffer));
	memset(check_uart_receiver_buffer, 0, sizeof(check_uart_receiver_buffer));     // clear all buffer
}


void gui_msg_send_fun(int a_val, char app_id, char fun_id)
{
	 unsigned char i,send_chech_sum=0;
         tx_buff=0;
            memset(gui_tx_buff,0,sizeof(gui_tx_buff));

            gui_tx_buff[tx_buff++]=START_BYTE;          //START BYTE
            gui_tx_buff[tx_buff++]=HEADER_BYTE;         //HEADER BYTE
	    buf_length=strlen(datas[a_val]);            
	    gui_tx_buff[tx_buff++] = 0;                 //RESERVED BYTE
	    gui_tx_buff[tx_buff++]=buf_length;          //LENGTH OF DATA
            gui_tx_buff[tx_buff++]=app_id;              //APP ID
            gui_tx_buff[tx_buff++]=fun_id;              //FUN ID
	    datum_data=datas[a_val]; 
	    {
	        for(i=0; i<strlen(datas[a_val]);i++)
	        {
	            gui_tx_buff[tx_buff++] = *datum_data++; //ACTUAL DATA
	        }
	    }
	    send_chech_sum = check_sum(tx_buff);
	    gui_tx_buff[tx_buff++]=send_chech_sum;      //CHECKSUM
	    memcpy(temp_tx_buff,gui_tx_buff,sizeof(gui_tx_buff));
	    txx_buff=add_stuff_byte(tx_buff);
	    gui_tx_buff[txx_buff++] = '#';               //END BYTE
	    transmit_no_of_bytes = txx_buff;		    
	   // memset(final_data_send_buff,0,sizeof(final_data_send_buff));
            memcpy(final_data_send_buff,gui_tx_buff,sizeof(gui_tx_buff));
            memcpy(tx_backup_buff,final_data_send_buff,sizeof(final_data_send_buff));
	    send_flag=SET;
	    retry_flag=0;
}

unsigned char check_sum(unsigned char tx_length)
{
    unsigned char i,j,send_check_sum;
    for(i=2,j=0,send_check_sum=0; i<tx_length; i++,j++)
       send_check_sum += (j ^ gui_tx_buff[i]);
       send_check_sum = ~(send_check_sum + gui_tx_buff[1]);
       return send_check_sum;
}

unsigned char add_stuff_byte(unsigned char tx_length)
{
    unsigned char i,j;
    for(i=1,j=1;j<tx_length;i++,j++)
    {
        if((temp_tx_buff[i]==0X1C)||(temp_tx_buff[i]==0X2A)||(temp_tx_buff[i]==0X23))
        {
            gui_tx_buff[j++] = 0X1C;
            gui_tx_buff[j] = ~temp_tx_buff[i];
            tx_length++;
        }
        else
            gui_tx_buff[j] = temp_tx_buff[i];
    }
    return j;
}

void uart_send()
{
	if(((send_flag)||(retry_flag))&&(send_delay<=0))
	{
		if(!retry_flag)
		{			
		    send_flag=0;
		    if(!ack_flag)
		    retry_flag = 1;
		    ack_flag=0;
 		    R_SCI12_Serial_Send(final_data_send_buff,(transmit_no_of_bytes));
		    send_delay=5; //mili sec
		}
		else
		{
		   R_SCI12_Serial_Send(tx_backup_buff,(transmit_no_of_bytes));
		   if(++retry_count>4)
		    {
		        retry_count = 0;
		        retry_flag = 0;
		    }
		    send_delay =5;
		}
	}
}


void string_convert()
{
    unsigned int i,j=0;
    for(i=0;i<strlen((char *)string_data);i++)
    {
        if(string_data[i]==':')
        {
            ssid = atoi((char *)string_value);
            memset(string_value,0,sizeof(string_value));
            j =0;
        }
        else if(string_data[i]=='|')
        {
            sett_value = atoi(string_value);
            memset(string_value,0,sizeof(string_value));
            j =0;
            settings();
        }
        else
        {
            string_value[j++]=string_data[i];
        }
    }
}


void settings()
{

  switch(ssid)
  {
      case 1:
          setting[SC_DEC_ON_TIME] = sett_value;
          break;
      case 2:
          setting[SC_MK_ON_TIME] = sett_value;
          break;
      case 3:
	  setting[LC_DEC_ON_TIME] = sett_value;
	  break; 
      case 4:
          setting[LC_MK_ON_TIME] = sett_value;
          break; 
      case 5:
          setting[BC_DEC_ON_TIME] = sett_value;
          break;
      case 6:
          setting[BC_WAT_ON_TIME] = sett_value;
          break;
      case 7:
          setting[COFFEE_DEC_REV] = sett_value;
          break;
      case 8:
          setting[LT_DEC_ON_TIME] = sett_value;
          break;
      case 9:
          setting[LT_MK_ON_TIME] = sett_value;
          break;
      case 10:
	  setting[BT_DEC_ON_TIME] = sett_value;
	  break; 
      case 11:
          setting[BT_WAT_ON_TIME] = sett_value;
          break; 
      case 12:
          setting[TEA_DEC_REV] = sett_value;
          break;
      case 13:
          setting[MK_ON_TIME] = sett_value;
          break;
      case 14:
          setting[MK_EX_TIME] = sett_value;
          break;
      case 15:
          setting[MK_REV_TIME] = sett_value;
          break;
      case 16:
          setting[HW_ON_TIME] = sett_value;
          break;
      case 17:
          setting[TEA_DEC_LTR] = sett_value;
          break;
      case 18:
          setting[TEA_DEC_1LTR_TM] = sett_value;
          break;
      case 19:
          setting[TEA_DEC_3LTR_TM] = sett_value;
          break;
      case 20:
          setting[COFFEE_DEC_LTR] = sett_value;
          break;
      case 21:
          setting[COFF_DEC_1LTR_TM] = sett_value;
          break;
      case 22:
          setting[COFF_DEC_3LTR_TM] = sett_value;
          break;
      case 23:
          setting[HTR_ERR_TM] = sett_value;
          break;
      case 24:
          setting[BLR_DRN_TM] = sett_value;
          break;
      case 25:
          setting[ST_COFF_COUNT] = sett_value;
          break;
      case 26:
          setting[LT_COFF_COUNT] = sett_value;
          break;
      case 27:
          setting[LT_TEA_COUNT] = sett_value;
          break;
      case 28:
          setting[BK_TEA_COUNT] = sett_value;
          break;
      case 29:
          setting[BK_COFF_COUNT] = sett_value;
          break;
      case 30:
          setting[MILK_COUNT] = sett_value;
          break;
      case 31:
          setting[HW_COUNT] = sett_value;
          break;
      case 32:
          setting[ST_COFF_DLY_COUNT] = sett_value;
          break;
      case 33:
          setting[LT_COFF_DLY_COUNT] = sett_value;
          break;
      case 34:
          setting[LT_TEA_DLY_COUNT] = sett_value;
          break;
      case 35:
          setting[BK_TEA_DLY_COUNT] = sett_value;
          break;
      case 36:
          setting[BK_COFF_DLY_COUNT] = sett_value;
          break; 
      case 37:
          setting[MILK_DLY_COUNT] = sett_value;
          break;
      case 38:
          setting[HW_DLY_COUNT] = sett_value;
          break;
      case 39:
          setting[ALL_DRINK_CNT] = sett_value;
          break;
      case 40:
          setting[TEA_BREW_CNT] = sett_value;
	  break;
      case 41:
          setting[COFF_BREW_CNT] = sett_value;
	  break;
  }
}



