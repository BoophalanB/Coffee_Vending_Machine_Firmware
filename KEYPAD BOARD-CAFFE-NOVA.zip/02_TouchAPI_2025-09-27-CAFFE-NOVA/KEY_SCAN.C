#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"


void key_scan();
extern void increment();
extern void decrement();

void key_scan()
{     
	overall_key = f_key_data;
	if(overall_key)                     
	{
		if(!delay_flag)
		{
			delay_flag =SET;
			delay_debouncing_time=0;
			temp_key_data = overall_key;	
		}
		else
	        {
	            if(delay_debouncing_time>=3)
		    {
			if((temp_key_data == 1)&&(increment_decrement_flag)&&(!password_flag))
			 {
			       delay_debouncing_time=0;
			       delay_flag=0;
			       increment();
			 } 
			 if((temp_key_data == 2)&&(increment_decrement_flag)&&(!password_flag))
			 {
			       delay_debouncing_time=0;
			       delay_flag=0;
			       decrement();
			 } 
			 
		    }  
	            if(delay_debouncing_time>=100)
	            {
	                if((temp_key_data == 8)||(temp_key_data == 10))
	                {
	                    long_press_flag = 1;
			    key_press_flag=SET;
	                    final_key = temp_key_data;
			    delay_debouncing_time=0;
			    delay_flag=0;
	                }
			else
		            {
		                delay_flag = 0;
		                delay_debouncing_time = 0;
		            }
	            }
	        }

	}
	else 
	{       
		if(delay_flag)
		{
			if(delay_debouncing_time>=5)
			{
				key_press_flag=SET;
				short_press_flag=1;
				final_key = temp_key_data;
				delay_debouncing_time=0;
				delay_flag=0;
			}
		}
		delay_debouncing_time=0;
		delay_flag=0;
		
	}
	
}


