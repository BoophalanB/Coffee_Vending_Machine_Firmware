/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_key_control.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_KEY_CONTROL_C__

/***********************************************************************************************************************
 Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes <System Includes> , �gProject Includes�h
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_setup.h"
#include "r_ctsu_key_control.h"
#include "r_ctsu_user_API.h"

#ifdef  KEY_USE
/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile extern uint16_t g_key_onoff[MAX_KEY_ID];

/***********************************************************************************************************************
* Function Name: KeyProcess
* Description  : Key decoding main function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void KeyProcess( void )
{
    uint8_t    loop_ts;
    uint16_t   sensor_val;

    for (loop_ts = 0; loop_ts < MAX_TS; loop_ts++)
    {
        if (KEY_FUNC_OK == KeyFunctionCheck(loop_ts))
        {
            sensor_val = CtsuGetSensorData(loop_ts);
            //ref_val = CtsuGetReferenceData(loop_ts);
            KeyDecode(sensor_val, loop_ts);
        }
    }
}

/***********************************************************************************************************************
* Function Name: KeyDecode
* Description  : Key decoding function
* Arguments    : key_val    key data value
*              : ts_num     TS port number
* Return Value : None
***********************************************************************************************************************/
void KeyDecode( uint16_t key_val, uint8_t ts_num )
{
    uint8_t    key_id;
    uint8_t    offset;
    uint16_t   sBit;

    CTSUMakeCthr(key_val);          /* Make ON/OFFdecision-value */

    if (KEY_LOW > ts_num)
    {
        key_id = 0;
        offset = ts_num;
    }
    else if (KEY_MID > ts_num)
    {
        key_id = 1;
        offset = (uint8_t)(ts_num - KEY_LOW);
    }
    else if (KEY_HIGH > ts_num)
    {
        key_id = 2;
        offset = (uint8_t)(ts_num - KEY_MID);
    }
    else
    {
        return;
    }

    sBit = (uint16_t)(0x0001 << offset);
    if (0x0000 == (used_key_func[key_id] & sBit))
    {
        return;
    }

    //CTSUMultiTouchCancel();                             /* Multi Touch Cancel            */
    CTSUOnOffJudgement(key_val, key_id, offset);          /* ON/OFF judgement              */
    CTSUDriftCorrection(key_val, key_id, offset);         /* Drift correction              */

    if ((KEY_NUM - 1) == g_data_tim)
    {
        g_data_tim = 0;
    }
    else
    {
        g_data_tim = (uint8_t)(g_data_tim + 1);
    }
}

/***********************************************************************************************************************
* Function Name: CTSUMakeCthr
* Description  : Touch determination parameter generation function
* Arguments    : key_val_sub    key data value
* Return Value : none
***********************************************************************************************************************/
void CTSUMakeCthr( uint16_t key_val_sub )
{
    uint16_t over_cnt;

    /* Make Dcount,Cthr */
    if (g_nref[g_data_tim] < key_val_sub)
    {
        /* Dcount = g_nref - g_ncount */
        g_dcount[g_data_tim] = (uint16_t)(key_val_sub - g_nref[g_data_tim]);
    }
    else
    {
        g_dcount[g_data_tim] = 0;
    }

    over_cnt = (65535 - g_nthr[g_data_tim]);

    if (over_cnt > g_nref[g_data_tim])
    {
        g_cthr[g_data_tim] = (uint16_t)(g_nref[g_data_tim] + g_nthr[g_data_tim]);
    }
    else
    {
        g_cthr[g_data_tim] = 65535;
    }
}

/***********************************************************************************************************************
* Function Name: CTSUMultiTouchCancel
* Description  : Two or more touch is canceled.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CTSUMultiTouchCancel( void )
{
    uint8_t    m_cancel_ch;
    uint8_t    ts;

    if (OFF == g_sensor_function.function.mtc)
    {
        return;
    }

    /* Clear Asum value */
    asum = 0;

    /*===== ASUM make =====*/
    for (m_cancel_ch = mtc_start_ch; m_cancel_ch < (mtc_end_ch + 1); m_cancel_ch++)
    {
        ts = g_index_sensor[m_cancel_ch];
        if (0xff != ts)
        {
            if (15 < g_dcount[ts])
            {
                asum += g_dcount[ts];
            }
        }
    }

    /*==== Cthr make =====*/
    for (m_cancel_ch = mtc_start_ch; m_cancel_ch < (mtc_end_ch + 1); m_cancel_ch++)
    {
        ts = g_index_sensor[m_cancel_ch];
        if (0xff != ts)
        {
            if (g_cthr[ts] > asum)
            {
                /* correction Cthr value */
                g_cthr[ts] -= (asum - g_dcount[ts]);
            }
            else
            {
                g_cthr[ts] = 0;
            }
        }
    }
}

/***********************************************************************************************************************
* Function Name: CTSUOnOffJudgement
* Description  : Function to determine touch or not
* Arguments    : key_val_sub    key data value
*              : id             key touch/non-touch data storage buffer ID
*              : offset         key number offset value
* Return Value : none
***********************************************************************************************************************/
void CTSUOnOffJudgement( uint16_t key_val_sub, uint8_t id, uint8_t offset )
{
    uint16_t    sBit;
    uint16_t    sOnOff;
    uint16_t    ntouch_val;

    if (g_cthr[g_data_tim] > g_nhys[g_data_tim])
    {
        ntouch_val = (uint16_t)(g_cthr[g_data_tim] - g_nhys[g_data_tim]);
    }
    else
    {
        ntouch_val = g_cthr[g_data_tim];
    }

    sBit = (uint16_t)( 0x0001 << offset );
    if (key_val_sub > g_cthr[g_data_tim] )       /* Measurement value > Threshold value = Touch ON */
    {
        g_virtual_touch_info[id] |= sBit;        /* Virtual touch ON */
    }
    else if (key_val_sub < ntouch_val )
    {
        g_virtual_touch_info[id] &= (~sBit);        /* Virtual touch OFF */
    }
    else
    {
        /* Do Nothing */
    }

    if (0 != (g_virtual_touch_info[id] & sBit))        /* Virtual touch ON check */
    {
        g_non_touch_cnt[g_data_tim] = 0;
        if (g_touch_cnt[g_data_tim] == (uint16_t)g_touch_cmp_val)        /* Real touch ON check */
        {
            g_real_touch_info[id] = (uint16_t)(g_real_touch_info[id] | sBit);        /* Real touch ON */
            sOnOff                = (uint16_t)(0x0001 << g_data_tim);
            g_key_onoff[id]       = (uint16_t)(g_key_onoff[id] | sOnOff);
            if (0 != g_msa)                       /* MSA check */
            {
                g_touch_cnt[g_data_tim]++;         /* Total touch ON counter up */
            }
        }
        else
        {
            g_touch_cnt[g_data_tim]++;            /* Total touch ON counter up */
        }
    }
    else        /* Virtual touch OFF */
    {
        g_touch_cnt[g_data_tim] = 0;
        if (g_non_touch_cnt[g_data_tim] == (uint16_t)g_non_touch_cmp_val)        /* Real touch OFF check */
        {
            sOnOff                = (uint16_t)(0x0001 << g_data_tim);
            g_real_touch_info[id] = (uint16_t)(g_real_touch_info[id] & (~sBit));        /* Real touch OFF */
            g_key_onoff[id]       = (uint16_t)(g_key_onoff[id] & (~sOnOff));
        }
        else
        {
            g_non_touch_cnt[g_data_tim]++;        /* Total touch OFF counter up */
        }
    }

    /* ===== The reset judgment processing at the time of continuation on ===== */
    if (0 != g_msa)
    {
        /* If reaching ( c_msa(DF_MSA_DATA) + AcdON threshold),
           it makes OnOff judgment result off and it revises a drift. */
        if (g_touch_cnt[g_data_tim] == (g_msa + (uint16_t)g_touch_cmp_val))
        {
            /* Real touch and Virtual touch OFF */
            g_real_touch_info[id]    &= (~sBit);
            g_virtual_touch_info[id] &= (~sBit);
            g_touch_cnt[g_data_tim]   = 0;

            /* Drift parameter clear */
            g_dc_cnt[g_data_tim] = 0;
            g_dc_ref[g_data_tim] = 0x00000000ul;
            /* Compulsion drift */
            g_nref[g_data_tim] = key_val_sub;
        }
    }

    /* ===== ONOFF final result ===== */
    if (0x0000ul != (g_real_touch_info[id] & sBit))
    {
        g_touch_result[id] |= sBit;
    }
    else
    {
        g_touch_result[id] &= (~sBit);
    }

    /* ===== Key ON/OFF update ===== */
    BDATA[id] = g_touch_result[id];
}

/***********************************************************************************************************************
* Function Name: CTSUDriftCorrection
* Description  : Drift correction function ( Reference value update )
* Arguments    : key_val_sub    key data value
*              : id             key touch/non-touch data storage buffer ID
*              : offset         key number offset value
* Return Value : DRIFT_OK(0)
*              : DRIFT_OFF(2)
***********************************************************************************************************************/
uint8_t CTSUDriftCorrection( uint16_t key_val_sub, uint8_t id, uint8_t offset )
{
    uint16_t    sBit;

    /* If the drift processing is a prohibition */
    if (OFF == g_sensor_function.function.drift)
    {
        /* There is no processing */
        return DRIFT_OFF;
    }

    sBit = (uint16_t)( 0x0001 << offset );
    /* In case of doing drift correction being and moreover On/Off judgment result 1=OFF */
    if ((0x0000ul == (g_virtual_touch_info[id] & sBit))
     && (0x0000ul != (g_drift_permission[id] & sBit))
     && (OFF == MultiCancelDriftCheck(g_data_tim)))
    {

        /* It is an addition for the drift correction average calculation */
        g_dc_ref[g_data_tim] = g_dc_ref[g_data_tim] + key_val_sub;
        /* Drift correction counter's being inclement */
        g_dc_cnt[g_data_tim] = (uint16_t)(g_dc_cnt[g_data_tim] + 1);

        /* If reaching the correction number of times */
        if (g_dc_cnt[g_data_tim] == g_dci )
        {
            if (g_dci == 0)
            {
                g_dci = 1;
            }
            g_nref[g_data_tim] = (uint16_t)(g_dc_ref[g_data_tim] / g_dci);

            /* To REF of the average */
            g_dc_ref[g_data_tim] = 0x0000000ul;
            /* Work clear */
            g_dc_cnt[g_data_tim] = 0;
        }
    }
    else
    {
        g_dc_ref[g_data_tim] = 0x00000000ul;
        g_dc_cnt[g_data_tim] = 0;
    }

    return DRIFT_OK;
}

/***********************************************************************************************************************
* Function Name: MultiCancelDriftCheck
* Description  : multicancel drift check
* Arguments    : multi_ch -
*              :   channel data
* Return Value : result - 
*              :   0=not, 1= on job
***********************************************************************************************************************/
uint8_t MultiCancelDriftCheck( uint8_t multi_ch )
{
    if (ON == g_sensor_function.function.mtc)
    {
        /* Multi cancelling CH and Asum> ATHR */
        if ((mtc_start_ch <= multi_ch) && (mtc_end_ch >= multi_ch))
        {
            if (asum > Athr)
            {
                return (ON);
            }
        }
    }
    return (OFF);
}

/***********************************************************************************************************************
* Function Name: KeyCalibrationProcess
* Description  : Key data calibration main function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void  KeyCalibrationProcess( void )
{
    uint8_t loop_ts;

    for (loop_ts = 0; loop_ts < MAX_TS; loop_ts++)
    {
        if (KEY_FUNC_OK == KeyFunctionCheck(loop_ts))
        {
            KeyCalibration(loop_ts);
        }
    }

    if (0 == g_ctsu_flag.bit.msr_calib)
    {
        g_calib_time = 0;
    }
    else
    {
        g_calib_time = (uint8_t)(g_calib_time + 1);
        g_calib_data_num = 0;
    }
}

/***********************************************************************************************************************
* Function Name: KeyCalibration
* Description  : Key data calibration function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void KeyCalibration( uint8_t ts_num )
{
    uint8_t    loop;
    uint8_t    loop_max;
    uint8_t    max_num;
    uint32_t   work_buff[6];

    if (CTSU_AT_INIT           == g_ctsu_at_mode             // If offset tuning is working, this process is pass.(temp)
     || CTSU_AT_INITIAL_OFFSET == g_ctsu_at_mode)
    {
        return;
    }

    if (CALIB_TIME != g_calib_time)
    {
        g_calib[g_calib_data_num][g_calib_time] = g_scount[g_index_sensor[ts_num]];
        g_calib_data_num = (uint8_t)(g_calib_data_num + 1);
        return;
    }

    for (loop = 0; loop < KEY_NUM; loop++)
    {
        work_buff[0] = (uint32_t)(g_calib[loop][0] + g_calib[loop][1]);    /* buff0 + buff1 */
        work_buff[1] = (uint32_t)(g_calib[loop][0] + g_calib[loop][2]);    /* buff0 + buff2 */
        work_buff[2] = (uint32_t)(g_calib[loop][0] + g_calib[loop][3]);    /* buff0 + buff3 */
        work_buff[3] = (uint32_t)(g_calib[loop][1] + g_calib[loop][2]);    /* buff1 + buff2 */
        work_buff[4] = (uint32_t)(g_calib[loop][1] + g_calib[loop][3]);    /* buff1 + buff3 */
        work_buff[5] = (uint32_t)(g_calib[loop][2] + g_calib[loop][3]);    /* buff2 + buff3 */

        for (loop_max = 0, max_num = 0; loop_max < 5; loop_max++)
        {
            if (work_buff[max_num] < work_buff[loop_max + 1])
            {
                max_num = (uint8_t)(loop_max + 1);
            }
        }
        g_nref[loop] = (uint16_t)(work_buff[max_num] / 2);
    }
    g_ctsu_flag.bit.msr_calib = 0;
}

/***********************************************************************************************************************
* Function Name: KeyFunctionCheck
* Description  : Key function check
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
uint8_t KeyFunctionCheck( uint8_t loop )
{
    uint8_t     key_id;
    uint8_t     offset;
    uint16_t    sBit;

    if (KEY_LOW > loop)
    {
        key_id = 0;
        offset = loop;
    }
    else if (KEY_MID > loop)
    {
        key_id = 1;
        offset = (uint8_t)(loop - KEY_LOW);
    }
    else if (KEY_HIGH > loop)
    {
        key_id = 2;
        offset = (uint8_t)(loop - KEY_MID);
    }
    else
    {
        return KEY_FUNC_NG;
    }

    sBit = (uint16_t)(0x0001 << offset);
    if (0x0000 == (used_key_func[key_id] & sBit))
    {
        return KEY_FUNC_NG;
    }

    return KEY_FUNC_OK;
}

#endif  // KEY_USE

