/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_slider_control.c
* Version      : 1.00
* Description  : Touch Sensor IC Renesas slider process
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_SLIDER_CONTROL_C__

/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_slider_control.h"
#include "r_ctsu_user_API.h"

#ifdef SLIDER_USE    //[
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files);
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: SliderProcess
* Description  : Slider main function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void SliderProcess( void )
{
    uint8_t    slider_id;
    uint8_t    loop_ts;
    uint16_t   sensor_val;

    for (slider_id = 0; slider_id < DF_SLIDER_NUMBER; slider_id++)
    {
        for (loop_ts = 0; loop_ts < g_sliderInfo[slider_id].num; loop_ts++)
        {
            sensor_val = CtsuGetSensorData(g_sliderInfo[slider_id].ts[loop_ts]);
            g_slider_data[loop_ts] = sensor_val;
        }
        g_slider_pos[slider_id] = SliderDecode(slider_id);
    }
}

/***********************************************************************************************************************
* Function Name: SliderDecode
* Description  : Slider decode function
* Arguments    : s_id           Slider ID( 0-7 )
* Return Value : slider_rpos    Slider touch position( 65535 = non-touch )
***********************************************************************************************************************/
uint16_t SliderDecode( uint8_t s_id )
{
    uint8_t     loop;
    uint8_t     max_num;
    uint8_t     maxch1[3];
    uint16_t    d1,d2,d3;
    uint16_t    slider_vpos;        /* Slider virtual position        */
    uint16_t    slider_rpos;
    uint16_t    slider_dsum;
    uint8_t     resol_num;
    uint16_t    resol_plus;
    uint16_t    resol_minus;

    /* Unstable Correction */
    for (loop = 0, max_num = 0; loop < (g_sliderInfo[s_id].num-1); loop++)
    {
        if (g_slider_data[max_num] < g_slider_data[loop+1])
        {
            max_num = loop + 1;
        }
    }

    /*The maximum ch number to change is put in the array. */
    maxch1[0] = max_num;

    /* Array making for slider operation-------------*/
    /*     |    Maximum change CH_No -----> Array"0"    */
    /*     |    Maximum change CH_No + 1 -> Array"2"    */
    /*     |    Maximum change CH_No - 1 -> Array"1"    */
    if (0u < g_slider_data[maxch1[0]])
    {
        if (0u == maxch1[0])
        {
            maxch1[1] = (uint8_t)(maxch1[0] + 2);
            maxch1[2] = (uint8_t)(maxch1[0] + 1);
        }
        else if (maxch1[0] == (g_sliderInfo[s_id].num - 1))
        {
            maxch1[1] = (uint8_t)(maxch1[0] - 1);
            maxch1[2] = (uint8_t)(maxch1[0] - 2);
        }
        else
        {
            maxch1[1] = (uint8_t)(maxch1[0] - 1);
            maxch1[2] = (uint8_t)(maxch1[0] + 1);
        }

        /* Constant decision for operation of angle of slider */
        /*    Three constant decisions for the operation      */
        /*    Operation of angle of slider                    */
        d1 = g_slider_data[maxch1[0]] - g_slider_data[maxch1[1]];
        d2 = g_slider_data[maxch1[0]] - g_slider_data[maxch1[2]];
        slider_dsum = (uint16_t)(d1 + d2);

        if (slider_dsum > g_sliderInfo[s_id].threshold)
        {
            d3          = 100 + ((d2 * 100) / d1);
            slider_vpos = ((10000 / d3) + (100 * maxch1[0]));

            resol_num   = (uint8_t)(g_sliderInfo[s_id].num - 1);
            resol_plus  = (uint16_t)(100 * resol_num);
            resol_minus = (uint16_t)(50 / g_sliderInfo[s_id].resolution);

            /* swa = 0 -> Max ------ swa output 1 to Max */
            slider_rpos = (uint16_t)(slider_vpos / g_sliderInfo[s_id].resolution);
            if (0 == slider_rpos)
            {
                slider_rpos = 1;
            }
            else if (slider_rpos >= (resol_plus / g_sliderInfo[s_id].resolution))
            {
                slider_rpos = (slider_rpos - (resol_plus / g_sliderInfo[s_id].resolution)) * 2;
                slider_rpos = slider_rpos + (resol_plus / g_sliderInfo[s_id].resolution);
                if (slider_rpos > ((100 / g_sliderInfo[s_id].resolution) * g_sliderInfo[s_id].num))
                {
                    slider_rpos = ((100 / g_sliderInfo[s_id].resolution) * g_sliderInfo[s_id].num);
                }
            }
            else if (slider_rpos <= (100 / g_sliderInfo[s_id].resolution))
            {
                if( slider_rpos < resol_minus )
                {
                   slider_rpos = 1;
                }
                else
                {
                    slider_rpos = slider_rpos - resol_minus;
                    if( slider_rpos == 0 )
                    {
                        slider_rpos = 1;
                    }
                    else
                    {
                        slider_rpos = slider_rpos * 2;
                    }
                }
            }
            else
            {
                /* Do Nothing */
            }
            g_sliderInfo[s_id].value = slider_rpos;
        }
        else
        {
            g_sliderInfo[s_id].value = 0xFFFFu;
            slider_rpos = 0xFFFFu;
        }
    }
    else
    {
        /* Touch Off Value */
        g_sliderInfo[s_id].value = 0xFFFFu;
        slider_rpos = 0xFFFFu;
    }
    return slider_rpos;
}

/***********************************************************************************************************************
* Function Name: SliderCalibrationProcess
* Description  : Slider calibration process
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void SliderCalibrationProcess( void )
{
#if 0
    uint8_t     slider_id;
    uint8_t     loop_ts;
    uint16_t    sensor_val;

    for (slider_id = 0; slider_id < DF_SLIDER_NUMBER; slider_id++)
    {
        for (loop_ts = 0; loop_ts < g_sliderInfo[slider_id].num; loop_ts++)
        {
            sensor_val = CtsuGetSensorData( g_sliderInfo[slider_id].ts[loop_ts]);
            g_slider_data[loop_ts] = sensor_val;
        }
        SliderNonTouchDeltaCorrection();
    }
#endif
}

/***********************************************************************************************************************
* Function Name: SliderNonTouchDeltaCorrection
* Description  : Value of correction of non-touch data of slider operation
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
#if 0
void SliderNonTouchDeltaCorrection( uint8_t s_id )
{

}
#endif

#endif //] SLIDER_USE

/***********************************************************************************************************************
    END OF TEXT
***********************************************************************************************************************/
