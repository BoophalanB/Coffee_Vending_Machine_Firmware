/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_wheel_control.c
* Version      : 1.00
* Description  : Touch Sensor IC Renesas wheel process
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

#define __R_CTSU_WHEEL_CONTROL_C__
/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_wheel_control.h"
#include "r_ctsu_user_API.h"

#ifdef WHEEL_USE    //[
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files);
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: WheelProcess
* Description  : Wheel main function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void WheelProcess( void )
{
    uint8_t    wheel_id;
    uint8_t    loop_ts;
    uint16_t   sensor_val;

    for (wheel_id = 0; wheel_id < DF_WHEEL_NUMBER; wheel_id++)
    {
        for (loop_ts = 0; loop_ts < g_wheelInfo[wheel_id].num; loop_ts++)
        {
            sensor_val = CtsuGetSensorData(g_wheelInfo[wheel_id].ts[loop_ts]);
            g_wheel_data[loop_ts] = sensor_val;
        }
        g_wheel_pos[wheel_id] = WheelDecode(wheel_id);
    }
}

/***********************************************************************************************************************
* Function Name: WheelDecode
* Description  : Wheel Decode function
* Arguments    : w_id          Wheel ID ( 0-7 )
* Return Value : wheel_rpos    Wheel touch position( 65535 = non-touch )
***********************************************************************************************************************/
uint16_t WheelDecode( uint8_t w_id )
{
    uint8_t     loop;
    uint8_t     max_num;
    uint8_t     maxch[3];
    uint16_t    d1,d2,d3;
    uint16_t    wheel_vpos;        /* Wheel virtual position    */
    uint16_t    wheel_rpos;
    uint16_t    wheel_dsum;

    /* Unstable Correction */
    for (loop = 0, max_num = 0; loop < (g_wheelInfo[w_id].num-1); loop++)
    {
        if (g_wheel_data[max_num] < g_wheel_data[loop+1])
        {
            max_num = loop + 1;
        }
    }

    /*The maximum ch number to change is put in the array. */
    maxch[0] = max_num;

    /* Array making for slider operation          */
    /*    Maximum change CH_No -----> Array"0"    */
    /*    Maximum change CH_No + 1 -> Array"2"    */
    /*    Maximum change CH_No - 1 -> Array"1"    */
    if (0u < g_wheel_data[maxch[0]])
    {
        if (0u == maxch[0])
        {
            maxch[1] = (uint8_t)(g_wheelInfo[w_id].num - 1);
            maxch[2] = (uint8_t)(maxch[0] + 1);
        }
        else if ( maxch[0] == ( g_wheelInfo[w_id].num - 1 ))
        {
            maxch[1] = (uint8_t)(maxch[0] - 1);
            maxch[2] = 0;
        }
        else
        {
            maxch[1] = (uint8_t)(maxch[0] - 1u);
            maxch[2] = (uint8_t)(maxch[0] + 1u);
        }

        /* Constant decision for operation of angle of wheel    */
        /*    Three constant decisions for the operation        */
        /*    Operation of angle of wheel                       */
        d1 = g_wheel_data[maxch[0]] - g_wheel_data[maxch[1]];
        d2 = g_wheel_data[maxch[0]] - g_wheel_data[maxch[2]];
        wheel_dsum = (uint16_t)(d1 + d2);

        if (wheel_dsum > g_wheelInfo[w_id].threshold)
        {
            d3 = 100 + ((d2 * 100) / d1);

            if( 4 == g_wheelInfo[w_id].num )
            {
                wheel_vpos = ((9000 / d3) + ( 90 * maxch[0] ));
            }
            else
            {
                wheel_vpos = ((4500 / d3) + ( 45 * maxch[0] ));
            }

            /* Angle division output */
            /* diff_angle_ch = 0 -> 359 ------ diff_angle_ch output 1 to 360 */
            if (0 == wheel_vpos)
            {
                wheel_vpos = 360;
            }
            else if (361 == wheel_vpos)
            {
                wheel_vpos = 1;
            }
            else if (361 < wheel_vpos)
            {
                wheel_vpos = (wheel_vpos-360) >> 1;
            }
            else
            {
                /* Do Nothing */
            }

            /* swa = 0 -> Max ------ swa output 1 to Max */
            wheel_rpos = (uint16_t)(wheel_vpos / g_wheelInfo[w_id].resolution);
            if (0 == wheel_rpos)
            {
                wheel_rpos = 1;
            }
            g_wheelInfo[w_id].value = wheel_rpos;
        }
        else
        {
            g_wheelInfo[w_id].value = 0xFFFFu;
            wheel_rpos = 0xFFFFu;
        }
    }
    else
    {
        /* Touch Off Value */
        g_wheelInfo[w_id].value = 0xFFFFu;
        wheel_rpos = 0xFFFFu;
    }
    return wheel_rpos;
}

/***********************************************************************************************************************
* Function Name: WheelCalibrationProcess
* Description  : Wheel calibration process
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void WheelCalibrationProcess( void )
{

}
#endif    //] WHEEL_USE

/***********************************************************************************************************************
    END OF TEXT
***********************************************************************************************************************/
