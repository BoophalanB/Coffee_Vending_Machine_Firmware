/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_self_tuning_control_mu.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_SELF_TUNING_CONTROL_C__

/***********************************************************************************************************************
 Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes <System Includes> , �gProject Includes�h
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_setup.h"
#include "r_ctsu_common_control.h"
#include "r_ctsu_key_control.h"
#include "r_ctsu_user_API.h"
#include "r_ctsu_self_tuning_control.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: CheckAutoTuning
* Description  : 
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CheckSelfTuning( void )
{
#ifdef KEY_USE
    uint8_t     wk_onoff = 0;
    uint8_t     column_tx;
    uint8_t     row_rx;

    for (row_rx = 0; row_rx < RECEIVE_NUM; row_rx++)
    {
        for (column_tx = 0; column_tx < SEND_NUM; column_tx++)
        {
            if (1 == BDATA[column_tx][row_rx])
            {
                wk_onoff++;
            }
        }
    }
    if (0 == wk_onoff)
    {                                           // << touch off
        CtsuSetAutoTuningOnOff(AT_START);       /* Auto Tuning start */
    }
    else
    {                                           // << touch on
        CtsuSetAutoTuningOnOff(AT_PAUSE);       /* Auto Tuning Pause */
    }
#endif
}

/******************************************************************************
End  Of File
******************************************************************************/

