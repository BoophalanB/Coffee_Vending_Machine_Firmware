/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_key_control_mu.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_KEY_CONTROL_C__

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_setup.h"
#include "r_ctsu_key_control.h"
#include "r_ctsu_user_API.h"

#ifdef KEY_USE
/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
volatile extern uint16_t g_key_onoff[SEND_NUM][RECEIVE_NUM];

/***********************************************************************************************************************
* Function Name: KeyProcess
* Description  : Key decoding main function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void KeyProcess( void )
{
    uint8_t     column_tx;
    uint8_t     row_rx;
    uint16_t    sensor_val;

    for (row_rx = 0; row_rx < RECEIVE_NUM; row_rx++)
    {
        for (column_tx = 0; column_tx < SEND_NUM; column_tx++)
        {
            sensor_val = CtsuGetSensorData(column_tx, row_rx);
            //ref_val = CtsuGetReferenceData(loop_ts);
            if (DATA_GET_ERROR != sensor_val)
            {
                KeyDecode(sensor_val, column_tx, row_rx);
            }
        }
    }
}

/***********************************************************************************************************************
* Function Name: KeyDecode
* Description  : Key decoding function
* Arguments    : key_value    key data value
*              : column       Horizontal (column) number
*              : row          Length (row) number
* Return Value : None
***********************************************************************************************************************/
void KeyDecode( uint16_t key_value, uint8_t column, uint8_t row )
{

    CTSUMakeCthr(key_value, column, row);               /* Make ON/OFFdecision-value    */

    //CTSUMultiTouchCancel();                               /* Multi Touch Cancel           */
    CTSUOnOffJudgement(key_value, column, row);         /* ON/OFF judgement             */
    CTSUDriftCorrection(key_value, column, row);        /* Drift correction             */

    if ((MEASURE_NUM -1) == g_data_tim)
    {
        g_data_tim = 0;
    }
    else
    {
        g_data_tim = (uint8_t)(g_data_tim + 1);
    }
}

/***********************************************************************************************************************
* Function Name: CTSUMakeCthr
* Description  : Touch determination parameter generation function
* Arguments    : key_val    key data value
*              : column     Horizontal (column) number
*              : row        Length (row) number
* Return Value : none
***********************************************************************************************************************/
void CTSUMakeCthr( uint16_t key_val, uint8_t column_sub, uint8_t row_sub )
{
    /* Make Dcount,Cthr */
    if (g_nref[column_sub][row_sub] > key_val)
    {
        /* Dcount = g_nref - g_ncount */
        g_dcount[column_sub][row_sub] = (uint16_t)(g_nref[column_sub][row_sub] - key_val);
    }
    else
    {
        g_dcount[column_sub][row_sub] = 0;
    }

    if (g_nref[column_sub][row_sub] > g_nthr[column_sub][row_sub])
    {
        g_cthr[column_sub][row_sub] = (uint16_t)(g_nref[column_sub][row_sub] - g_nthr[column_sub][row_sub]);
    }
    else
    {
        g_cthr[column_sub][row_sub] = 0;
    }
}

/***********************************************************************************************************************
* Function Name: CTSUMultiTouchCancel
* Description  : Two or more touch is canceled.
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CTSUMultiTouchCancel( void )
{
//    uint8_t    m_cancel_ch;
//    uint8_t    ts;

    if (OFF == g_sensor_function.function.mtc)
    {
        return;
    }

    /* Clear Asum value */
    asum = 0;

#if 0
    /*===== ASUM make =====*/
    for (m_cancel_ch = mtc_start_ch ; m_cancel_ch < mtc_end_ch +1; m_cancel_ch++)
    {
        ts = g_index_sensor[m_cancel_ch];
        if (ts != 0xff)
        {
            if (g_dcount[ts] > 15)
            {
                asum += g_dcount[ts];
            }
        }
    }

    /*==== Cthr make =====*/
    for (m_cancel_ch = mtc_start_ch ; m_cancel_ch < mtc_end_ch+1; m_cancel_ch++)
    {
        ts = g_index_sensor[m_cancel_ch];
        if (ts != 0xff)
        {
            if (g_cthr[ts] > asum)
            {
                 g_cthr[ts] -= (asum - g_dcount[ts]);
            }
            else
            {
                g_cthr[ts] = 0;
            }
        }
    }
#endif
}

/***********************************************************************************************************************
* Function Name: CTSUOnOffJudgement
* Description  : Function to determine touch or not
* Arguments    : key_val_sub    key data value
*              : column_sub     Horizontal (column) number
*              : row_sub        Length (row) number
* Return Value : none
***********************************************************************************************************************/
void CTSUOnOffJudgement( uint16_t key_val, uint8_t column_sub, uint8_t row_sub )
{
    uint32_t    ntouch_val;

    ntouch_val = (uint32_t)g_cthr[column_sub][row_sub] + (uint32_t)g_nhys[column_sub][row_sub];

    if (key_val < g_cthr[column_sub][row_sub])                  /* Measurement value > Threshold value = Touch ON    */
    {
        g_virtual_touch_info[column_sub][row_sub] = 1;                            /* Virtual touch ON                 */
    }
    else if ((uint32_t)(key_val) > ntouch_val)
    {
        g_virtual_touch_info[column_sub][row_sub] = 0;                            /* Virtual touch OFF                */
    }
    else
    {
        /* Do Nothing */
    }

    if (0 != g_virtual_touch_info[column_sub][row_sub])                         /* Virtual touch ON check            */
    {
        g_non_touch_cnt[column_sub][row_sub] = 0;
        if (g_touch_cnt[column_sub][row_sub] == (uint16_t)g_touch_cmp_val)      /* Real touch ON check               */
        {
            g_real_touch_info[column_sub][row_sub] = 1;                          /* Real touch ON                     */
            g_key_onoff[column_sub][row_sub]       = 1;
            if (0 != g_msa)                                                     /* MSA check                         */
            {
                g_touch_cnt[column_sub][row_sub]++;                              /* Total touch ON counter up         */
            }
        }
        else
        {
            g_touch_cnt[column_sub][row_sub]++;                                  /* Total touch ON counter up         */
        }
    }
    else                                                                         /* Virtual touch OFF                 */
    {
        g_touch_cnt[column_sub][row_sub] = 0;
        if (g_non_touch_cnt[column_sub][row_sub] == (uint16_t)g_non_touch_cmp_val)    /* Real touch OFF check        */
        {
            g_real_touch_info[column_sub][row_sub] = 0;                          /* Real touch OFF                    */
            g_key_onoff[column_sub][row_sub] = 0;
        }
        else
        {
            g_non_touch_cnt[column_sub][row_sub]++;                              /* Total touch OFF counter up        */
        }
    }

    /* ===== The reset judgment processing at the time of continuation on ===== */
    if (0 != g_msa)
    {
        /* If reaching (c_msa(DF_MSA_DATA) + AcdON threshold),
            it makes OnOff judgment result off and it revises a drift. */
        if (g_touch_cnt[column_sub][row_sub] == (g_msa + (uint16_t)g_touch_cmp_val))
        {
            /* Real touch and Virtual touch OFF */
            g_real_touch_info[column_sub][row_sub]    = 0;
            g_virtual_touch_info[column_sub][row_sub] = 0;
            g_touch_cnt[column_sub][row_sub]          = 0;

            /* Drift parameter clear */
            g_dc_cnt[column_sub][row_sub] = 0;
            g_dc_ref[column_sub][row_sub] = 0x00000000ul;
            /* Compulsion drift */
            g_nref[column_sub][row_sub] = key_val;
        }
    }

    /* ===== ONOFF final result ===== */
    if (0 != (g_real_touch_info[column_sub][row_sub]))
    {
        g_touch_result[column_sub][row_sub] = 1;
    }
    else
    {
        g_touch_result[column_sub][row_sub] = 0;
    }

    /* ===== Key ON/OFF update ===== */
    BDATA[column_sub][row_sub] = g_touch_result[column_sub][row_sub];
}

/***********************************************************************************************************************
* Function Name: CTSUDriftCorrection
* Description  : Drift correction function ( Reference value update)
* Arguments    : key_val        key data value
*              : column_sub        Horizontal (column) number
*              : row_sub        Length (row) number
* Return Value : DRIFT_OK(0)
*              : DRIFT_OFF(2)
***********************************************************************************************************************/
uint8_t CTSUDriftCorrection( uint16_t key_val, uint8_t column_sub, uint8_t row_sub )
{
    /* If the drift processing is a prohibition */
    if (OFF == g_sensor_function.function.drift)
    {
        /* There is no processing */
        return DRIFT_OFF;
    }

    /* In case of doing drift correction being and moreover On/Off judgment result 1=OFF */
    if ((0   == g_virtual_touch_info[column_sub][row_sub])
     && (0   != g_drift_permission[column_sub][row_sub])
     && (OFF == MultiCancelDriftCheck(g_data_tim)))
    {
        /* It is an addition for the drift correction average calculation */
        g_dc_ref[column_sub][row_sub] = g_dc_ref[column_sub][row_sub] + key_val;
        /* Drift correction counter's being inclement */
        g_dc_cnt[column_sub][row_sub] = (uint16_t)(g_dc_cnt[column_sub][row_sub] + 1);

        /* If reaching the correction number of times */
        if (g_dc_cnt[column_sub][row_sub] == g_dci)
        {
            if (g_dci == 0)
            {
                g_dci = 1;
            }
            g_nref[column_sub][row_sub] = (uint16_t)(g_dc_ref[column_sub][row_sub] / g_dci);

            /* To REF of the average */
            g_dc_ref[column_sub][row_sub] = 0x0000000ul;
            /* Work clear */
            g_dc_cnt[column_sub][row_sub] = 0;
        }
    }
    else
    {
        g_dc_ref[column_sub][row_sub] = 0x00000000ul;
        g_dc_cnt[column_sub][row_sub] = 0;
    }
    return DRIFT_OK;
}

/***********************************************************************************************************************
* Function Name: MultiCancelDriftCheck
* Description  : multicancel drift check
* Arguments    : multi_ch -
*              :   channel data
* Return Value : result - 
*              :   0=not, 1= on job
***********************************************************************************************************************/
uint8_t MultiCancelDriftCheck( uint8_t multi_ch )
{
    if (g_sensor_function.function.mtc == ON)
    {
        /* Multi cancelling CH and Asum> ATHR */
        if ((mtc_start_ch <= multi_ch) && (mtc_end_ch >= multi_ch))
        {
            if (asum > Athr)
            {
                return (ON);
            }
        }
    }
    return (OFF);
}

/***********************************************************************************************************************
* Function Name: KeyCalibration
* Description  : Key data calibration function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void KeyCalibration( void )
{
    uint8_t     column_ts;
    uint8_t     row_ts;
    uint8_t     loop;
    uint8_t     loop_max;
    uint8_t     max_num;
    uint32_t    work_buff[6];

    if ((CTSU_AT_INIT           == g_ctsu_at_mode)             // If offset tuning is working, this process is pass.(temp)
     || (CTSU_AT_INITIAL_OFFSET == g_ctsu_at_mode))
    {
        return;
    }

    for (row_ts = 0; row_ts < RECEIVE_NUM; row_ts++)
    {
        for (column_ts = 0; column_ts < SEND_NUM; column_ts++)
        {
            g_calib[ g_calib_data_num ][ g_calib_time ] = g_diff_scount[column_ts][row_ts];
            g_calib_data_num = (uint8_t)(g_calib_data_num + 1);
        }
    }

    if ((CALIB_TIME - 1) != g_calib_time)
    {
        g_calib_time = (uint8_t)(g_calib_time + 1);
        g_calib_data_num = 0;
        return;
    }

    column_ts = 0;
    row_ts = 0;

    for (loop = 0; loop < MEASURE_NUM; loop++)
    {
        work_buff[0] = (uint32_t)(g_calib[loop][0] + g_calib[loop][1]);        /* buff0 + buff1 */
        work_buff[1] = (uint32_t)(g_calib[loop][0] + g_calib[loop][2]);        /* buff0 + buff2 */
        work_buff[2] = (uint32_t)(g_calib[loop][0] + g_calib[loop][3]);        /* buff0 + buff3 */
        work_buff[3] = (uint32_t)(g_calib[loop][1] + g_calib[loop][2]);        /* buff1 + buff2 */
        work_buff[4] = (uint32_t)(g_calib[loop][1] + g_calib[loop][3]);        /* buff1 + buff3 */
        work_buff[5] = (uint32_t)(g_calib[loop][2] + g_calib[loop][3]);        /* buff2 + buff3 */

        for (loop_max = 0, max_num = 0 ; loop_max < 5 ; loop_max++)
        {
            if (work_buff[max_num] < work_buff[loop_max + 1])
            {
                max_num = (uint8_t)(loop_max + 1);
            }
        }

        g_nref[column_ts][row_ts] = (uint16_t)(work_buff[max_num] / 2);

        column_ts = (uint8_t)(column_ts + 1);
        if (column_ts == SEND_NUM)
        {
            column_ts = 0;
            row_ts = (uint8_t)(row_ts + 1);
        }
    }
    g_ctsu_flag.bit.msr_calib = 0;
}

/***********************************************************************************************************************
* Function Name: KeyFunctionCheck
* Description  : 
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
uint8_t KeyFunctionCheck( uint8_t loop )
{
    uint8_t     key_id;
    uint8_t     offset;
    uint16_t    sBit;

    if (KEY_LOW > loop)
    {
        key_id = 0;
        offset = loop;
    }
    else if (KEY_MID > loop)
    {
        key_id = 1;
        offset = (uint8_t)(loop - KEY_LOW);
    }
    else if (KEY_HIGH > loop)
    {
        key_id = 2;
        offset = (uint8_t)(loop - KEY_MID);
    }
    else
    {
        return KEY_FUNC_NG;
    }

    sBit = (uint16_t)(0x0001 << offset);
    if (0x0000 == (used_key_func[ key_id ] & sBit))
    {
        return KEY_FUNC_NG;
    }

    return KEY_FUNC_OK;
}

#endif    // KEY_USE

