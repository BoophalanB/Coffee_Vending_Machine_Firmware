/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_self_tuning_control.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_SELF_TUNING_CONTROL_C__

/***********************************************************************************************************************
 Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
 Includes <System Includes> , �gProject Includes�h
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_setup.h"
#include "r_ctsu_common_control.h"
#include "r_ctsu_key_control.h"
#include "r_ctsu_user_API.h"
#include "r_ctsu_self_tuning_control.h"
#include "r_ctsu_wheel_control.h"
#include "r_ctsu_slider_control.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: CheckSelfTuning
* Description  : 
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CheckSelfTuning( void )
{
    uint8_t     wk_onoff = 0;
#ifdef KEY_USE
    uint8_t     loop_id;
#endif
#ifdef SLIDER_USE
    uint8_t     slider_id;
#endif
#ifdef WHEEL_USE
    uint8_t     wheel_id;
#endif

#ifdef KEY_USE
    for (loop_id = 0; loop_id < MAX_KEY_ID; loop_id++)
    {
        if (0x0000 != BDATA[loop_id])
        {
            wk_onoff++;
        }
    }
#endif
#ifdef SLIDER_USE
    for (slider_id = 0; slider_id < DF_SLIDER_NUMBER; slider_id++)
    {
        if (0xFFFFu != g_slider_pos[slider_id])
        {
                wk_onoff++;
        }
    }
#endif
#ifdef WHEEL_USE
    for (wheel_id = 0; wheel_id < DF_WHEEL_NUMBER; wheel_id++)
    {
        if (0xFFFFu != g_wheel_pos[wheel_id])
        {
                wk_onoff++;
        }
    }
#endif
    if (0 == wk_onoff)
    {                                           // << touch off
        CtsuSetAutoTuningOnOff(AT_START);     /* Auto Tuning start */
    }
    else
    {                                           // << touch on
        CtsuSetAutoTuningOnOff( AT_PAUSE );     /* Auto Tuning Pause */
    }
}

/******************************************************************************
End  Of File
******************************************************************************/

