/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_user_API.c
* Version      : 1.00
* Description  : This is the touch API code.
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

#define __TOUCH_USER_API_C__
/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */
#include "iodefine.h"

/* S/W include header */
#include "r_cg_userdefine.h"
#include "r_ctsu_common_control.h"
#include "r_ctsu_setup.h"
//#include "r_ctsu_physical_driver.h"
#include "r_ctsu_user_API.h"

#ifdef KEY_USE
    #include "r_ctsu_key_control.h"
#endif

#ifdef SLIDER_USE
    #include "r_ctsu_slider_control.h"
#endif

#ifdef WHEEL_USE
    #include "r_ctsu_wheel_control.h"
#endif

#include <string.h>

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global variables (to be accessed by other files);
***********************************************************************************************************************/

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
uint8_t info_bak;

/***********************************************************************************************************************
* Function Name: CtsuSetMeasurementMode
* Description  : Set sensor measurement start/stop
* Arguments    : mode -
*                    TSCU mode
* Return Value : status - 
*                    touch data status
***********************************************************************************************************************/
uint8_t CtsuSetMeasureMode( CTSU_MODE_E mode )
{
    /* Check request mode -> STOP */
    if (CTSU_STOP_RQ == mode)
    {
        g_ctsu_soft_mode = CTSU_STOP_MODE;              /* Set CTSU Measurement stop mode    */
    }
    else
    {
        /* IF sensor Measurement stop mode */
        if (CTSU_STOP_MODE == g_ctsu_soft_mode)
        {
            g_ctsu_soft_mode = CTSU_READY_MODE;        /* Set CTSU measurement ready mode    */
            CTSUSetCtsuStart();                        /* Set CTSU Start proc.               */
        }
    }
    return (g_ctsu_soft_mode);
}

/***********************************************************************************************************************
* Function Name: CtsuGetDataCheck
* Description  : Measurement data acquisition check
* Arguments    : ---
* Return Value : 0x00 : GET_OK
*              : 0x01 : GET_NG (Not data updata)
*              : 0x02 : SENS_CNT_OVER_NG
*              : 0x03 : REF_CNT_OVER_NG
*              : 0x04 : SENS_REF_CNT_OVER_NG
*              : 0x05 : TSCAP_ERR_NG
***********************************************************************************************************************/
uint8_t CtsuGetDataCheck( void )
{
    uint8_t    status;

    if ((CTSU_AT_INIT == g_ctsu_at_mode) || (CTSU_AT_INITIAL_OFFSET == g_ctsu_at_mode))   /* Self tuning error */
    {
        status = SELF_TUNING_NG;
    }
    else if (1 == g_ctsu_flag.bit.data_update)                 /* Data get OK (non-error)        */
    {
        status = GET_OK;
    }
    else if ((1 == g_ctsu_flag.bit.sens_over) && (1 == g_ctsu_flag.bit.ref_over))
    {
        status = SENS_REF_CNT_OVER_NG;
    }
    else if (1 == g_ctsu_flag.bit.sens_over)              /* Sensor counter over error        */
    {
        status = SENS_CNT_OVER_NG;
    }
    else if (1 == g_ctsu_flag.bit.ref_over)               /* Reference counter over error    */
    {
        status = REF_CNT_OVER_NG;
    }
    else if (1 == g_ctsu_flag.bit.icomp_error)            /* TSCAP voltage error        */
    {
        status = TSCAP_ERR_NG;
    }
    else
    {
        status = GET_NG;
    }
    return status;
}

/***********************************************************************************************************************
* Function Name: CtsuGetSensorData
* Description  : CTSU sensor data get
* Arguments    : ---
* Return Value : 
***********************************************************************************************************************/
uint16_t CtsuGetSensorData( uint8_t index_num )
{
    if (0xFF != g_index_sensor[index_num]) 
    {
        return g_scount[g_index_sensor[index_num]];
    }
    else
    {
        return DATA_GET_ERROR;
    }
}

/***********************************************************************************************************************
* Function Name: CtsuGetSensorData
* Description  : CTSU sensor data get
* Arguments    : ---
* Return Value : 
***********************************************************************************************************************/
uint16_t CtsuGetReferenceData( uint8_t index_num )
{
    if (0xFF != g_index_sensor[index_num])
    {
        return g_rcount[g_index_sensor[index_num]];
    }
    else
    {
        return DATA_GET_ERROR;
    }
}

#ifdef KEY_USE
/***********************************************************************************************************************
* Function Name: CtsuSetDriftEnable
* Description  : Set drift correction enable ch
* Arguments    : sw -
*                   enable
*              : p_enable -
*                   Point of Drift ON/OFF data
* Return Value : result -
*                   result
***********************************************************************************************************************/
uint8_t CtsuSetDriftEnableCh( DRIFT_ENABLE_E sw )
{
    uint8_t loop;
    uint8_t result = 1;

    /* Set enable ch */
    /* If the drift is all channel prohibition */
    if (DC_ALL_STOP == sw)
    {
        for (loop = 0; loop < MAX_KEY_ID; loop++)
        {
            g_drift_permission[loop] = 0x0000;            //    all channel clear -> prohibition
        }
        result = 0;
    /* If the drift is all channel permission */
    }
    else if (DC_ALL_ACT == sw)
    {
#if (MAX_KEY_ID == 3)
        g_drift_permission[0] = 0xFFFF;
        g_drift_permission[1] = 0xFFFF;
        g_drift_permission[2] = 0x000F;
#elif (MAX_KEY_ID == 2)
        g_drift_permission[0] = 0xFFFF;
        g_drift_permission[1] = 0xFFFF;
#else
        g_drift_permission[0] = 0xFFFF;
#endif
        result = 0;
    }
    else
    {
        /* Do Nothing */
    }
    return (result);
}
#endif    // KEY_USE

/***********************************************************************************************************************
* Function Name: CtsuSetTrackingTiming
* Description  : CTSU Tracking Timing setting
* Arguments    : ---
* Return Value : 
***********************************************************************************************************************/
void CtsuSetTrackingTiming( uint16_t time )
{
    g_tracking_timing = time;        /* time * main cycle(20ms) */
}

/***********************************************************************************************************************
* Function Name: CtsuSetAutoTuningOnOff
* Description  : CTSU Auto Tuning ON/OFF switch
* Arguments    : ---
* Return Value : 
***********************************************************************************************************************/
uint8_t CtsuSetAutoTuningOnOff( AUTO_TUNING_ONOFF info )
{
    if (info_bak == info)
    {
        return g_ctsu_at_mode;
    }
    info_bak = info;

    if (AT_PAUSE == info)
    {
        if ((CTSU_AT_TSCAP_ERR != g_ctsu_at_mode)   /* If mode is TSCAP voltage error, not change.*/
         && (CTSU_AT_STOP      != g_ctsu_at_mode))  /* If mode is STOP, not Pause.*/
        {
            g_ctsu_at_mode_bak = g_ctsu_at_mode;
            g_ctsu_at_mode     = CTSU_AT_PAUSE;
        }
    }
    else if (AT_START == info)
    {
        if (CTSU_AT_PAUSE == g_ctsu_at_mode)        /* If mode is Pause, start.*/
        {
            g_ctsu_at_mode = g_ctsu_at_mode_bak;
            g_c_at_timing  = (g_tracking_timing + 1);    /* Tuning timing refresh */
        }
    }
    else if (AT_STOP == info)
    {
        if (CTSU_AT_TSCAP_ERR != g_ctsu_at_mode)    /* If mode is TSCAP voltage error, not change.*/
        {
            g_ctsu_at_mode = CTSU_AT_STOP;
        }
    }
    else                                            /* <<INITIAL START */
    {
        g_ctsu_at_mode     = CTSU_AT_INIT;
        g_ctsu_at_mode_bak = CTSU_AT_INIT;
    }
    return g_ctsu_at_mode;
}

/***********************************************************************************************************************
* END OF TEXT
***********************************************************************************************************************/
