/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_common_control.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_COMMON_CONTROL_C__

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */

/* S/W include header */
#include "r_ctsu_common_control.h"
#include "r_ctsu_physical_driver.h"
#include "r_ctsu_setup.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
DTC_TABLE_EXTERN DTC_DATA_T dtc_info_ctsu_wr;       /* DTC transfer information for CTSU WR */
DTC_TABLE_EXTERN DTC_DATA_T dtc_info_ctsu_rd;       /* DTC transfer information for CTSU RD */

/***********************************************************************************************************************
* Function Name: CTSUMainProc
* Description  : Capacitive Touch Sensing Unit main process
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUMainProc(void)
{
    if ((CTSU_FINISH_MODE == g_ctsu_soft_mode) && (1 == g_ctsu_flag.bit.ctsu_period))
    {
        g_ctsu_flag.bit.ctsu_period = 0;

        if ((1 == g_ctsu_flag.bit.ctsu_measure) && (0 == g_ctsu_flag.bit.icomp_error))
        {
            CTSUMovingAverage();                     /* Make Touch count value */
        }

        CTSUAutoTuning();                            /* Auto Tuning */
        g_ctsu_soft_mode = CTSU_READY_MODE;
        CTSUSetCtsuStart();                          /* set CTSU Start proc.*/
    }
}

/***********************************************************************************************************************
* Function Name: CTSUMovingAverage
* Description  : Make Touch count value
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CTSUMovingAverage( void )
{
    uint8_t    loop_ts;
    uint32_t   scount_work;
    uint32_t   rcount_work;

    for (loop_ts = 0; loop_ts < SUM_TS; loop_ts++)
    {
        if (0 == g_ctsu_flag.bit.first_storage)
        {
            g_s_addbuf[loop_ts] = g_cntrdata[loop_ts].sen_cntr;
            g_r_addbuf[loop_ts] = g_cntrdata[loop_ts].ref_cntr;
        }
        else
        {
            scount_work =  g_s_addbuf[loop_ts];                             /* Get Add data    */
            rcount_work =  g_r_addbuf[loop_ts];                             /* Get Add data    */
            scount_work -= scount_work / ADD_TIME;                          /* Pull data for the measurement once    */
            rcount_work -= rcount_work / ADD_TIME;                          /* Pull data for the measurement once    */
            scount_work += g_cntrdata[loop_ts].sen_cntr / ADD_TIME;         /* Add Now data    */
            rcount_work += g_cntrdata[loop_ts].ref_cntr / ADD_TIME;         /* Add Now data    */

            g_s_addbuf[loop_ts] = scount_work;                              /* Data store for next    */
            g_r_addbuf[loop_ts] = rcount_work;                              /* Data store for next    */
        }

        g_scount[loop_ts] = g_s_addbuf[loop_ts];
        g_rcount[loop_ts] = g_r_addbuf[loop_ts];
    }

    if (0 == g_ctsu_flag.bit.first_storage)
    {
        g_ctsu_flag.bit.first_storage = 1;
    }
}

/***********************************************************************************************************************
* Function Name: BackupCTSUSO
* Description  : backup Sensor Offset value
* Arguments    : ts, offset
* Return Value : none
***********************************************************************************************************************/
void BackupCTSUSO( void )
{
    uint8_t loop_ts;

    for (loop_ts = 0; loop_ts < SUM_TS; loop_ts++)
    {
        g_CTSUSO_bak[loop_ts]  = g_write_buf[(loop_ts * 3) + 1] & 0x03FF;
    }
}

/***********************************************************************************************************************
* Function Name: ResetCTSUSO
* Description  : reset Sensor Offset value
* Arguments    : ts, offset
* Return Value : none
***********************************************************************************************************************/
void ResetCTSUSO( void )
{
    uint8_t loop_ts;

    for (loop_ts = 0; loop_ts < SUM_TS; loop_ts++)
    {
        g_write_buf[(loop_ts * 3) + 1] = (g_write_buf[(loop_ts * 3) + 1] & 0xFC00) | g_CTSUSO_bak[loop_ts] ;
    }
}

/***********************************************************************************************************************
* Function Name: CTSUAutoTuning
* Description  : include offset auto tuning
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CTSUAutoTuning( void )
{
    switch (g_ctsu_at_mode)
    {
        case CTSU_AT_TRACKING_OFFSET:
            if (--g_c_at_timing == 0)                               /* Waiting for the stabilization g_scount, g_rcount */
            {
                g_c_at_timing = g_tracking_timing+1;                /* Tuning timing 20ms*time */
                TrackingOffsetTuning();                             /* Offset Auto Tuning(Tracking type) */
            }
            break;
        case CTSU_AT_INITIAL_OFFSET:
            if (--g_c_at_timing == 0)                               /* Waiting for the stabilization g_scount, g_rcount */
            {
                g_c_at_timing = ADD_TIME+1;                         /* Tuning timing 20ms*ADD_TIME(Moving Average time) */
                if (AT_FINISH == InitialOffsetTuning())
                {
                    g_ctsu_at_mode = CTSU_AT_TRACKING_OFFSET;       /* next mode */
                }
            }
            break;
        case CTSU_AT_INIT:
            g_c_at_timing = 10;                                     /* Wait time 20ms*10=200ms */
            BackupCTSUSO();                                         /* backup Sensor Offset value */
            g_ctsu_at_mode = CTSU_AT_INITIAL_OFFSET;                /* next mode */
            break;
        /* The default case is intentionally combined. 
           This was done to satisfy code coverage. */
        case CTSU_AT_STOP:
        case CTSU_AT_PAUSE:
        case CTSU_AT_TSCAP_ERR:
        default:
            break;
    }
}

/***********************************************************************************************************************
* Function Name: SetOffsetValue
* Description  : Sensor Offset value set
* Arguments    : ts, sign, offset
* Return Value : none
***********************************************************************************************************************/
uint8_t SetOffsetValue( uint16_t ts, uint8_t sign, uint16_t set_val )
{
    int16_t wk_offset;
    int16_t wk;
    uint8_t rt_dt = AT_NG;

    wk_offset = g_write_buf[ ts * 3 + 1 ] & 0x03FF;
    if (DT_MINUS == sign)
    {
        wk = wk_offset - set_val;
    }
    else
    {
        wk = wk_offset + set_val;
    }

    if (DT_MINUS == sign)
    {
        if (0 < wk)
        {
            g_write_buf[ts * 3 + 1] -= set_val;
            rt_dt = AT_OK;
        }
    }
    else
    {
        if ( 0x03FF >= wk )
        {
            g_write_buf[ts * 3 + 1] += set_val;
            rt_dt = AT_OK;
        }
    }
    return (rt_dt);
}

/***********************************************************************************************************************
* Function Name: InitialOffsetTuning
* Description  : offset auto tuning (Initial type)
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
uint8_t InitialOffsetTuning( void )
{
    uint16_t wk_scount;
    uint16_t wk_offset;
    uint16_t wk_count;
    uint16_t wk_diff_count;
    uint8_t  rt_dt = AT_FINISH;
    uint8_t  loop_ts;

    if (1 == g_ctsu_flag.bit.icomp_error)                    //      << TSCAP voltage error mode
    {
        g_ctsu_at_mode = CTSU_AT_TSCAP_ERR;
    }
    else
    {
        for (loop_ts=0; loop_ts < SUM_TS; loop_ts++)
        {
            if (CTSU_OT_INIT == offset_tuning_mode[loop_ts])             //  << [initial mode]
            {
                if (0xFFF0 <= g_scount[loop_ts])                         //  << overflow error mode
                {
                    g_ctsu_flag.bit.sens_over = 0;
                    if (AT_NG == SetOffsetValue(loop_ts, DT_PLUS, 0x020))
                    {
                        offset_tuning_mode[loop_ts]  = CTSU_OT_SC_OVERFLOW_ERR;
                    }
                }
                else if (g_scount[loop_ts] < g_rcount[loop_ts])          // << under Reference counter mode
                {
                    if (0 == (g_write_buf[(loop_ts * 3) + 1] & 0x03FF))
                    {
                        offset_tuning_mode[loop_ts]  = CTSU_OT_FINISH;
                    }
                    else
                    {
                        g_scount_bak[loop_ts] = g_scount[loop_ts];
                        g_offset_bak[loop_ts]  = g_write_buf[(loop_ts * 3) + 1] & 0x03FF;
                        SetOffsetValue(loop_ts, DT_MINUS, 0x002);
                        g_offset_data_bak[loop_ts] = 0x03FF;             // set dummy data
                        offset_tuning_mode[loop_ts] = CTSU_OT_TUNING;
                    }
                }
                else                                                     //  << 0xFFFE - Reference counter mode
                {
                    g_scount_bak[loop_ts] = g_scount[loop_ts];
                    g_offset_bak[loop_ts]  = g_write_buf[(loop_ts * 3) + 1] & 0x03FF;
                    SetOffsetValue(loop_ts, DT_PLUS, 0x002);
                    g_offset_data_bak[loop_ts] = 0x03FF;                 // set dummy data
                    offset_tuning_mode[loop_ts] = CTSU_OT_TUNING;
                }
            }
            else if (CTSU_OT_TUNING == offset_tuning_mode[loop_ts])      //  << [offset tuning mode]
            {
                if (1 == g_ctsu_flag.bit.icomp_error)                    //  << TSCAP voltage error mode
                {
                    ResetCTSUSO();                                       /* reset Sensor Offset value    */
                    g_ctsu_at_mode = CTSU_AT_TSCAP_ERR;                  /* set error mode -> process end    */
                    break;
                }
                else
                {
                    if (g_scount_bak[loop_ts] > g_scount[loop_ts])
                    {
                        wk_scount = g_scount_bak[loop_ts] - g_scount[loop_ts];
                    }
                    else
                    {
                        wk_scount = g_scount[loop_ts] - g_scount_bak[loop_ts];
                    }
                    wk_offset = (g_write_buf[ loop_ts*3+1 ] & 0x03FF);
                    if (wk_offset > g_offset_bak[loop_ts])
                    {
                        wk_offset = wk_offset - g_offset_bak[loop_ts];
                    }
                    else
                    {
                        wk_offset = g_offset_bak[loop_ts] - wk_offset;
                    }
                    wk_count = wk_scount / wk_offset;

                    if (0 == wk_count)
                    {
                        wk_count = 1;
                    }

                    g_scount_bak[loop_ts] = g_scount[loop_ts];
                    g_offset_bak[loop_ts] = (g_write_buf[ loop_ts*3+1 ] & 0x03FF);
                    if (g_scount[loop_ts] > g_rcount[loop_ts])
                    {
                        wk_diff_count = g_scount[loop_ts] - g_rcount[loop_ts];
                        wk_offset = wk_diff_count / wk_count;

                        if (wk_offset > g_offset_data_bak[loop_ts])     // protect unstable data
                        {
                            wk_offset = g_offset_data_bak[loop_ts];
                        }
                        g_offset_data_bak[loop_ts] = wk_offset;

                        if (0 == wk_offset)
                        {
                            offset_tuning_mode[loop_ts] = CTSU_OT_FINISH;
                        }
                        else if (3 > wk_offset)
                        {
                            SetOffsetValue(loop_ts, DT_PLUS, wk_offset);
                        }
                        else
                        {
                            SetOffsetValue(loop_ts, DT_PLUS, (wk_offset / 3));
                        }
                    }
                    else
                    {
                        wk_diff_count = g_rcount[loop_ts] - g_scount[loop_ts];
                        wk_offset = wk_diff_count / wk_count;

                        if (wk_offset > g_offset_data_bak[loop_ts])                      // protect unstable data
                        {
                            wk_offset = g_offset_data_bak[loop_ts];
                        }
                        g_offset_data_bak[loop_ts] = wk_offset;

                        if (0 == wk_offset)
                        {
                            offset_tuning_mode[loop_ts] = CTSU_OT_FINISH;
                        }
                        else if (3 > wk_offset)
                        {
                            SetOffsetValue(loop_ts, DT_MINUS, wk_offset);
                        }
                        else
                        {
                            SetOffsetValue(loop_ts, DT_MINUS, (wk_offset / 3));
                        }
                    }
                }
            }
            else
            {
                /* Do Nothing */
            }
            if ((CTSU_OT_INIT   == offset_tuning_mode[loop_ts])
             || (CTSU_OT_TUNING == offset_tuning_mode[loop_ts]))
            {
                rt_dt = AT_CONTI;
            }
        }
    }
    return (rt_dt);
}

/***********************************************************************************************************************
* Function Name: TrackingOffsetTuning
* Description  : offset auto tuning (Tracking type)
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void TrackingOffsetTuning( void )
{
    uint8_t loop_ts;

    for (loop_ts = 0; loop_ts < SUM_TS; loop_ts++)
    {
        if (g_scount[loop_ts] > g_rcount[loop_ts])
        {
            if (TRACKING_UPPER_LIMIT < (g_scount[loop_ts] - g_rcount[loop_ts]))
            {
                SetOffsetValue(loop_ts, DT_PLUS, 1);
            }
        }
        else
        {
            if (TRACKING_LOWER_LIMIT < (g_rcount[loop_ts] - g_scount[loop_ts]))
            {
                SetOffsetValue(loop_ts, DT_MINUS, 1);
            }
        }
    }
}

/***********************************************************************************************************************
* Function Name: CTSUSetCtsuStart
* Description  : set DTC initial value
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUSetCtsuStart(void)
{
    CTSUSetDtcStart(&dtc_info_ctsu_wr,&dtc_info_ctsu_rd,g_write_buf,g_cntrdata,g_cntrdummy,CTSU_DRIVER_SELF);
    CTSUSetMeasurementOperation(0x01, 0x00);        /* Mode:start, Trigger:s/w    */
    g_ctsu_soft_mode = CTSU_RUN_MODE;
}

