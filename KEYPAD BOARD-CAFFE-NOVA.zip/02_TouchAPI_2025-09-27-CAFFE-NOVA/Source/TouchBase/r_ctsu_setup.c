/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_setup.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_SETUP_C__

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */
#include "iodefine.h"

/* S/W include header */
#include "r_ctsu_setup.h"
#include "r_ctsu_physical_driver.h"
#include "r_ctsu_common_control.h"
#include "r_ctsu_user_API.h"

#ifdef KEY_USE
    #include "r_ctsu_key_control.h"
#endif

#ifdef SLIDER_USE
    #include "r_ctsu_slider_control.h"
#endif

#ifdef WHEEL_USE
    #include "r_ctsu_wheel_control.h"
#endif

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
DTC_TABLE_EXTERN DTC_DATA_T dtc_info_ctsu_wr;       /* DTC transfer information for CTSU WR */
DTC_TABLE_EXTERN DTC_DATA_T dtc_info_ctsu_rd;       /* DTC transfer information for CTSU RD */
/* Touch key parameter */
#ifdef KEY_USE
const uint16_t thrbuff[] =
{
#if DF_TS00_KEY_USE == 1
    DF_TS00_THR,
#endif
#if DF_TS01_KEY_USE == 1
    DF_TS01_THR,
#endif
#if DF_TS02_KEY_USE == 1
    DF_TS02_THR,
#endif
#if DF_TS03_KEY_USE == 1
    DF_TS03_THR,
#endif
#if DF_TS04_KEY_USE == 1
    DF_TS04_THR,
#endif
#if DF_TS05_KEY_USE == 1
    DF_TS05_THR,
#endif
#if DF_TS06_KEY_USE == 1
    DF_TS06_THR,
#endif
#if DF_TS07_KEY_USE == 1
    DF_TS07_THR,
#endif
#if DF_TS08_KEY_USE == 1
    DF_TS08_THR,
#endif
#if DF_TS09_KEY_USE == 1
    DF_TS09_THR,
#endif
#if DF_TS10_KEY_USE == 1
    DF_TS10_THR,
#endif
#if DF_TS11_KEY_USE == 1
    DF_TS11_THR,
#endif
#if DF_TS12_KEY_USE == 1
    DF_TS12_THR,
#endif
#if DF_TS13_KEY_USE == 1
    DF_TS13_THR,
#endif
#if DF_TS14_KEY_USE == 1
    DF_TS14_THR,
#endif
#if DF_TS15_KEY_USE == 1
    DF_TS15_THR,
#endif
#if DF_TS16_KEY_USE == 1
    DF_TS16_THR,
#endif
#if DF_TS17_KEY_USE == 1
    DF_TS17_THR,
#endif
#if DF_TS18_KEY_USE == 1
    DF_TS18_THR,
#endif
#if DF_TS19_KEY_USE == 1
    DF_TS19_THR,
#endif
#if DF_TS20_KEY_USE == 1
    DF_TS20_THR,
#endif
#if DF_TS21_KEY_USE == 1
    DF_TS21_THR,
#endif
#if DF_TS22_KEY_USE == 1
    DF_TS22_THR,
#endif
#if DF_TS23_KEY_USE == 1
    DF_TS23_THR,
#endif
#if DF_TS24_KEY_USE == 1
    DF_TS24_THR,
#endif
#if DF_TS25_KEY_USE == 1
    DF_TS25_THR,
#endif
#if DF_TS26_KEY_USE == 1
    DF_TS26_THR,
#endif
#if DF_TS27_KEY_USE == 1
    DF_TS27_THR,
#endif
#if DF_TS28_KEY_USE == 1
    DF_TS28_THR,
#endif
#if DF_TS29_KEY_USE == 1
    DF_TS29_THR,
#endif
#if DF_TS30_KEY_USE == 1
    DF_TS30_THR,
#endif
#if DF_TS31_KEY_USE == 1
    DF_TS31_THR,
#endif
#if DF_TS32_KEY_USE == 1
    DF_TS32_THR,
#endif
#if DF_TS33_KEY_USE == 1
    DF_TS33_THR,
#endif
#if DF_TS34_KEY_USE == 1
    DF_TS34_THR,
#endif
#if DF_TS35_KEY_USE == 1
    DF_TS35_THR,
#endif
};

const uint8_t hysbuff[] =
{
#if DF_TS00_KEY_USE == 1
    DF_TS00_HYS,
#endif
#if DF_TS01_KEY_USE == 1
    DF_TS01_HYS,
#endif
#if DF_TS02_KEY_USE == 1
    DF_TS02_HYS,
#endif
#if DF_TS03_KEY_USE == 1
    DF_TS03_HYS,
#endif
#if DF_TS04_KEY_USE == 1
    DF_TS04_HYS,
#endif
#if DF_TS05_KEY_USE == 1
    DF_TS05_HYS,
#endif
#if DF_TS06_KEY_USE == 1
    DF_TS06_HYS,
#endif
#if DF_TS07_KEY_USE == 1
    DF_TS07_HYS,
#endif
#if DF_TS08_KEY_USE == 1
    DF_TS08_HYS,
#endif
#if DF_TS09_KEY_USE == 1
    DF_TS09_HYS,
#endif
#if DF_TS10_KEY_USE == 1
    DF_TS10_HYS,
#endif
#if DF_TS11_KEY_USE == 1
    DF_TS11_HYS,
#endif
#if DF_TS12_KEY_USE == 1
    DF_TS12_HYS,
#endif
#if DF_TS13_KEY_USE == 1
    DF_TS13_HYS,
#endif
#if DF_TS14_KEY_USE == 1
    DF_TS14_HYS,
#endif
#if DF_TS15_KEY_USE == 1
    DF_TS15_HYS,
#endif
#if DF_TS16_KEY_USE == 1
    DF_TS16_HYS,
#endif
#if DF_TS17_KEY_USE == 1
    DF_TS17_HYS,
#endif
#if DF_TS18_KEY_USE == 1
    DF_TS18_HYS,
#endif
#if DF_TS19_KEY_USE == 1
    DF_TS19_HYS,
#endif
#if DF_TS20_KEY_USE == 1
    DF_TS20_HYS,
#endif
#if DF_TS21_KEY_USE == 1
    DF_TS21_HYS,
#endif
#if DF_TS22_KEY_USE == 1
    DF_TS22_HYS,
#endif
#if DF_TS23_KEY_USE == 1
    DF_TS23_HYS,
#endif
#if DF_TS24_KEY_USE == 1
    DF_TS24_HYS,
#endif
#if DF_TS25_KEY_USE == 1
    DF_TS25_HYS,
#endif
#if DF_TS26_KEY_USE == 1
    DF_TS26_HYS,
#endif
#if DF_TS27_KEY_USE == 1
    DF_TS27_HYS,
#endif
#if DF_TS28_KEY_USE == 1
    DF_TS28_HYS,
#endif
#if DF_TS29_KEY_USE == 1
    DF_TS29_HYS,
#endif
#if DF_TS30_KEY_USE == 1
    DF_TS30_HYS,
#endif
#if DF_TS31_KEY_USE == 1
    DF_TS31_HYS,
#endif
#if DF_TS32_KEY_USE == 1
    DF_TS32_HYS,
#endif
#if DF_TS33_KEY_USE == 1
    DF_TS33_HYS,
#endif
#if DF_TS34_KEY_USE == 1
    DF_TS34_HYS,
#endif
#if DF_TS35_KEY_USE == 1
    DF_TS35_HYS,
#endif
};
#endif /* KEY_USE */

/*===== DTC transmit data ========================================================*/
const uint16_t ctsusscbuff[] =
{ 
#if DF_ENABLE_TS00 == 1
    DF_TS00_CTSUSSC,
#endif
#if DF_ENABLE_TS01 == 1
    DF_TS01_CTSUSSC,
#endif
#if DF_ENABLE_TS02 == 1
    DF_TS02_CTSUSSC,
#endif
#if DF_ENABLE_TS03 == 1
    DF_TS03_CTSUSSC,
#endif
#if DF_ENABLE_TS04 == 1
    DF_TS04_CTSUSSC,
#endif
#if DF_ENABLE_TS05 == 1
    DF_TS05_CTSUSSC,
#endif
#if DF_ENABLE_TS06 == 1
    DF_TS06_CTSUSSC,
#endif
#if DF_ENABLE_TS07 == 1
    DF_TS07_CTSUSSC,
#endif
#if DF_ENABLE_TS08 == 1
    DF_TS08_CTSUSSC,
#endif
#if DF_ENABLE_TS09 == 1
    DF_TS09_CTSUSSC,
#endif
#if DF_ENABLE_TS10 == 1
    DF_TS10_CTSUSSC,
#endif
#if DF_ENABLE_TS11 == 1
    DF_TS11_CTSUSSC,
#endif
#if DF_ENABLE_TS12 == 1
    DF_TS12_CTSUSSC,
#endif
#if DF_ENABLE_TS13 == 1
    DF_TS13_CTSUSSC,
#endif
#if DF_ENABLE_TS14 == 1
    DF_TS14_CTSUSSC,
#endif
#if DF_ENABLE_TS15 == 1
    DF_TS15_CTSUSSC,
#endif
#if DF_ENABLE_TS16 == 1
    DF_TS16_CTSUSSC,
#endif
#if DF_ENABLE_TS17 == 1
    DF_TS17_CTSUSSC,
#endif
#if DF_ENABLE_TS18 == 1
    DF_TS18_CTSUSSC,
#endif
#if DF_ENABLE_TS19 == 1
    DF_TS19_CTSUSSC,
#endif
#if DF_ENABLE_TS20 == 1
    DF_TS20_CTSUSSC,
#endif
#if DF_ENABLE_TS21 == 1
    DF_TS21_CTSUSSC,
#endif
#if DF_ENABLE_TS22 == 1
    DF_TS22_CTSUSSC,
#endif
#if DF_ENABLE_TS23 == 1
    DF_TS23_CTSUSSC,
#endif
#if DF_ENABLE_TS24 == 1
    DF_TS24_CTSUSSC,
#endif
#if DF_ENABLE_TS25 == 1
    DF_TS25_CTSUSSC,
#endif
#if DF_ENABLE_TS26 == 1
    DF_TS26_CTSUSSC,
#endif
#if DF_ENABLE_TS27 == 1
    DF_TS27_CTSUSSC,
#endif
#if DF_ENABLE_TS28 == 1
    DF_TS28_CTSUSSC,
#endif
#if DF_ENABLE_TS29 == 1
    DF_TS29_CTSUSSC,
#endif
#if DF_ENABLE_TS30 == 1
    DF_TS30_CTSUSSC,
#endif
#if DF_ENABLE_TS31 == 1
    DF_TS31_CTSUSSC,
#endif
#if DF_ENABLE_TS32 == 1
    DF_TS32_CTSUSSC,
#endif
#if DF_ENABLE_TS33 == 1
    DF_TS33_CTSUSSC,
#endif
#if DF_ENABLE_TS34 == 1
    DF_TS34_CTSUSSC,
#endif
#if DF_ENABLE_TS35 == 1
    DF_TS35_CTSUSSC,
#endif
};

const uint16_t ctsuso0buff[] =
{ 
#if DF_ENABLE_TS00 == 1
    DF_TS00_CTSUSO0,
#endif
#if DF_ENABLE_TS01 == 1
    DF_TS01_CTSUSO0,
#endif
#if DF_ENABLE_TS02 == 1
    DF_TS02_CTSUSO0,
#endif
#if DF_ENABLE_TS03 == 1
    DF_TS03_CTSUSO0,
#endif
#if DF_ENABLE_TS04 == 1
    DF_TS04_CTSUSO0,
#endif
#if DF_ENABLE_TS05 == 1
    DF_TS05_CTSUSO0,
#endif
#if DF_ENABLE_TS06 == 1
    DF_TS06_CTSUSO0,
#endif
#if DF_ENABLE_TS07 == 1
    DF_TS07_CTSUSO0,
#endif
#if DF_ENABLE_TS08 == 1
    DF_TS08_CTSUSO0,
#endif
#if DF_ENABLE_TS09 == 1
    DF_TS09_CTSUSO0,
#endif
#if DF_ENABLE_TS10 == 1
    DF_TS10_CTSUSO0,
#endif
#if DF_ENABLE_TS11 == 1
    DF_TS11_CTSUSO0,
#endif
#if DF_ENABLE_TS12 == 1
    DF_TS12_CTSUSO0,
#endif
#if DF_ENABLE_TS13 == 1
    DF_TS13_CTSUSO0,
#endif
#if DF_ENABLE_TS14 == 1
    DF_TS14_CTSUSO0,
#endif
#if DF_ENABLE_TS15 == 1
    DF_TS15_CTSUSO0,
#endif
#if DF_ENABLE_TS16 == 1
    DF_TS16_CTSUSO0,
#endif
#if DF_ENABLE_TS17 == 1
    DF_TS17_CTSUSO0,
#endif
#if DF_ENABLE_TS18 == 1
    DF_TS18_CTSUSO0,
#endif
#if DF_ENABLE_TS19 == 1
    DF_TS19_CTSUSO0,
#endif
#if DF_ENABLE_TS20 == 1
    DF_TS20_CTSUSO0,
#endif
#if DF_ENABLE_TS21 == 1
    DF_TS21_CTSUSO0,
#endif
#if DF_ENABLE_TS22 == 1
    DF_TS22_CTSUSO0,
#endif
#if DF_ENABLE_TS23 == 1
    DF_TS23_CTSUSO0,
#endif
#if DF_ENABLE_TS24 == 1
    DF_TS24_CTSUSO0,
#endif
#if DF_ENABLE_TS25 == 1
    DF_TS25_CTSUSO0,
#endif
#if DF_ENABLE_TS26 == 1
    DF_TS26_CTSUSO0,
#endif
#if DF_ENABLE_TS27 == 1
    DF_TS27_CTSUSO0,
#endif
#if DF_ENABLE_TS28 == 1
    DF_TS28_CTSUSO0,
#endif
#if DF_ENABLE_TS29 == 1
    DF_TS29_CTSUSO0,
#endif
#if DF_ENABLE_TS30 == 1
    DF_TS30_CTSUSO0,
#endif
#if DF_ENABLE_TS31 == 1
    DF_TS31_CTSUSO0,
#endif
#if DF_ENABLE_TS32 == 1
    DF_TS32_CTSUSO0,
#endif
#if DF_ENABLE_TS33 == 1
    DF_TS33_CTSUSO0,
#endif
#if DF_ENABLE_TS34 == 1
    DF_TS34_CTSUSO0,
#endif
#if DF_ENABLE_TS35 == 1
    DF_TS35_CTSUSO0,
#endif
};

const uint16_t ctsuso1buff[] =
{ 
#if DF_ENABLE_TS00 == 1
    DF_TS00_CTSUSO1,
#endif
#if DF_ENABLE_TS01 == 1
    DF_TS01_CTSUSO1,
#endif
#if DF_ENABLE_TS02 == 1
    DF_TS02_CTSUSO1,
#endif
#if DF_ENABLE_TS03 == 1
    DF_TS03_CTSUSO1,
#endif
#if DF_ENABLE_TS04 == 1
    DF_TS04_CTSUSO1,
#endif
#if DF_ENABLE_TS05 == 1
    DF_TS05_CTSUSO1,
#endif
#if DF_ENABLE_TS06 == 1
    DF_TS06_CTSUSO1,
#endif
#if DF_ENABLE_TS07 == 1
    DF_TS07_CTSUSO1,
#endif
#if DF_ENABLE_TS08 == 1
    DF_TS08_CTSUSO1,
#endif
#if DF_ENABLE_TS09 == 1
    DF_TS09_CTSUSO1,
#endif
#if DF_ENABLE_TS10 == 1
    DF_TS10_CTSUSO1,
#endif
#if DF_ENABLE_TS11 == 1
    DF_TS11_CTSUSO1,
#endif
#if DF_ENABLE_TS12 == 1
    DF_TS12_CTSUSO1,
#endif
#if DF_ENABLE_TS13 == 1
    DF_TS13_CTSUSO1,
#endif
#if DF_ENABLE_TS14 == 1
    DF_TS14_CTSUSO1,
#endif
#if DF_ENABLE_TS15 == 1
    DF_TS15_CTSUSO1,
#endif
#if DF_ENABLE_TS16 == 1
    DF_TS16_CTSUSO1,
#endif
#if DF_ENABLE_TS17 == 1
    DF_TS17_CTSUSO1,
#endif
#if DF_ENABLE_TS18 == 1
    DF_TS18_CTSUSO1,
#endif
#if DF_ENABLE_TS19 == 1
    DF_TS19_CTSUSO1,
#endif
#if DF_ENABLE_TS20 == 1
    DF_TS20_CTSUSO1,
#endif
#if DF_ENABLE_TS21 == 1
    DF_TS21_CTSUSO1,
#endif
#if DF_ENABLE_TS22 == 1
    DF_TS22_CTSUSO1,
#endif
#if DF_ENABLE_TS23 == 1
    DF_TS23_CTSUSO1,
#endif
#if DF_ENABLE_TS24 == 1
    DF_TS24_CTSUSO1,
#endif
#if DF_ENABLE_TS25 == 1
    DF_TS25_CTSUSO1,
#endif
#if DF_ENABLE_TS26 == 1
    DF_TS26_CTSUSO1,
#endif
#if DF_ENABLE_TS27 == 1
    DF_TS27_CTSUSO1,
#endif
#if DF_ENABLE_TS28 == 1
    DF_TS28_CTSUSO1,
#endif
#if DF_ENABLE_TS29 == 1
    DF_TS29_CTSUSO1,
#endif
#if DF_ENABLE_TS30 == 1
    DF_TS30_CTSUSO1,
#endif
#if DF_ENABLE_TS31 == 1
    DF_TS31_CTSUSO1,
#endif
#if DF_ENABLE_TS32 == 1
    DF_TS32_CTSUSO1,
#endif
#if DF_ENABLE_TS33 == 1
    DF_TS33_CTSUSO1,
#endif
#if DF_ENABLE_TS34 == 1
    DF_TS34_CTSUSO1,
#endif
#if DF_ENABLE_TS35 == 1
    DF_TS35_CTSUSO1,
#endif
};

#ifdef SLIDER_USE
const slider_wheel_info_t g_sliderInfoRom[] = {
#if (DF_SLIDER_NUMBER > 0)
    { DF_SLIDER0_TS00, DF_SLIDER0_TS01, DF_SLIDER0_TS02, DF_SLIDER0_TS03, DF_SLIDER0_TS04,
      DF_SLIDER0_TS05, DF_SLIDER0_TS06, DF_SLIDER0_TS07, DF_SLIDER0_TS08, DF_SLIDER0_TS09,
      DF_SLIDER0_SENSOR_NUMBER,
      DF_SLIDER0_THRESHOLD, DF_SLIDER0_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 1)
    { DF_SLIDER1_TS00, DF_SLIDER1_TS01, DF_SLIDER1_TS02, DF_SLIDER1_TS03, DF_SLIDER1_TS04,
      DF_SLIDER1_TS05, DF_SLIDER1_TS06, DF_SLIDER1_TS07, DF_SLIDER1_TS08, DF_SLIDER1_TS09,
      DF_SLIDER1_SENSOR_NUMBER,
      DF_SLIDER1_THRESHOLD, DF_SLIDER1_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 2)
    { DF_SLIDER2_TS00, DF_SLIDER2_TS01, DF_SLIDER2_TS02, DF_SLIDER2_TS03, DF_SLIDER2_TS04,
      DF_SLIDER2_TS05, DF_SLIDER2_TS06, DF_SLIDER2_TS07, DF_SLIDER2_TS08, DF_SLIDER2_TS09,
      DF_SLIDER2_SENSOR_NUMBER,
      DF_SLIDER2_THRESHOLD, DF_SLIDER2_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 3)
    { DF_SLIDER3_TS00, DF_SLIDER3_TS01, DF_SLIDER3_TS02, DF_SLIDER3_TS03, DF_SLIDER3_TS04,
      DF_SLIDER3_TS05, DF_SLIDER3_TS06, DF_SLIDER3_TS07, DF_SLIDER3_TS08, DF_SLIDER3_TS09,
      DF_SLIDER3_SENSOR_NUMBER,
      DF_SLIDER3_THRESHOLD, DF_SLIDER3_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 4)
    { DF_SLIDER4_TS00, DF_SLIDER4_TS01, DF_SLIDER4_TS02, DF_SLIDER4_TS03, DF_SLIDER4_TS04,
      DF_SLIDER4_TS05, DF_SLIDER4_TS06, DF_SLIDER4_TS07, DF_SLIDER4_TS08, DF_SLIDER4_TS09,
      DF_SLIDER4_SENSOR_NUMBER,
      DF_SLIDER4_THRESHOLD, DF_SLIDER4_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 5)
    { DF_SLIDER5_TS00, DF_SLIDER5_TS01, DF_SLIDER5_TS02, DF_SLIDER5_TS03, DF_SLIDER5_TS04,
      DF_SLIDER5_TS05, DF_SLIDER5_TS06, DF_SLIDER5_TS07, DF_SLIDER5_TS08, DF_SLIDER5_TS09,
      DF_SLIDER5_SENSOR_NUMBER,
      DF_SLIDER5_THRESHOLD,  DF_SLIDER5_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 6)
    { DF_SLIDER6_TS00, DF_SLIDER6_TS01, DF_SLIDER6_TS02, DF_SLIDER6_TS03, DF_SLIDER6_TS04,
      DF_SLIDER6_TS05, DF_SLIDER6_TS06, DF_SLIDER6_TS07, DF_SLIDER6_TS08, DF_SLIDER6_TS09,
      DF_SLIDER6_SENSOR_NUMBER,
      DF_SLIDER6_THRESHOLD,  DF_SLIDER6_RESOLUTION, 0xffff },
#endif
#if (DF_SLIDER_NUMBER > 7)
    { DF_SLIDER7_TS00, DF_SLIDER7_TS01, DF_SLIDER7_TS02, DF_SLIDER7_TS03, DF_SLIDER7_TS04,
      DF_SLIDER7_TS05, DF_SLIDER7_TS06, DF_SLIDER7_TS07, DF_SLIDER7_TS08, DF_SLIDER7_TS09,
      DF_SLIDER7_SENSOR_NUMBER,
      DF_SLIDER7_THRESHOLD,  DF_SLIDER7_RESOLUTION, 0xffff },
#endif
};
#endif

#ifdef WHEEL_USE
const slider_wheel_info_t g_wheelInfoRom[] = {
#if (DF_WHEEL_NUMBER > 0)
    { DF_WHEEL0_TS00, DF_WHEEL0_TS01, DF_WHEEL0_TS02, DF_WHEEL0_TS03, DF_WHEEL0_TS04,
      DF_WHEEL0_TS05, DF_WHEEL0_TS06, DF_WHEEL0_TS07, DF_WHEEL0_TS08, DF_WHEEL0_TS09,
      DF_WHEEL0_SENSOR_NUMBER,
      DF_WHEEL0_THRESHOLD, DF_WHEEL0_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 1)
    { DF_WHEEL1_TS00, DF_WHEEL1_TS01, DF_WHEEL1_TS02, DF_WHEEL1_TS03, DF_WHEEL1_TS04,
      DF_WHEEL1_TS05, DF_WHEEL1_TS06, DF_WHEEL1_TS07, DF_WHEEL1_TS08, DF_WHEEL1_TS09,
      DF_WHEEL1_SENSOR_NUMBER,
      DF_WHEEL1_THRESHOLD, DF_WHEEL1_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 2)
    { DF_WHEEL2_TS00, DF_WHEEL2_TS01, DF_WHEEL2_TS02, DF_WHEEL2_TS03, DF_WHEEL2_TS04,
      DF_WHEEL2_TS05, DF_WHEEL2_TS06, DF_WHEEL2_TS07, DF_WHEEL2_TS08, DF_WHEEL2_TS09,
      DF_WHEEL2_SENSOR_NUMBER,
      DF_WHEEL2_THRESHOLD, DF_WHEEL2_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 3)
    { DF_WHEEL3_TS00, DF_WHEEL3_TS01, DF_WHEEL3_TS02, DF_WHEEL3_TS03, DF_WHEEL3_TS04,
      DF_WHEEL3_TS05, DF_WHEEL3_TS06, DF_WHEEL3_TS07, DF_WHEEL3_TS08, DF_WHEEL3_TS09,
      DF_WHEEL3_SENSOR_NUMBER,
      DF_WHEEL3_THRESHOLD, DF_WHEEL3_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 4)
    { DF_WHEEL4_TS00, DF_WHEEL4_TS01, DF_WHEEL4_TS02, DF_WHEEL4_TS03, DF_WHEEL4_TS04,
      DF_WHEEL4_TS05, DF_WHEEL4_TS06, DF_WHEEL4_TS07, DF_WHEEL4_TS08, DF_WHEEL4_TS09,
      DF_WHEEL4_SENSOR_NUMBER,
      DF_WHEEL4_THRESHOLD, DF_WHEEL4_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 5)
    { DF_WHEEL5_TS00, DF_WHEEL5_TS01, DF_WHEEL5_TS02, DF_WHEEL5_TS03, DF_WHEEL5_TS04,
      DF_WHEEL5_TS05, DF_WHEEL5_TS06, DF_WHEEL5_TS07, DF_WHEEL5_TS08, DF_WHEEL5_TS09,
      DF_WHEEL5_SENSOR_NUMBER,
      DF_WHEEL5_THRESHOLD,  DF_WHEEL5_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 6)
    { DF_WHEEL6_TS00, DF_WHEEL6_TS01, DF_WHEEL6_TS02, DF_WHEEL6_TS03, DF_WHEEL6_TS04,
      DF_WHEEL6_TS05, DF_WHEEL6_TS06, DF_WHEEL6_TS07, DF_WHEEL6_TS08, DF_WHEEL6_TS09,
      DF_WHEEL6_SENSOR_NUMBER,
      DF_WHEEL6_THRESHOLD,  DF_WHEEL6_RESOLUTION, 0xffff },
#endif
#if (DF_WHEEL_NUMBER > 7)
    { DF_WHEEL7_TS00, DF_WHEEL7_TS01, DF_WHEEL7_TS02, DF_WHEEL7_TS03, DF_WHEEL7_TS04,
      DF_WHEEL7_TS05, DF_WHEEL7_TS06, DF_WHEEL7_TS07, DF_WHEEL7_TS08, DF_WHEEL7_TS09,
      DF_WHEEL7_SENSOR_NUMBER,
      DF_WHEEL7_THRESHOLD,  DF_WHEEL7_RESOLUTION, 0xffff },
#endif
};
#endif

#ifdef KEY_USE
    extern volatile uint16_t    g_key_onoff[MAX_KEY_ID];
#endif

/***********************************************************************************************************************
* Function Name: CTSUSetInitial
* Description  : Capacitive Touch Sensing Unit initial setup
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUSetInitial(void)
{
    CTSUInitialRegisterValueStorage();
    CTSUFunctionPinControl();
    CTSUSetDtcInitial(&dtc_info_ctsu_wr, &dtc_info_ctsu_rd,g_write_buf, g_cntrdata, g_cntrdummy, CTSU_DRIVER_SELF);
    CTSUStartSetup();
    CTSUSetWriteBuffer();
    CTSUParameterBufInit();                            /* Prameter Buff initialaize    */
    g_ctsu_soft_mode = CTSU_FINISH_MODE;
    CtsuSetTrackingTiming(DF_TRACKING_TIME);           /* Tracking timing              */
    CtsuSetAutoTuningOnOff(AT_INITIAL_START);          /* Auto Tuning initial mode     */
}

/***********************************************************************************************************************
* Function Name: CTSUInitialRegisterValueStorage
* Description  : CTSU measurement Initial register value storage
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUInitialRegisterValueStorage(void)
{
    g_ctsucr1_param.hard_macro_power_sw       = DF_CTSUPON;
    g_ctsucr1_param.lpf_charge_sw             = DF_CTSUCSW;
    g_ctsucr1_param.analogue_signal_mode      = DF_CTSUATUNE0;
    g_ctsucr1_param.analogue_output_mode      = DF_CTSUATUNE1;
    g_ctsucr1_param.ctsu_count_source         = DF_CTSUCLK;
    g_ctsucr1_param.measure_mode              = DF_CTSUMD;

    g_ctsudclkc_param.diffusion_clock_mode    = DF_CTSUSSMOD;
    g_ctsudclkc_param.diffusion_clock_control = DF_CTSUSSCNT;

    g_ctsusdprs_param.drive_pulse_cycle       = DF_CTSUPRRATIO;
    g_ctsusdprs_param.drive_pulse_mode        = DF_CTSUPRMODE;
    g_ctsusdprs_param.sensor_edge_control     = DF_CTSUSOFF;

    g_ctsu_wait_time = DF_CTSUSST;

    g_ctsu_chanel_enable = DF_CTSUCHAC0 | (DF_CTSUCHAC1 << 8);

    if (0 == g_ctsucr1_param.measure_mode)
    {
        g_ctsu_measure_chanel = DF_CTSUMCH0;
    }
    else
    {
        //g_ctsu_measure_chanel = 0x00;
    }
    g_ctsu_chanel_txrx = DF_CTSUCHTRC0 | (DF_CTSUCHTRC1 << 8);
}

/***********************************************************************************************************************
* Function Name: CTSUFunctionPinControl
* Description  : CTSU measurement pin function setting function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUFunctionPinControl(void)
{
    /* Port functon change protect off setting */
    MPC.PWPR.BIT.B0WI  = OFF;
    MPC.PWPR.BIT.PFSWE = ON;

    /* Pin function is set in touch sensor */
    if (1 == DF_ENABLE_TS00)
    {
        MPC.P07PFS.BYTE  = P07PFS_TS0;
        PORT0.PMR.BIT.B7 = 1;
    }
    else
    {
        PORT0.PODR.BIT.B7 = 0;
        PORT0.PDR.BIT.B7  = 1;
    }

    if (1 == DF_ENABLE_TS01)
    {
        MPC.P04PFS.BYTE  = P04PFS_TS1;
        PORT0.PMR.BIT.B4 = 1;
    }
    else
    {
        PORT0.PODR.BIT.B4 = 0;
        PORT0.PDR.BIT.B4  = 1;
    }

    if (1 == DF_ENABLE_TS02)
    {
        MPC.P02PFS.BYTE  = P02PFS_TS2;
        PORT0.PMR.BIT.B2 = 1;
    }
    else
    {
        PORT0.PODR.BIT.B2 = 0;
        PORT0.PDR.BIT.B2  = 1;
    }

    if (1 == DF_ENABLE_TS03)
    {
        MPC.PJ3PFS.BYTE  = PJ3PFS_TS3;
        PORTJ.PMR.BIT.B3 = 1;
    }
    else
    {
        PORTJ.PODR.BIT.B3 = 0;
        PORTJ.PDR.BIT.B3  = 1;
    }

    if (1 == DF_ENABLE_TS04)
    {
        MPC.P25PFS.BYTE  = P25PFS_TS4;
        PORT2.PMR.BIT.B5 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B5 = 0;
        PORT2.PDR.BIT.B5  = 1;
    }

    if (1 == DF_ENABLE_TS05)
    {
        MPC.P24PFS.BYTE  = P24PFS_TS5;
        PORT2.PMR.BIT.B4 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B4 = 0;
        PORT2.PDR.BIT.B4  = 1;
    }

    if (1 == DF_ENABLE_TS06)
    {
        MPC.P23PFS.BYTE  = P23PFS_TS6;
        PORT2.PMR.BIT.B3 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B3 = 0;
        PORT2.PDR.BIT.B3  = 1;
    }

    if (1 == DF_ENABLE_TS07)
    {
        MPC.P22PFS.BYTE  = P22PFS_TS7;
        PORT2.PMR.BIT.B2 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B2 = 0;
        PORT2.PDR.BIT.B2  = 1;
    }

    if (1 == DF_ENABLE_TS08)
    {
        MPC.P21PFS.BYTE  = P21PFS_TS8;
        PORT2.PMR.BIT.B1 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B1 = 0;
        PORT2.PDR.BIT.B1  = 1;
    }

    if (1 == DF_ENABLE_TS09)
    {
        MPC.P20PFS.BYTE  = P20PFS_TS9;
        PORT2.PMR.BIT.B0 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B0 = 0;
        PORT2.PDR.BIT.B0  = 1;
    }

    if (1 == DF_ENABLE_TS10)
    {
        MPC.P27PFS.BYTE  = P27PFS_TS10;
        PORT2.PMR.BIT.B7 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B7 = 0;
        PORT2.PDR.BIT.B7  = 1;
    }

    if (1 == DF_ENABLE_TS11)
    {
        MPC.P32PFS.BYTE  = P32PFS_TS11;
        PORT3.PMR.BIT.B2 = 1;
    }
    else
    {
        PORT3.PODR.BIT.B2 = 0;
        PORT3.PDR.BIT.B2  = 1;
    }

    if (0 != SUM_TS)
    {
        MPC.P26PFS.BYTE  = P26PFS_TSCAP;
        PORT2.PMR.BIT.B6 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B6 = 0;
        PORT2.PDR.BIT.B6  = 1;
    }

    /* Sensor drive pulse output setting        */
#ifdef DRIVE_PULSE_DEBUG
    SYSTEM.PRCR.WORD  = 0xA5FF;
    SYSTEM.CKOCR.WORD = 0x0800;            /* CTSU CLKOUT        */
    MPC.P15PFS.BYTE   = P15PFS_DEGUG;
#endif

    /* Sensor drive pulse output setting        */
#ifdef DRIVE_PULSE_DEBUG
    PORT1.PMR.BIT.B5 = ON;
#endif
}

/***********************************************************************************************************************
* Function Name: CTSUInitialSetup
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUStartSetup(void)
{
    /* set Max key for using Physical driver */
    g_max_key = SUM_TS;

    /* Operation mode Register change protect off setting */
    SYSTEM.PRCR.WORD = PRCR1_ENA;
    SYSTEM.MSTPCRD.BIT.MSTPD10 = OFF;

    /* CTSU hard macro power supply switch change process call */
    CTSUSetPowerSupplyEnable(g_ctsucr1_param.hard_macro_power_sw);

    /* CTSU LPF capacitance charge switch change process call */
    CTSUSetLpfChargingControl(g_ctsucr1_param.lpf_charge_sw);

    /* CTSU analog adjustment Signal0 set process call */
    CTSUSetLowPowControl(g_ctsucr1_param.analogue_signal_mode);

    /* CTSU analog adjustment Signal1 set  process call */
    CTSUSetIcoCurrentAttenuator(g_ctsucr1_param.analogue_output_mode);

    /* CTSU count Source select process call */
    CTSUSetCountSource(g_ctsucr1_param.ctsu_count_source);

    /* CTSU measurement mode select process call */
    CTSUSetMeasurementMode(g_ctsucr1_param.measure_mode);

    /* CTSU Sensor Drive Pulse Spectrum Diffusion Setting Register (CTSUSDPRS) */
    CTSUSetSensorDrivePulseSpectrumDiffusion(g_ctsusdprs_param.drive_pulse_cycle, g_ctsusdprs_param.drive_pulse_mode, g_ctsusdprs_param.sensor_edge_control);

    /* CTSU diffusion clock mode and oscillation frequency select process call */
    CTSUSetDiffusionClockModeSelect(g_ctsudclkc_param.diffusion_clock_mode, g_ctsudclkc_param.diffusion_clock_control);

    /* CTSU sensor wait time set process call */
    CTSUSetSensorStabilizationWaitTime(g_ctsu_wait_time);

    /* CTSU channel enable set process call */
    CTSUSetChannelEnableControl(g_ctsu_chanel_enable);

    /* CTSU measurement channel set process call */
    CTSUSetMeasurementChannel(g_ctsu_measure_chanel);

    /* CTSU Channel transmit/receive control process call */
    CTSUSetChannelTransmitReceiveControl(g_ctsu_chanel_txrx);
}

/***********************************************************************************************************************
* Function Name: CTSUSetWriteBuffer
* Description  : set DTC write buffer data
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUSetWriteBuffer(void)
{
    uint8_t loop_ch;
    uint8_t pt;

    /* ===== Drift Correction  ===== */
    /* CTSU Channel Enable Control Register 0 (CTSUCHAC0)
    b7-0    CTSU Measurement Channel 0        */
    /* CTSU Channel Enable Control Register 1 (CTSUCHAC1)
    b3-0    CTSU Measurement Channel 1        */
    for (loop_ch = 0, pt = 0; loop_ch < SUM_TS; loop_ch++)
    {
        /* CTSU Spectrum Diffusion Control Register initial value    */
        g_write_buf[ pt ]   = ctsusscbuff[loop_ch];
        /* CTSU Sensor Offset Register 0 initial value    */
        g_write_buf[ pt+1 ] = ctsuso0buff[loop_ch];
        /* CTSU Sensor Offset Register 1 initial value    */
        g_write_buf[ pt+2 ] = ctsuso1buff[loop_ch];
        /* next buffer pointer set    */
        pt = (uint8_t)(pt + 3);
    }
}

/***********************************************************************************************************************
* Function Name: CTSUParameterBufInit
* Description  : CTSU S/W parameter initialization function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CTSUParameterBufInit(void)
{
#ifdef KEY_USE
    uint8_t loop_id;
#endif

    uint8_t loop;
    uint8_t pt;

#ifdef KEY_USE
    for (loop = 0; loop < KEY_NUM; loop++)
    {
        g_nthr[loop] = thrbuff[loop];
        g_nhys[loop] = hysbuff[loop];
    }

    /* ===== ON/OFF judgment initialization  ===== */
    for (loop_id = 0; loop_id < MAX_KEY_ID; loop_id++)
    {
        g_virtual_touch_info[loop_id] = 0x0000;
        g_real_touch_info[loop_id]    = 0x0000;
        g_touch_result[loop_id]       = 0x0000;
        BDATA[loop_id]                = 0x0000;
        g_key_onoff[loop_id]          = 0x0000;
    }

#if (MAX_KEY_ID == 3 )
    used_key_func[0]      = KEY_USE_INFO_LOW;        /* TS09,TS10,TS11        (0000111000000000)    */
    used_key_func[1]      = KEY_USE_INFO_MID;        /* not used                                    */
    used_key_func[2]      = KEY_USE_INFO_HIGH;       /* not used                                    */
    g_drift_permission[0] = 0xFFFF;
    g_drift_permission[1] = 0xFFFF;
    g_drift_permission[2] = 0x000F;
#elif (MAX_KEY_ID == 2 )
    used_key_func[0]      = KEY_USE_INFO_LOW;        /* TS09,TS10,TS11        (0000111000000000)    */
    used_key_func[1]      = KEY_USE_INFO_MID;        /* not used                                    */
    g_drift_permission[0] = 0xFFFF;
    g_drift_permission[1] = 0xFFFF;
#elif (MAX_KEY_ID == 1 )
    used_key_func[0]      = KEY_USE_INFO_LOW;        /* TS09,TS10,TS11        (0000111000000000)    */
    g_drift_permission[0] = 0xFFFF;
#endif

    /* ===== Multi Touch Cancel  ===== */
    g_sensor_function.value        = 0x00;
    g_sensor_function.function.mtc = DF_MTC_ONOFF;            /* Multi Touch Cancel off        */
    mtc_start_ch                   = DF_MTC_START_TS;
    mtc_end_ch                     = DF_MTC_END_TS;

    /* ===== Total touch/non tount function setting  ===== */
    g_touch_cmp_val     = DF_ACD_ON;
    g_non_touch_cmp_val = DF_ACD_OFF;

    /* ===== Drift correction function setting  ===== */
    g_sensor_function.function.drift = DF_DC_FUNCTION;           /* Drift function enabule        */
    g_dci = DF_DCI;

    /* ===== MSA function setting ===== */
    g_msa = DF_MSA;

    if (g_touch_cmp_val)
    {
        g_sensor_function.function.acd0 = ON;
    }

    if (g_non_touch_cmp_val)
    {
        g_sensor_function.function.acd1 = ON;
    }

    if (g_msa)
    {
        g_sensor_function.function.msa = ON;
    }

    g_data_tim = 0;
    g_calib_data_num = 0;

    /* ===== Measure Calibration function setting ===== */
    g_ctsu_flag.bit.msr_calib = 1;            /* Request flag set        */
#else // KEY_USE
    g_ctsu_flag.bit.msr_calib = 0;            /* Request flag set        */
#endif // KEY_USE

#ifdef SLIDER_USE
    for (loop = 0; loop < DF_SLIDER_NUMBER; loop++)
    {
        g_slider_pos[ loop ] = 0xFFFF;
        g_sliderInfo[ loop ] = g_sliderInfoRom[ loop ];
    }
#endif

#ifdef WHEEL_USE
    for (loop = 0; loop < DF_WHEEL_NUMBER; loop++)
    {
        g_wheel_pos[ loop ] = 0xFFFF;
        g_wheelInfo[ loop ] = g_wheelInfoRom[ loop ];
    }
#endif

    /* ===== Initialize index table for conversion ts-number to SUM_TS index ===== */
    for (loop = 0, pt = 0; loop < MAX_TS; loop++)
    {
        if (0 != (g_ctsu_chanel_enable & (1 << loop)))
        {
            g_index_sensor[loop] = pt++;
        }
        else
        {
            g_index_sensor[loop] = 0xff;
        }
    }
}
