/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_interrupt.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"
#ifdef MUTUAL_FUNC_USE
    #include "r_ctsu_physical_driver_mu.h"
#else
    #include "r_ctsu_physical_driver.h"
#endif    //] MUTUAL_FUNC_USE

/* H/W include header */
#include "iodefine.h"
#include "r_cg_vect.h"
#include "r_ctsu_interrupt.h"

/* S/W include header */
#include "r_ctsu_common_control.h"
//#include "r_ctsu_user_API.h"

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/

/***********************************************************************************************************************
* Function Name: Excep_CTSU_CTSUFN
* Description  : Measurement finish interruption process.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void Excep_CTSU_CTSUFN( void )
{
    CTSUInterrupt();
}

/***********************************************************************************************************************
* Function Name: CTSUInterrupt
* Description  : CTSU measurement end interrupt function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUInterrupt( void )
{
    uint8_t err_status;

    if (0 != CTSUGetTscapVoltageError())
    {
        g_ctsu_flag.bit.icomp_error = 1;            /* TSCAP voltage error              */
        CTSUSetPowerSupplyOnly(0x00);               /* TSCUPON off -> TSCUICOMP clear   */
        nop();
        nop();
        CTSUSetPowerSupplyOnly(0x01);               /* TSCUPON on                       */
    }
    else
    {
        g_ctsu_flag.bit.icomp_error = 0;            /* TSCAP voltage error clear        */
    }

    err_status = CTSUGetCounterOverflow();

    switch (err_status)
    {
        case SENS_OK:
            g_ctsu_flag.bit.sens_over = 0;
            g_ctsu_flag.bit.ref_over = 0;
            if (g_ctsu_flag.bit.icomp_error != 1)         /* TSCAP voltage error                    */
            {
                g_ctsu_flag.bit.data_update = 1;          /* Measurement data updata status set     */
            }
            g_ctsu_soft_mode = CTSU_FINISH_MODE;
            g_ctsu_flag.bit.ctsu_measure = 1;
            break;
        case SENS_OVER:
            g_ctsu_flag.bit.ref_over = 0;
            g_ctsu_flag.bit.sens_over = 1;                /* Sensor Counter overflow status set     */
            g_ctsu_soft_mode = CTSU_FINISH_MODE;
            break;
        case REF_OVER:
            g_ctsu_flag.bit.sens_over = 0;
            g_ctsu_flag.bit.ref_over = 1;                 /* Reference Counter overflow status set  */
            g_ctsu_soft_mode = CTSU_FINISH_MODE;
            break;
        case SENS_REF_OVER:
            g_ctsu_flag.bit.sens_over = 1;                /* Sensor Counter overflow status set     */
            g_ctsu_flag.bit.ref_over = 1;                 /* Reference Counter overflow status set  */
            g_ctsu_soft_mode = CTSU_FINISH_MODE;
            break;
        default:
            g_ctsu_soft_mode = CTSU_STOP_MODE;
            break;
    }
}
