/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_setup_mu.c
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#define __R_CTSU_SETUP_C__

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"

/* H/W include header */
#include "iodefine.h"

/* S/W include header */
#include "r_ctsu_setup.h"
#include "r_ctsu_physical_driver_mu.h"
#include "r_ctsu_common_control.h"
#include "r_ctsu_user_API.h"

#ifdef KEY_USE
    #include "r_ctsu_key_control.h"
#endif

#ifdef SLIDER_USE
    #include "r_ctsu_slider_control.h"
#endif

#ifdef WHEEL_USE
    #include "r_ctsu_wheel_control.h"
#endif

/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
DTC_TABLE_EXTERN DTC_DATA_T dtc_info_ctsu_wr;       /* DTC transfer information for CTSU WR */
DTC_TABLE_EXTERN DTC_DATA_T dtc_info_ctsu_rd;       /* DTC transfer information for CTSU RD */

/* Touch key parameter */
#ifdef KEY_USE
const uint16_t thrbuff[] =
{
#if DF_TS00_FUNCTION == 1
    DF_TS00_00_THR,
#endif
#if DF_TS01_FUNCTION == 1
    DF_TS01_00_THR,
#endif
#if DF_TS02_FUNCTION == 1
    DF_TS02_00_THR,
#endif
#if DF_TS03_FUNCTION == 1
    DF_TS03_00_THR,
#endif
#if DF_TS04_FUNCTION == 1
    DF_TS04_00_THR,
#endif
#if DF_TS05_FUNCTION == 1
    DF_TS05_00_THR,
#endif
#if DF_TS06_FUNCTION == 1
    DF_TS06_00_THR,
#endif
#if DF_TS07_FUNCTION == 1
    DF_TS07_00_THR,
#endif
#if DF_TS08_FUNCTION == 1
    DF_TS08_00_THR,
#endif
#if DF_TS09_FUNCTION == 1
    DF_TS09_00_THR,
#endif
#if DF_TS10_FUNCTION == 1
    DF_TS10_00_THR,
#endif
#if DF_TS11_FUNCTION == 1
    DF_TS11_00_THR,
#endif
#if (1 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_01_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_01_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_01_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_01_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_01_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_01_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_01_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_01_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_01_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_01_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_01_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_01_THR,
    #endif
#endif
#if (2 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_02_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_02_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_02_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_02_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_02_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_02_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_02_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_02_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_02_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_02_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_02_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_02_THR,
    #endif
#endif
#if (3 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_03_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_03_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_03_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_03_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_03_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_03_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_03_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_03_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_03_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_03_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_03_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_03_THR,
    #endif
#endif
#if (4 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_04_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_04_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_04_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_04_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_04_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_04_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_04_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_04_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_04_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_04_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_04_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_04_THR,
    #endif
#endif
#if (5 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_05_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_05_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_05_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_05_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_05_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_05_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_05_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_05_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_05_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_05_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_05_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_05_THR,
    #endif
#endif
#if (6 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_06_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_06_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_06_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_06_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_06_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_06_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_06_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_06_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_06_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_06_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_06_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_06_THR,
    #endif
#endif
#if (7 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_07_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_07_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_07_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_07_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_07_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_07_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_07_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_07_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_07_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_07_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_07_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_07_THR,
    #endif
#endif
#if (8 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_08_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_08_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_08_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_08_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_08_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_08_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_08_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_08_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_08_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_08_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_08_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_08_THR,
    #endif
#endif
#if (9 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_09_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_09_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_09_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_09_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_09_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_09_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_09_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_09_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_09_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_09_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_09_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_09_THR,
    #endif
#endif
#if (10 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_10_THR,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_10_THR,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_10_THR,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_10_THR,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_10_THR,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_10_THR,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_10_THR,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_10_THR,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_10_THR,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_10_THR,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_10_THR,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_10_THR,
    #endif
#endif
};

const uint8_t hysbuff[] =
{
#if DF_TS00_FUNCTION == 1
    DF_TS00_00_HYS,
#endif
#if DF_TS01_FUNCTION == 1
    DF_TS01_00_HYS,
#endif
#if DF_TS02_FUNCTION == 1
    DF_TS02_00_HYS,
#endif
#if DF_TS03_FUNCTION == 1
    DF_TS03_00_HYS,
#endif
#if DF_TS04_FUNCTION == 1
    DF_TS04_00_HYS,
#endif
#if DF_TS05_FUNCTION == 1
    DF_TS05_00_HYS,
#endif
#if DF_TS06_FUNCTION == 1
    DF_TS06_00_HYS,
#endif
#if DF_TS07_FUNCTION == 1
    DF_TS07_00_HYS,
#endif
#if DF_TS08_FUNCTION == 1
    DF_TS08_00_HYS,
#endif
#if DF_TS09_FUNCTION == 1
    DF_TS09_00_HYS,
#endif
#if DF_TS10_FUNCTION == 1
    DF_TS10_00_HYS,
#endif
#if DF_TS11_FUNCTION == 1
    DF_TS11_00_HYS,
#endif
#if (1 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_01_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_01_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_01_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_01_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_01_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_01_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_01_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_01_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_01_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_01_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_01_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_01_HYS,
    #endif
#endif
#if (2 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_02_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_02_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_02_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_02_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_02_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_02_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_02_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_02_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_02_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_02_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_02_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_02_HYS,
    #endif
#endif
#if (3 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_03_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_03_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_03_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_03_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_03_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_03_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_03_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_03_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_03_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_03_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_03_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_03_HYS,
    #endif
#endif
#if (4 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_04_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_04_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_04_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_04_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_04_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_04_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_04_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_04_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_04_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_04_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_04_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_04_HYS,
    #endif
#endif
#if (5 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_05_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_05_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_05_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_05_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_05_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_05_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_05_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_05_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_05_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_05_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_05_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_05_HYS,
    #endif
#endif
#if (6 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_06_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_06_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_06_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_06_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_06_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_06_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_06_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_06_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_06_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_06_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_06_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_06_HYS,
    #endif
#endif
#if (7 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_07_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_07_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_07_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_07_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_07_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_07_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_07_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_07_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_07_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_07_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_07_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_07_HYS,
    #endif
#endif
#if (8 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_08_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_08_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_08_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_08_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_08_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_08_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_08_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_08_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_08_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_08_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_08_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_08_HYS,
    #endif
#endif
#if (9 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_09_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_09_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_09_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_09_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_09_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_09_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_09_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_09_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_09_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_09_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_09_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_09_HYS,
    #endif
#endif
#if (10 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_10_HYS,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_10_HYS,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_10_HYS,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_10_HYS,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_10_HYS,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_10_HYS,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_10_HYS,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_10_HYS,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_10_HYS,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_10_HYS,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_10_HYS,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_10_HYS,
    #endif
#endif
};
#endif /* KEY_USE */

/*===== DTC transmit data ========================================================*/
const uint16_t ctsusscbuff[] =
{
#if DF_TS00_FUNCTION == 1
    DF_TS00_00_CTSUSSC,
#endif
#if DF_TS01_FUNCTION == 1
    DF_TS01_00_CTSUSSC,
#endif
#if DF_TS02_FUNCTION == 1
    DF_TS02_00_CTSUSSC,
#endif
#if DF_TS03_FUNCTION == 1
    DF_TS03_00_CTSUSSC,
#endif
#if DF_TS04_FUNCTION == 1
    DF_TS04_00_CTSUSSC,
#endif
#if DF_TS05_FUNCTION == 1
    DF_TS05_00_CTSUSSC,
#endif
#if DF_TS06_FUNCTION == 1
    DF_TS06_00_CTSUSSC,
#endif
#if DF_TS07_FUNCTION == 1
    DF_TS07_00_CTSUSSC,
#endif
#if DF_TS08_FUNCTION == 1
    DF_TS08_00_CTSUSSC,
#endif
#if DF_TS09_FUNCTION == 1
    DF_TS09_00_CTSUSSC,
#endif
#if DF_TS10_FUNCTION == 1
    DF_TS10_00_CTSUSSC,
#endif
#if DF_TS11_FUNCTION == 1
    DF_TS11_00_CTSUSSC,
#endif
#if (1 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_01_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_01_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_01_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_01_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_01_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_01_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_01_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_01_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_01_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_01_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_01_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_01_CTSUSSC,
    #endif
#endif
#if (2 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_02_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_02_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_02_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_02_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_02_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_02_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_02_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_02_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_02_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_02_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_02_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_02_CTSUSSC,
    #endif
#endif
#if (3 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_03_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_03_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_03_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_03_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_03_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_03_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_03_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_03_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_03_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_03_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_03_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_03_CTSUSSC,
    #endif
#endif
#if (4 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_04_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_04_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_04_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_04_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_04_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_04_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_04_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_04_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_04_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_04_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_04_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_04_CTSUSSC,
    #endif
#endif
#if (5 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_05_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_05_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_05_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_05_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_05_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_05_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_05_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_05_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_05_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_05_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_05_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_05_CTSUSSC,
    #endif
#endif
#if (6 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_06_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_06_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_06_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_06_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_06_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_06_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_06_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_06_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_06_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_06_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_06_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_06_CTSUSSC,
    #endif
#endif
#if (7 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_07_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_07_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_07_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_07_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_07_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_07_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_07_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_07_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_07_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_07_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_07_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_07_CTSUSSC,
    #endif
#endif
#if (8 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_08_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_08_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_08_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_08_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_08_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_08_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_08_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_08_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_08_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_08_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_08_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_08_CTSUSSC,
    #endif
#endif
#if (9 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_09_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_09_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_09_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_09_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_09_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_09_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_09_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_09_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_09_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_09_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_09_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_09_CTSUSSC,
    #endif
#endif
#if (10 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_10_CTSUSSC,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_10_CTSUSSC,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_10_CTSUSSC,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_10_CTSUSSC,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_10_CTSUSSC,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_10_CTSUSSC,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_10_CTSUSSC,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_10_CTSUSSC,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_10_CTSUSSC,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_10_CTSUSSC,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_10_CTSUSSC,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_10_CTSUSSC,
    #endif
#endif
};

const uint16_t ctsuso0buff[] =
{
#if DF_TS00_FUNCTION == 1
    DF_TS00_00_CTSUSO0,
#endif
#if DF_TS01_FUNCTION == 1
    DF_TS01_00_CTSUSO0,
#endif
#if DF_TS02_FUNCTION == 1
    DF_TS02_00_CTSUSO0,
#endif
#if DF_TS03_FUNCTION == 1
    DF_TS03_00_CTSUSO0,
#endif
#if DF_TS04_FUNCTION == 1
    DF_TS04_00_CTSUSO0,
#endif
#if DF_TS05_FUNCTION == 1
    DF_TS05_00_CTSUSO0,
#endif
#if DF_TS06_FUNCTION == 1
    DF_TS06_00_CTSUSO0,
#endif
#if DF_TS07_FUNCTION == 1
    DF_TS07_00_CTSUSO0,
#endif
#if DF_TS08_FUNCTION == 1
    DF_TS08_00_CTSUSO0,
#endif
#if DF_TS09_FUNCTION == 1
    DF_TS09_00_CTSUSO0,
#endif
#if DF_TS10_FUNCTION == 1
    DF_TS10_00_CTSUSO0,
#endif
#if DF_TS11_FUNCTION == 1
    DF_TS11_00_CTSUSO0,
#endif
#if (1 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_01_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_01_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_01_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_01_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_01_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_01_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_01_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_01_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_01_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_01_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_01_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_01_CTSUSO0,
    #endif
#endif
#if (2 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_02_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_02_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_02_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_02_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_02_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_02_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_02_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_02_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_02_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_02_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_02_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_02_CTSUSO0,
    #endif
#endif
#if (3 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_03_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_03_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_03_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_03_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_03_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_03_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_03_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_03_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_03_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_03_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_03_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_03_CTSUSO0,
    #endif
#endif
#if (4 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_04_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_04_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_04_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_04_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_04_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_04_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_04_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_04_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_04_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_04_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_04_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_04_CTSUSO0,
    #endif
#endif
#if (5 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_05_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_05_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_05_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_05_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_05_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_05_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_05_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_05_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_05_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_05_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_05_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_05_CTSUSO0,
    #endif
#endif
#if (6 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_06_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_06_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_06_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_06_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_06_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_06_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_06_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_06_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_06_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_06_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_06_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_06_CTSUSO0,
    #endif
#endif
#if (7 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_07_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_07_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_07_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_07_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_07_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_07_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_07_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_07_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_07_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_07_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_07_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_07_CTSUSO0,
    #endif
#endif
#if (8 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_08_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_08_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_08_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_08_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_08_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_08_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_08_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_08_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_08_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_08_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_08_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_08_CTSUSO0,
    #endif
#endif
#if (9 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_09_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_09_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_09_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_09_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_09_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_09_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_09_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_09_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_09_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_09_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_09_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_09_CTSUSO0,
    #endif
#endif
#if (10 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_10_CTSUSO0,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_10_CTSUSO0,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_10_CTSUSO0,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_10_CTSUSO0,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_10_CTSUSO0,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_10_CTSUSO0,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_10_CTSUSO0,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_10_CTSUSO0,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_10_CTSUSO0,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_10_CTSUSO0,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_10_CTSUSO0,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_10_CTSUSO0,
    #endif
#endif
};

const uint16_t ctsuso1buff[] =
{
#if DF_TS00_FUNCTION == 1
    DF_TS00_00_CTSUSO1,
#endif
#if DF_TS01_FUNCTION == 1
    DF_TS01_00_CTSUSO1,
#endif
#if DF_TS02_FUNCTION == 1
    DF_TS02_00_CTSUSO1,
#endif
#if DF_TS03_FUNCTION == 1
    DF_TS03_00_CTSUSO1,
#endif
#if DF_TS04_FUNCTION == 1
    DF_TS04_00_CTSUSO1,
#endif
#if DF_TS05_FUNCTION == 1
    DF_TS05_00_CTSUSO1,
#endif
#if DF_TS06_FUNCTION == 1
    DF_TS06_00_CTSUSO1,
#endif
#if DF_TS07_FUNCTION == 1
    DF_TS07_00_CTSUSO1,
#endif
#if DF_TS08_FUNCTION == 1
    DF_TS08_00_CTSUSO1,
#endif
#if DF_TS09_FUNCTION == 1
    DF_TS09_00_CTSUSO1,
#endif
#if DF_TS10_FUNCTION == 1
    DF_TS10_00_CTSUSO1,
#endif
#if DF_TS11_FUNCTION == 1
    DF_TS11_00_CTSUSO1,
#endif
#if (1 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_01_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_01_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_01_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_01_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_01_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_01_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_01_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_01_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_01_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_01_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_01_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_01_CTSUSO1,
    #endif
#endif
#if (2 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_02_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_02_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_02_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_02_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_02_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_02_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_02_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_02_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_02_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_02_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_02_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_02_CTSUSO1,
    #endif
#endif
#if (3 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_03_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_03_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_03_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_03_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_03_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_03_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_03_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_03_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_03_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_03_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_03_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_03_CTSUSO1,
    #endif
#endif
#if (4 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_04_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_04_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_04_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_04_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_04_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_04_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_04_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_04_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_04_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_04_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_04_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_04_CTSUSO1,
    #endif
#endif
#if (5 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_05_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_05_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_05_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_05_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_05_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_05_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_05_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_05_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_05_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_05_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_05_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_05_CTSUSO1,
    #endif
#endif
#if (6 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_06_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_06_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_06_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_06_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_06_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_06_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_06_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_06_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_06_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_06_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_06_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_06_CTSUSO1,
    #endif
#endif
#if (7 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_07_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_07_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_07_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_07_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_07_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_07_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_07_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_07_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_07_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_07_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_07_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_07_CTSUSO1,
    #endif
#endif
#if (8 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_08_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_08_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_08_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_08_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_08_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_08_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_08_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_08_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_08_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_08_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_08_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_08_CTSUSO1,
    #endif
#endif
#if (9 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_09_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_09_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_09_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_09_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_09_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_09_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_09_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_09_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_09_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_09_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_09_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_09_CTSUSO1,
    #endif
#endif
#if (10 < RECEIVE_NUM)
    #if DF_TS00_FUNCTION == 1
        DF_TS00_10_CTSUSO1,
    #endif
    #if DF_TS01_FUNCTION == 1
        DF_TS01_10_CTSUSO1,
    #endif
    #if DF_TS02_FUNCTION == 1
        DF_TS02_10_CTSUSO1,
    #endif
    #if DF_TS03_FUNCTION == 1
        DF_TS03_10_CTSUSO1,
    #endif
    #if DF_TS04_FUNCTION == 1
        DF_TS04_10_CTSUSO1,
    #endif
    #if DF_TS05_FUNCTION == 1
        DF_TS05_10_CTSUSO1,
    #endif
    #if DF_TS06_FUNCTION == 1
        DF_TS06_10_CTSUSO1,
    #endif
    #if DF_TS07_FUNCTION == 1
        DF_TS07_10_CTSUSO1,
    #endif
    #if DF_TS08_FUNCTION == 1
        DF_TS08_10_CTSUSO1,
    #endif
    #if DF_TS09_FUNCTION == 1
        DF_TS09_10_CTSUSO1,
    #endif
    #if DF_TS10_FUNCTION == 1
        DF_TS10_10_CTSUSO1,
    #endif
    #if DF_TS11_FUNCTION == 1
        DF_TS11_10_CTSUSO1,
    #endif
#endif
};

#ifdef KEY_USE
    extern volatile uint16_t    g_key_onoff[SEND_NUM][RECEIVE_NUM];
#endif

/***********************************************************************************************************************
* Function Name: CTSUSetInitial
* Description  : Capacitive Touch Sensing Unit initial setup
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUSetInitial(void)
{
    CTSUInitialRegisterValueStorage();
    CTSUFunctionPinControl();
    CTSUSetDtcInitial(&dtc_info_ctsu_wr, &dtc_info_ctsu_rd, g_write_buf, g_cntrdummy, g_cntrdata, CTSU_DRIVER_MUTUAL);
    CTSUStartSetup();
    CTSUSetWriteBuffer();
    CTSUParameterBufInit();                            /* Prameter Buff initialaize    */
    g_ctsu_soft_mode = CTSU_FINISH_MODE;
    CtsuSetTrackingTiming(DF_TRACKING_TIME);           /* Tracking timing              */
    CtsuSetAutoTuningOnOff(AT_INITIAL_START);          /* Auto Tuning initial mode     */
}

/***********************************************************************************************************************
* Function Name: CTSUInitialRegisterValueStorage
* Description  : CTSU measurement Initial register value storage
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUInitialRegisterValueStorage(void)
{
    g_ctsucr1_param.hard_macro_power_sw       = DF_CTSUPON;
    g_ctsucr1_param.lpf_charge_sw             = DF_CTSUCSW;
    g_ctsucr1_param.analogue_signal_mode      = DF_CTSUATUNE0;
    g_ctsucr1_param.analogue_output_mode      = DF_CTSUATUNE1;
    g_ctsucr1_param.ctsu_count_source         = DF_CTSUCLK;
    g_ctsucr1_param.measure_mode              = DF_CTSUMD;

    g_ctsudclkc_param.diffusion_clock_mode    = DF_CTSUSSMOD;
    g_ctsudclkc_param.diffusion_clock_control = DF_CTSUSSCNT;

    g_ctsusdprs_param.drive_pulse_cycle       = DF_CTSUPRRATIO;
    g_ctsusdprs_param.drive_pulse_mode        = DF_CTSUPRMODE;
    g_ctsusdprs_param.sensor_edge_control     = DF_CTSUSOFF;

    g_ctsu_wait_time = DF_CTSUSST;

    g_ctsu_chanel_enable = DF_CTSUCHAC0 | (DF_CTSUCHAC1 << 8);

    if (0 == g_ctsucr1_param.measure_mode)
    {
        g_ctsu_measure_chanel = DF_CTSUMCH0;
    }
    else
    {
        //g_ctsu_measure_chanel = 0x00;
    }
    g_ctsu_chanel_txrx = DF_CTSUCHTRC0 | ( DF_CTSUCHTRC1 <<8 );
}

/***********************************************************************************************************************
* Function Name: CTSUFunctionPinControl
* Description  : CTSU measurement pin function setting function
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUFunctionPinControl(void)
{
    /* Port functon change protect off setting */
    MPC.PWPR.BIT.B0WI  = OFF;
    MPC.PWPR.BIT.PFSWE = ON;

    /* Pin function is set in touch sensor */
    if (1 == DF_ENABLE_TS00)
    {
        MPC.P07PFS.BYTE = P07PFS_TS0;
        PORT0.PMR.BIT.B7 = 1;
    }
    else
    {
        PORT0.PODR.BIT.B7 = 0;
        PORT0.PDR.BIT.B7  = 1;
    }

    if (1 == DF_ENABLE_TS01)
    {
        MPC.P04PFS.BYTE  = P04PFS_TS1;
        PORT0.PMR.BIT.B4 = 1;
    }
    else
    {
        PORT0.PODR.BIT.B4 = 0;
        PORT0.PDR.BIT.B4  = 1;
    }

    if (1 == DF_ENABLE_TS02)
    {
        MPC.P02PFS.BYTE  = P02PFS_TS2;
        PORT0.PMR.BIT.B2 = 1;
    }
    else
    {
        PORT0.PODR.BIT.B2 = 0;
        PORT0.PDR.BIT.B2  = 1;
    }

    if (1 == DF_ENABLE_TS03)
    {
        MPC.PJ3PFS.BYTE  = PJ3PFS_TS3;
        PORTJ.PMR.BIT.B3 = 1;
    }
    else
    {
        PORTJ.PODR.BIT.B3 = 0;
        PORTJ.PDR.BIT.B3  = 1;
    }

    if (1 == DF_ENABLE_TS04)
    {
        MPC.P25PFS.BYTE  = P25PFS_TS4;
        PORT2.PMR.BIT.B5 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B5 = 0;
        PORT2.PDR.BIT.B5  = 1;
    }

    if (1 == DF_ENABLE_TS05)
    {
        MPC.P24PFS.BYTE  = P24PFS_TS5;
        PORT2.PMR.BIT.B4 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B4 = 0;
        PORT2.PDR.BIT.B4  = 1;
    }

    if (1 == DF_ENABLE_TS06)
    {
        MPC.P23PFS.BYTE  = P23PFS_TS6;
        PORT2.PMR.BIT.B3 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B3 = 0;
        PORT2.PDR.BIT.B3  = 1;
    }

    if (1 == DF_ENABLE_TS07)
    {
        MPC.P22PFS.BYTE  = P22PFS_TS7;
        PORT2.PMR.BIT.B2 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B2 = 0;
        PORT2.PDR.BIT.B2  = 1;
    }

    if (1 == DF_ENABLE_TS08)
    {
        MPC.P21PFS.BYTE  = P21PFS_TS8;
        PORT2.PMR.BIT.B1 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B1 = 0;
        PORT2.PDR.BIT.B1  = 1;
    }

    if (1 == DF_ENABLE_TS09)
    {
        MPC.P20PFS.BYTE  = P20PFS_TS9;
        PORT2.PMR.BIT.B0 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B0 = 0;
        PORT2.PDR.BIT.B0  = 1;
    }

    if (1 == DF_ENABLE_TS10)
    {
        MPC.P27PFS.BYTE  = P27PFS_TS10;
        PORT2.PMR.BIT.B7 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B7 = 0;
        PORT2.PDR.BIT.B7  = 1;
    }

    if (1 == DF_ENABLE_TS11)
    {
        MPC.P32PFS.BYTE  = P32PFS_TS11;
        PORT3.PMR.BIT.B2 = 1;
    }
    else
    {
        PORT3.PODR.BIT.B2 = 0;
        PORT3.PDR.BIT.B2  = 1;
    }

    if (0 != SUM_TS)
    {
        MPC.P26PFS.BYTE  = P26PFS_TSCAP;
        PORT2.PMR.BIT.B6 = 1;
    }
    else
    {
        PORT2.PODR.BIT.B6 = 0;
        PORT2.PDR.BIT.B6  = 1;
    }

    /* Sensor drive pulse output setting        */
#ifdef DRIVE_PULSE_DEBUG
    SYSTEM.PRCR.WORD  = 0xA5FF;
    SYSTEM.CKOCR.WORD = 0x0800;        /* CTSU CLKOUT */
    MPC.P15PFS.BYTE = P15PFS_DEGUG;
#endif

    /* Sensor drive pulse output setting        */
#ifdef DRIVE_PULSE_DEBUG
    PORT1.PMR.BIT.B5 = ON;
#endif
}

/***********************************************************************************************************************
* Function Name: CTSUInitialSetup
* Description  : This function implements main function.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUStartSetup(void)
{
    /* set Max key for using Physical driver */
    g_max_key = MEASURE_NUM;

    /* Operation mode Register change protect off setting */
    SYSTEM.PRCR.WORD = PRCR1_ENA;
    SYSTEM.MSTPCRD.BIT.MSTPD10 = OFF;

    /* CTSU hard macro power supply switch change process call */
    CTSUSetPowerSupplyEnable(g_ctsucr1_param.hard_macro_power_sw);

    /* CTSU LPF capacitance charge switch change process call */
    CTSUSetLpfChargingControl(g_ctsucr1_param.lpf_charge_sw);

    /* CTSU analog adjustment Signal0 set process call */
    CTSUSetLowPowControl(g_ctsucr1_param.analogue_signal_mode);

    /* CTSU analog adjustment Signal1 set  process call */
    CTSUSetIcoCurrentAttenuator(g_ctsucr1_param.analogue_output_mode);

    /* CTSU count Source select process call */
    CTSUSetCountSource(g_ctsucr1_param.ctsu_count_source);

    /* CTSU measurement mode select process call */
    CTSUSetMeasurementMode(g_ctsucr1_param.measure_mode);

    /* CTSU Sensor Drive Pulse Spectrum Diffusion Setting Register (CTSUSDPRS) */
    CTSUSetSensorDrivePulseSpectrumDiffusion(g_ctsusdprs_param.drive_pulse_cycle, g_ctsusdprs_param.drive_pulse_mode, g_ctsusdprs_param.sensor_edge_control);

    /* CTSU diffusion clock mode and oscillation frequency select process call */
    CTSUSetDiffusionClockModeSelect(g_ctsudclkc_param.diffusion_clock_mode, g_ctsudclkc_param.diffusion_clock_control);

    /* CTSU sensor wait time set process call */
    CTSUSetSensorStabilizationWaitTime(g_ctsu_wait_time);

    /* CTSU channel enable set process call */
    CTSUSetChannelEnableControl(g_ctsu_chanel_enable);

    /* CTSU measurement channel set process call */
    CTSUSetMeasurementChannel(g_ctsu_measure_chanel);

    /* CTSU Channel transmit/receive control process call */
    CTSUSetChannelTransmitReceiveControl(g_ctsu_chanel_txrx);
}

/***********************************************************************************************************************
* Function Name: CTSUSetWriteBuffer
* Description  : set DTC write buffer data
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void CTSUSetWriteBuffer(void)
{
    uint8_t loop_num;
    uint8_t pt;

    for (loop_num = 0, pt=0; loop_num < MEASURE_NUM; loop_num++)
    {
        /* CTSU Spectrum Diffusion Control Register initial value  */
        g_write_buf[pt]   = ctsusscbuff[loop_num];
        /* CTSU Sensor Offset Register 0 initial value  */
        g_write_buf[pt+1] = ctsuso0buff[loop_num];
        /* CTSU Sensor Offset Register 1 initial value  */
        g_write_buf[pt+2] = ctsuso1buff[loop_num];
        /* next buffer pointer set */
        pt = (uint8_t)(pt + 3);
    }
}

/***********************************************************************************************************************
* Function Name: CTSUParameterBufInit
* Description  : CTSU S/W parameter initialization function
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void CTSUParameterBufInit(void)
{
    uint8_t column_ts;
    uint8_t row_ts;
    uint8_t loop;
    uint8_t pt;

#ifdef KEY_USE
    loop = 0;
    for (row_ts = 0; row_ts < RECEIVE_NUM; row_ts++)
    {
        for (column_ts = 0; column_ts < SEND_NUM; column_ts++)
        {
            g_nthr[column_ts][row_ts]                  = thrbuff[loop];
            g_nhys[column_ts][row_ts]                  = hysbuff[loop];
            g_virtual_touch_info[column_ts][row_ts]    = 0;
            g_real_touch_info[column_ts][row_ts]       = 0;
            g_touch_result[column_ts][row_ts]          = 0;
            BDATA[column_ts][row_ts]                   = 0;
            g_key_onoff[ column_ts ][ row_ts ]         = 0;
            g_drift_permission[ column_ts ][ row_ts ]  = 1;
            loop = (uint8_t)(loop + 1);
        }
    }

    /* ===== Multi Touch Cancel  ===== */
    g_sensor_function.value        = 0x00;
    g_sensor_function.function.mtc = DF_MTC_ONOFF;            /* Multi Touch Cancel off */
    mtc_start_ch                   = DF_MTC_START_TS;
    mtc_end_ch                     = DF_MTC_END_TS;

    /* ===== Total touch/non tount function setting  ===== */
    g_touch_cmp_val     = DF_ACD_ON;
    g_non_touch_cmp_val = DF_ACD_OFF;

    /* ===== Drift correction function setting  ===== */
    g_sensor_function.function.drift = DF_DC_FUNCTION;    // Drift on
    g_dci = DF_DCI;

    /* ===== MSA function setting ===== */
    g_msa = DF_MSA;

    if (g_touch_cmp_val)
    {
        g_sensor_function.function.acd0 = ON;
    }

    if (g_non_touch_cmp_val)
    {
        g_sensor_function.function.acd1 = ON;
    }

    if (g_msa)
    {
        g_sensor_function.function.msa = ON;
    }

    g_data_tim       = 0;
    g_calib_data_num = 0;

    /* ===== Measure Calibration function setting ===== */
    g_ctsu_flag.bit.msr_calib = 1;                        /* Request flag set */
#else /* KEY_USE */
    g_ctsu_flag.bit.msr_calib = 0;                        /* Request flag set */
#endif /* KEY_USE */

    /* ===== Initialize index table for conversion ts-number to SUM_TS index ===== */
    for (loop = 0, pt = 0; loop < MAX_TS; loop++)
    {
        if (0 != (g_ctsu_chanel_enable & (1 << loop)))
        {
            g_index_sensor[loop] = pt++;
        }
        else
        {
            g_index_sensor[loop] = 0xff;
        }
    }
}
