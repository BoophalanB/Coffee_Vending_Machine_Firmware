/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_serial_control.c
* Version      : 1.00
* Description  : This is the serial command code.
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

#define __R_SERIAL_COMMAND_C__
/***********************************************************************************************************************
Includes   <System Includes> , "Project Includes"
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
/* Start user code for include. Do not edit comment generated here */
#include "r_cg_userdefine.h"
//#include "r_usb_ctypedef.h"
#include "r_serial_control.h"
#include "r_ctsu_common_control.h"
#include "r_ctsu_parameter_common.h"
#include "r_ctsu_setup.h"

#ifdef MUTUAL_FUNC_USE
    #include "r_ctsu_physical_driver_mu.h"
#else
    #include "r_ctsu_physical_driver.h"
#endif    //] MUTUAL_FUNC_USE

#include "r_ctsu_key_control.h"
#include "r_ctsu_slider_control.h"
#include "r_ctsu_wheel_control.h"
#include "r_ctsu_user_api.h"

/* End user code. Do not edit comment generated here */

#ifdef WORKBENCH_COMMAND_USE    //[
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#define TRUE                (1u)
#define FALSE               (0u)

#ifdef    MUTUAL_FUNC_USE
#define BUF_SIZE_SND_TMP    (4/* HEADER */ +                                            \
                             4/* BDATA */ * sizeof(uint16_t)/* WORD */ +                                \
                             2/* CV + RV */ * sizeof(uint16_t)/* WORD */ * MEASURE_NUM +                    \
                             1/* SLIDER POSITION */ * sizeof(uint16_t)/* WORD */ * DF_SLIDER_NUMBER +    \
                             1/* WHEEL POSITION */ * sizeof(uint16_t)/* WORD */ * DF_WHEEL_NUMBER +        \
                             2/* RETURN VALUE */)
#else
#define BUF_SIZE_SND_TMP    (4/* HEADER */ +                                            \
                             4/* BDATA */ * sizeof(uint16_t)/* WORD */ +                                \
                             2/* CV + RV */ * sizeof(uint16_t)/* WORD */ * MAX_TS +                    \
                             1/* SLIDER POSITION */ * sizeof(uint16_t)/* WORD */ * DF_SLIDER_NUMBER +    \
                             1/* WHEEL POSITION */ * sizeof(uint16_t)/* WORD */ * DF_WHEEL_NUMBER +        \
                             2/* RETURN VALUE */)
#endif
#define BUF_SIZE_RCV        (4/* HREADR */ + 16)
#define HEAD_SIZE           (4)
#define MONITOR_CMD_SIZE    (24)

#define BUF_SIZE_SND        (BUF_SIZE_SND_TMP + BUF_SIZE_SND_TMP % 4)

// command definition
#define CMD_PROFILE    (0x00u)
#define CMD_MEASURE    (0x01u)
#define CMD_PARAMETER  (0x02)
#define CMD_REGISTER   (0x03)
#define CMD_UTILITY    (0x04)
#define CMD_RESERVED   (0x05)

// Workbench ---> Touch sensor
#define CMD_RQ    (0x00u)
#define CMD_READ  (0x00)
#define CMD_WRITE (0x40)

#define CMD_RQ_PROFILE_READ     (CMD_RQ | CMD_READ  | CMD_PROFILE)      // sensor data read request
#define CMD_RQ_PROFILE_WRITE    (CMD_RQ | CMD_WRITE | CMD_PROFILE)      // sensor data read request
#define CMD_RQ_MEASURE_READ     (CMD_RQ | CMD_READ  | CMD_MEASURE)      // sensor data write request
#define CMD_RQ_MEASURE_WRITE    (CMD_RQ | CMD_WRITE | CMD_MEASURE)      // sensor data write request
#define CMD_RQ_PARAMETER_READ   (CMD_RQ | CMD_READ  | CMD_PARAMETER)    // usb i/f board status getting request
#define CMD_RQ_PARAMETER_WRITE  (CMD_RQ | CMD_WRITE | CMD_PARAMETER)    // usb i/f board status getting request
#define CMD_RQ_REGISTER_READ    (CMD_RQ | CMD_READ  | CMD_REGISTER)     // usb i/f board status control request
#define CMD_RQ_REGISTER_WRITE   (CMD_RQ | CMD_WRITE | CMD_REGISTER)     // usb i/f board status control request
#define CMD_RQ_UTILITY_READ     (CMD_RQ | CMD_READ  | CMD_UTILITY)      // usb i/f board read request
#define CMD_RQ_UTILITY_WRITE    (CMD_RQ | CMD_WRITE | CMD_UTILITY)      // usb i/f board read request

// Workbench <=== Touch sensor 
#define CMD_RE    (0x80u)

#define CMD_RE_SENSOR_READ   (CMD_RE | CMD_SENSOR_READ)  // sensor data read response
#define CMD_RE_SENSOR_WRITE  (CMD_RE | CMD_SENSOR_WRITE) // sensor data write response
#define CMD_RE_IF_STATE      (CMD_RE | CMD_IF_STATE)     // usb i/f board status getting response
#define CMD_RE_IF_CONTROL    (CMD_RE | CMD_IF_CONTROL)   // usb i/f board status control response
#define CMD_RE_IF_READ       (CMD_RE | CMD_IF_READ)      // usb i/f board read response
#define CMD_RE_IF_WRITE      (CMD_RE | CMD_IF_WRITE)     // usb i/f board write response

#define CMD_UNKNOWN    (0xff)        // unknown command

#define CMD_RESULT_SUCCESS    (0x00)
#define CMD_RESULT_FAILURE    (0xff)

#define CMD_UTILITY_PARAM_UPDATE    (1)
#define CMD_UTILITY_PARAM_RESET     (2)

#define CMD_UTILITY_UPDATE_FINISH   (0)
#define CMD_UTILITY_UPDATE_RUNNING  (1)

#define CMD_UTILITY_RESET_FINISH    (0)
#define CMD_UTILITY_RESET_RUNNING   (1)

#if 0
 communication time-out default value (No.15)
#define SERIAL_TIMEOUT        (250)        // two sec (main cycle 8 ms * 250 = 2000ms)
#endif

#define COMMAND_MODE_SERIAL (0)    // Serial port communication
#define COMMAND_MODE_IDE    (1)    // Cube suite+/e2studio communication

#if (ADD_TIME == 4) 
#define WAIT_TIME    ADD4_WAIT_FREQUENCY * TOUCH_MEASUREMENT_CYCLE_MS   /* 20msec:840         40msec:1680        */
#elif ( ADD_TIME == 5 )
#define WAIT_TIME    ADD5_WAIT_FREQUENCY * TOUCH_MEASUREMENT_CYCLE_MS   /* 20msec:1120        40msec:2240        */
#elif ( ADD_TIME == 6 )
#define WAIT_TIME    ADD6_WAIT_FREQUENCY * TOUCH_MEASUREMENT_CYCLE_MS   /* 20msec:1340        40msec:2680        */
#elif ( ADD_TIME == 7 )
#define WAIT_TIME    ADD7_WAIT_FREQUENCY * TOUCH_MEASUREMENT_CYCLE_MS   /* 20msec:1560        40msec:3120        */
#elif ( ADD_TIME == 8 )
#define WAIT_TIME    ADD8_WAIT_FREQUENCY * TOUCH_MEASUREMENT_CYCLE_MS   /* 20msec:1800        40msec:3600        */
#else
#error    "Illagal additional time is specified. Check Macro definition ADD_TIME."
#endif

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef    unsigned char    BOOL;

typedef union type_com_data_rd
{
    struct
    {
        uint8_t main;
        uint8_t sub;
        uint8_t size;
        uint8_t sum;
        uint8_t data[BUF_SIZE_RCV - HEAD_SIZE];
    } fmt;
    uint8_t byte_acs[BUF_SIZE_RCV];
} com_data_rd_t;

typedef union type_com_data_tx
{
    uint32_t dw_acs[BUF_SIZE_SND / 4];
    struct
    {
        uint8_t main;
        uint8_t sub;
        uint8_t size;
        uint8_t sum;
        uint8_t data[BUF_SIZE_SND - HEAD_SIZE];
    } fmt;
    uint8_t byte_acs[BUF_SIZE_SND];
}com_data_tx_t;

typedef struct type_monitor_command
{
    uint8_t command[MONITOR_CMD_SIZE];
    uint8_t size;
} monitor_command_t;

/***********************************************************************************************************************
Exported global variables (to be accessed by other files);
***********************************************************************************************************************/
#ifdef SLIDER_USE
    extern uint8_t                g_slider_number;
    extern uint8_t                g_slider_sensor_number[];
    extern slider_wheel_info_t    g_sliderInfo[];
#endif
#ifdef WHEEL_USE
    extern uint8_t                g_wheel_number;
    extern uint8_t                g_wheel_sensor_number[];
    extern slider_wheel_info_t    g_wheelInfo[];
#endif

/***********************************************************************************************************************
Private global variables and functions
***********************************************************************************************************************/
uint8_t    g_write_request;
#ifndef    MUTUAL_FUNC_USE
uint8_t    g_key_index[MAX_TS];
#endif    // MUTUAL_FUNC_USE
com_data_rd_t com_data;    /* Received data buffer */
com_data_tx_t rsp_cmd;    /* Transmit data buffer */
monitor_command_t monitor_command;    /* Monitor commands buffer */
BOOL        serial_transmit_ready;
uint8_t    command_mode;
uint8_t        store_value_acd0;
uint8_t        store_value_acd1;
uint16_t    store_value_msa;

static void CreateResponceCommand(com_data_tx_t * pcmd);
static uint8_t SetChecksum(uint8_t main, uint8_t sub, uint8_t size, uint8_t * pdata);
static BOOL IsRightChecksum(com_data_rd_t * pcmd);
static uint8_t GetSensorValue(uint8_t code, uint16_t channel, uint16_t * pval);
//static uint8_t SetSensorValue(uint8_t code, uint8_t channel, uint16_t value, uint8_t * extraflag);
static void SensorProfileReadResponse(com_data_tx_t * pcmd, uint16_t channel);
//static void SensorProfileWriteResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorMeasureReadResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorParameterReadResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorParameterWriteResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorRegisterReadResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorRegisterWriteResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorUtilityReadResponse(com_data_tx_t * pcmd, uint16_t channel);
static void SensorUtilityWriteResponse(com_data_tx_t * pcmd, uint16_t channel);
static void    InitKeyIndexTable();

/***********************************************************************************************************************
* Function Name: SerialCommandInitial
* Description  : Serial command initialization
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void SerialCommandInitial(void)
{
    serial_transmit_ready = FALSE;
    command_mode          = COMMAND_MODE_SERIAL;
    InitKeyIndexTable();
    
    store_value_acd0      = DF_ACD_ON;
    store_value_acd1      = DF_ACD_OFF;
    store_value_msa       = DF_MSA;
}

/***********************************************************************************************************************
* Function Name: Serial command receive
* Description  : SerialCommandReceive
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
uint8_t    SerialCommandReceive(uint8_t * value, uint16_t length)
{
    uint8_t result;
    uint8_t i;

    result    = FALSE;
    for (i = 0; i < length; i++)
    {
        com_data.byte_acs[i]    = value[i];
    }
    if (FALSE != IsRightChecksum(&com_data))
    {
        serial_transmit_ready    = TRUE;

        result    = TRUE;
    }
    return result;
}

uint8_t    GetReplayMessage(uint8_t * value, uint16_t * length)
{
    BOOL    result;
    uint8_t i;
    uint8_t size;

    result    = FALSE;
    if (serial_transmit_ready)
    {
        /* preparing transmittion buffer */
        CreateResponceCommand(&rsp_cmd);

        /* UARTi transmission data is set */
        *length    =
        size    = (uint8_t)(rsp_cmd.fmt.size + HEAD_SIZE);
        for (i = 0; i < size; i++)
        {
            value[i]    = rsp_cmd.byte_acs[i];
        }
        serial_transmit_ready    = FALSE;
        result                   = TRUE;
    }
    return result;
}

/***********************************************************************************************************************
* Function Name: SerialTransmissionExecute
* Description  : Executing the serial communication
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void    PrepareReplayMessage()
{
    if (serial_transmit_ready)
    {
        if (COMMAND_MODE_IDE == command_mode)
        {
            /* preparing transmittion buffer */
            CreateResponceCommand(&rsp_cmd);
        }
        serial_transmit_ready    = FALSE;
    }
}

/***********************************************************************************************************************
* Function Name: TouchParamUpdate
* Description  : Update Touch parameters according to a request from Workbench
* Arguments    : none
* Return Value : none
***********************************************************************************************************************/
void TouchParamUpdate()
{
#if    0
    if (g_write_request != 0)
    {
        if (g_write_request == 2)
        {
            TouchParamInit();
        }
        TouchDataInitial();
        SerialCommandInitial();
        g_write_request    = 0;
    }
#endif
}

/***********************************************************************************************************************
* Function Name: CreateResponceCommand
* Description  : Create responce command
* Arguments    : pcmd - 
*                    Pointer of command
* Return Value : none
***********************************************************************************************************************/
static void CreateResponceCommand(com_data_tx_t *pcmd)
{
    pcmd->fmt.main = (uint8_t)(com_data.fmt.main | CMD_RE);
    pcmd->fmt.sub  = com_data.fmt.sub;

    switch (com_data.fmt.main)
    {
        case CMD_RQ_PROFILE_READ:
            SensorProfileReadResponse(pcmd, com_data.fmt.data[0]);
            break;
        case CMD_RQ_PROFILE_WRITE:
            break;
        case CMD_RQ_MEASURE_READ:
            SensorMeasureReadResponse(pcmd, com_data.fmt.data[0]);
            break;
/*      case CMD_RQ_MEASURE_WRITE:
            break;                 */
        case CMD_RQ_PARAMETER_READ:
            SensorParameterReadResponse(pcmd, com_data.fmt.data[0]);
            break;
        case CMD_RQ_PARAMETER_WRITE:
            SensorParameterWriteResponse(pcmd, com_data.fmt.data[2]);
            break;
        case CMD_RQ_REGISTER_READ:
            SensorRegisterReadResponse(pcmd, com_data.fmt.data[0]);
            break;
        case CMD_RQ_REGISTER_WRITE:
            SensorRegisterWriteResponse(pcmd, com_data.fmt.data[2]);
            break;
        case CMD_RQ_UTILITY_READ:
            SensorUtilityReadResponse(pcmd, com_data.fmt.data[0]);
            break;
        case CMD_RQ_UTILITY_WRITE:
            SensorUtilityWriteResponse(pcmd, com_data.fmt.data[2]);
            break;
        default:
            pcmd->fmt.size = 1;
            pcmd->fmt.data[0] = CMD_RESULT_FAILURE;
            break;
    }

    pcmd->fmt.sum = SetChecksum(pcmd->fmt.main, pcmd->fmt.sub, pcmd->fmt.size, pcmd->fmt.data);
}

/***********************************************************************************************************************
* Function Name: SetChecksum
* Description  : Set checksum
* Arguments    : main - 
*                    main command id
*                sub - 
*                    sub command id
*                size - 
*                    size of data
*                pdata - 
*                    Pointer of data buffer
* Return Value : sum - 
*                    checksum
***********************************************************************************************************************/
static uint8_t SetChecksum(uint8_t main, uint8_t sub, uint8_t size, uint8_t *pdata)
{
    uint8_t sum;
    uint8_t i;

    sum = (uint8_t)(main + sub + size);
    for (i = 0; i < size; i++)
    {
        sum += pdata[i];
    }

    return sum;
}

/***********************************************************************************************************************
* Function Name: IsRightChecksum
* Description  : Right checksum
* Arguments    : pcmd - 
*                    Pointer of received data
* Return Value : result - 
*                    TRUE , FALSE
***********************************************************************************************************************/
static BOOL IsRightChecksum(com_data_rd_t *pcmd)
{
#if    0
    return TRUE;
#else
    BOOL result;
    uint8_t sum;

    sum = SetChecksum(pcmd->fmt.main, pcmd->fmt.sub, pcmd->fmt.size, pcmd->fmt.data);
    result = FALSE;
    if (pcmd->fmt.sum == sum)
    {
        result = TRUE;
    }
    return result;
#endif
}

#ifdef    KEY_USE
#ifdef    MUTUAL_FUNC_USE
static BOOL    IsSensorKey(uint8_t ts)
{
    BOOL    result;

    result    = FALSE;
    if (ts < MEASURE_NUM)
    {
        result    = TRUE;
    }
    return result;
}
#else    // MUTUAL_FUNC_USE
static BOOL    IsSensorKey(uint8_t ts)
{
    BOOL    result = FALSE;
    uint8_t index;
    uint8_t value;

    index    = 3;
    value    = (uint8_t)(ts - 32);
    if (16 > ts)
    {
        index    = 0;
        value    = ts;
    }
    else if (32 > ts)
    {
        index    = 1;
        value    = (uint8_t)(ts - 16);
    }

    result    = FALSE;
    if (0 != (used_key_func[index] & (1 << value)))
    {
        result    = TRUE;
    }
    return result;
}
#endif    // MUTUAL_FUNC_USE
#endif    // KEY_USE

static void    InitKeyIndexTable()
{
#ifdef    KEY_USE
#ifndef    MUTUAL_FUNC_USE
    uint8_t i;
    uint8_t value;

    value = 0;
    for (i = 0; i < MAX_TS; i++)
    {
        g_key_index[i] = 0xff;
        if (IsSensorKey(i))
        {
            g_key_index[i] = value++;
        }
    }
#endif    // MUTUAL_FUNC_USE
#endif    // KEY_USE
}

#ifdef    MUTUAL_FUNC_USE
static uint16_t    GetTouchSensorResult(uint8_t id)
{
    uint16_t result;
    uint16_t i;
    uint16_t start;
    uint16_t end;
    
    switch (id) {
        case    1:    start = 16;    end = 32;    break;
        case    2:    start = 32;    end = 48;    break;
        case    3:    start = 48;    end = 64;    break;
        default:    start = 0;    end = 16;    break;
    }
    
    result = 0;
    for (i = start; i < end; i++)
    {
        if ((i % SEND_NUM) < SEND_NUM)
        {
            if ((i / SEND_NUM) < RECEIVE_NUM)
            {
                result |= BDATA[i % SEND_NUM][i / SEND_NUM] << (i - start);
            }
        }
    }
    return result;
}
#endif    // MUTUAL_FUNC_USE

/***********************************************************************************************************************
* Function Name: GetSensorValue
* Description  : Get sensor value
* Arguments    : code - 
*                    Where to start looking
*                channel - 
*                    channel data
*                pval - 
*                    Pointer of serial output data
* Return Value : result - 
*                    TRUE , FALSE
***********************************************************************************************************************/
static uint8_t GetSensorValue(uint8_t code, uint16_t channel, uint16_t *pval)
{
    uint8_t result;

    result = TRUE;
    switch (code)
    {
        case 0x00:    // SC
            result    = TRUE;
            *pval    = 0xffff;
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval    = g_diff_scount[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
                if (g_index_sensor[channel] != 0xff)
                {
                    *pval = g_scount[g_index_sensor[channel]];
                }
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x01:    // RV
            result    = TRUE;
            *pval    = 0xffff;
#ifdef    KEY_USE
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval = g_nref[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
                if (IsSensorKey(channel))
                {
                    *pval = g_nref[g_key_index[channel]];
                }
            }
#endif    // MUTUAL_FUNC_USE
#endif    // KEY_USE
            break;
        case 0x02:    // RC
            result    = TRUE;
            *pval    = 0xffff;
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval = g_diff_rcount[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
                if (0xff != g_index_sensor[channel])
                {
                    *pval = g_rcount[g_index_sensor[channel]];
                }
            }
#endif    // MUTUAL_FUNC_USE
            break;
//        case 0x03:    // RC
//            break;
        case 0x04:    // SDLPOS
#ifdef    SLIDER_USE
            if (DF_SLIDER_NUMBER > channel)
            {
                *pval = g_sliderInfo[channel].value;
            }
            else
            {
                result    = FALSE;
            }
#endif
            break;
        case 0x05:
#ifdef    WHEEL_USE
            if (DF_WHEEL_NUMBER > channel)
            {
                *pval = g_wheelInfo[channel].value;
            }
            else
            {
                result    = FALSE;
            }
#endif
            break;
        case 0x06:
#ifdef    KEY_USE
    #ifdef    MUTUAL_FUNC_USE
            *pval    = GetTouchSensorResult(0);
    #else    // MUTUAL_FUNC_USE
            *pval    = BDATA[0];
    #endif    // MUTUAL_FUNC_USE
#else    // KEY_USE
            *pval    = 0x00;
#endif    // KEY_USE
            break;
        case 0x07:
#ifdef    KEY_USE
    #ifdef    MUTUAL_FUNC_USE
            *pval    = GetTouchSensorResult(1);
    #else    // MUTUAL_FUNC_USE
        #if    (MAX_TS > 12)
            *pval    = BDATA[1];
        #else
            *pval    = 0x00;
        #endif
    #endif    // MUTUAL_FUNC_USE
#else    // KEY_USE
            *pval    = 0x00;
#endif    // KEY_USE
            break;
        case 0x08:
#ifdef    KEY_USE
    #ifdef    MUTUAL_FUNC_USE
            *pval    = GetTouchSensorResult(2);
    #else    // MUTUAL_FUNC_USE
        #if    (MAX_TS > 24)
            *pval    = BDATA[2];
        #else
            *pval    = 0x00;
        #endif
    #endif    // MUTUAL_FUNC_USE
#else    // KEY_USE
            *pval    = 0x00;
#endif    // KEY_USE
            break;
        case 0x09:
            *pval    = 0;    // No support
            break;
        case 0x0a:    // SCFRST (Sensor counter at 1st measurement)
            result    = FALSE;
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval = g_s_primary[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x0b:    // SCSCND (Sensor counte at 2nd measurement)
            result    = FALSE;
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval = g_s_secondary[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x0c:    // RCFRST (Sensor counter at 1st measurement)
            result    = FALSE;
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval = g_r_primary[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x0d:    // RCSCND (Sensor counte at 2nd measurement)
            result    = FALSE;
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                result    = TRUE;
                *pval = g_r_secondary[channel % SEND_NUM][channel / SEND_NUM];
            }
#else    // MUTUAL_FUNC_USE
            if (MAX_TS > channel)
            {
                result    = TRUE;
                *pval    = 0xffff;
            }
#endif    // MUTUAL_FUNC_USE
            break;            
        default:
            result    = FALSE;
            break;
    }
    return result;
}

/***********************************************************************************************************************
* Function Name: SensorProfileReadResponse
* Description  : Sensor read response
* Arguments    : pcmd - 
*                    Pointer of transfer data
*                channel - 
*                    channel data
* Return Value : none
***********************************************************************************************************************/
static void SensorProfileReadResponse(com_data_tx_t *pcmd, uint16_t channel)
{
    uint16_t value;
    uint8_t status;

    pcmd->fmt.size = 3;
    pcmd->fmt.data[0] = CMD_RESULT_FAILURE;    /* Error status */
    pcmd->fmt.data[1] = 0;
    pcmd->fmt.data[2] = 0;
    value = 0;

    if (pcmd->fmt.sub <= 0xff)
    {
        status = CMD_RESULT_SUCCESS;
        switch (pcmd->fmt.sub)
        {
            case 0x00:
                /* ID */
                value = DF_CHIP_ID;
                break;
            case 0x01:
                /* VER1(Version Lower) */
                value = DF_VERSIONu;
                break;
            case 0x02:
                /* VER2(Version Upper) */
                value = DF_VERSIONd;
                break;
            case 0x03:
                /* PROFILE */
                value = DF_PROFILE;
                break;
            default:
                break;
        }

        /* Normal status */
        pcmd->fmt.data[0] = status;
        pcmd->fmt.data[1] = (uint8_t)(value & 0xff);
        pcmd->fmt.data[2] = (uint8_t)(value >> 8);
    }
}

/***********************************************************************************************************************
* Function Name: SensorMeasureReadResponse
* Description  : Sensor write response
* Arguments    : pcmd - 
*                    Pointer of transfer data
*                channel - 
*                    channel data
* Return Value : none
***********************************************************************************************************************/
static void SensorMeasureReadResponse(com_data_tx_t *pcmd, uint16_t channel)
{
    uint16_t value;

    pcmd->fmt.size = 1;
    pcmd->fmt.data[0] = CMD_RESULT_FAILURE;    /* Error status */
    value = 0;

    if (pcmd->fmt.sub <= 0xff)
    {
        if (GetSensorValue(pcmd->fmt.sub, channel, &value) != FALSE)
        {
            pcmd->fmt.size = 3;
            pcmd->fmt.data[0] = CMD_RESULT_SUCCESS;
            pcmd->fmt.data[1] = (uint8_t)(value & 0xff);
            pcmd->fmt.data[2] = (uint8_t)(value >> 8);
        }
    }
}

#ifdef    SLIDER_USE
static uint8_t    GetSliderSensorNumber(uint8_t id, uint8_t no, uint16_t * pval)
{
    uint8_t    result;
    
    result    = CMD_RESULT_FAILURE;
    if (DF_SLIDER_NUMBER > id)
    {
        result    = CMD_RESULT_SUCCESS;
        *pval    = g_sliderInfo[id].ts[no];
    }
    return result;
}
#endif    // SLIDER_USE

#ifdef    WHEEL_USE
static uint8_t    GetWheelSensorNumber(uint8_t id, uint8_t no, uint16_t * pval)
{
    uint8_t    result;
    
    result    = CMD_RESULT_FAILURE;
    if (DF_WHEEL_NUMBER > id)
    {
        result    = CMD_RESULT_SUCCESS;
        *pval    = g_wheelInfo[id].ts[no];
    }
    return result;
}
#endif    // WHEEL_USE

/***********************************************************************************************************************
* Function Name: SensorParameterReadResponse
* Description  : State response
* Arguments    : pcmd - 
*                    Pointer of transfer data
* Return Value : none
***********************************************************************************************************************/
static void SensorParameterReadResponse(com_data_tx_t * pcmd, uint16_t channel)
{
    uint16_t value;
    uint8_t  status;

    pcmd->fmt.size = 1;
    pcmd->fmt.data[0] = CMD_RESULT_FAILURE;    /* Error status */
    value = 0;

    status = CMD_RESULT_SUCCESS;
    switch (pcmd->fmt.sub)
    {
        case 0x00:
#ifdef    KEY_USE
            if (g_sensor_function.function.drift)
            {
                value |= 0x0001;
            }
            if (g_sensor_function.function.msa)
            {
                value |= 0x0002;
            }
            if (g_sensor_function.function.acd0)
            {
                value |= 0x0004;
            }
            if (g_sensor_function.function.acd1)
            {
                value |= 0x0008;
            }
            if (g_sensor_function.function.mtc)
            {
                value |= 0x0010;
            }
#else    // KEY_USE
            value    = 0;
#endif    // KEY_USE
            break;
        case 0x01:
#ifdef    KEY_USE
            value = g_dci;
#endif    // KEY_USE
            break;
        case 0x02:
#ifdef    KEY_USE
            value    = store_value_msa;
#endif    // KEY_USE
            break;
        case 0x03:
#ifdef    KEY_USE
            value    = store_value_acd0;
#endif    // KEY_USE
            break;
        case 0x04:
#ifdef    KEY_USE
            value    = store_value_acd1;
#endif    // KEY_USE
            break;
        case 0x05:
#ifdef    KEY_USE
            value    = mtc_start_ch;
#endif    // KEY_USE
            break;
        case 0x06:
#ifdef    KEY_USE
            value    = mtc_end_ch;
#endif    // KEY_USE
            break;
        case 0x07:
#ifdef    KEY_USE
            value    = Athr;
#endif    // KEY_USE
            break;
        case 0x08:
            value    = 0xffff;
#ifdef    KEY_USE
            if (IsSensorKey(channel))
            {
#ifdef    MUTUAL_FUNC_USE
                value    = g_nthr[channel % SEND_NUM][channel / SEND_NUM];
#else    // MUTUAL_FUNC_USE
                value    = g_nthr[g_key_index[channel]];
#endif    // MUTUAL_FUNC_USE
            }
#endif    // KEY_USE
            break;
        case 0x09:
            value    = 0xffff;
#ifdef    KEY_USE
            if (IsSensorKey(channel))
            {
#ifdef    MUTUAL_FUNC_USE
                value    = g_nhys[channel % SEND_NUM][channel / SEND_NUM];
#else    // MUTUAL_FUNC_USE
                value    = g_nhys[g_key_index[channel]];
#endif    // MUTUAL_FUNC_USE
            }
#endif    // KEY_USE
            break;
#ifdef    SLIDER_USE
        case 0x0a:
            value    = DF_SLIDER_NUMBER;
            break;
        case 0x0b:
            if (DF_SLIDER_NUMBER > channel)
            {
                value    = g_sliderInfo[channel].num;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
        case 0x0c:
            status    = GetSliderSensorNumber(channel, 0, &value);
            break;
        case 0x0d:
            status    = GetSliderSensorNumber(channel, 1, &value);
            break;
        case 0x0e:
            status    = GetSliderSensorNumber(channel, 2, &value);
            break;
        case 0x0f:
            status    = GetSliderSensorNumber(channel, 3, &value);
            break;
        case 0x10:
            status    = GetSliderSensorNumber(channel, 4, &value);
            break;
        case 0x11:
            status    = GetSliderSensorNumber(channel, 5, &value);
            break;
        case 0x12:
            status    = GetSliderSensorNumber(channel, 6, &value);
            break;
        case 0x13:
            status    = GetSliderSensorNumber(channel, 7, &value);
            break;
        case 0x14:
            status    = GetSliderSensorNumber(channel, 8, &value);
            break;
        case 0x15:
            status    = GetSliderSensorNumber(channel, 9, &value);
            break;
        case 0x16:
            if (DF_SLIDER_NUMBER > channel)
            {
                value    = g_sliderInfo[channel].resolution;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
        case 0x17:
            if (DF_SLIDER_NUMBER > channel)
            {
                value    = g_sliderInfo[channel].threshold;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
#else    // SLIDER_USE
        case 0x0a:
            value = 0;
            break;
#endif    // SLIDER_USE
#ifdef    WHEEL_USE
        case 0x18:
            //value = g_wheel_number;
            value    = DF_WHEEL_NUMBER;
            break;
        case 0x19:
            if (DF_WHEEL_NUMBER > channel)
            {
                value    = g_wheelInfo[channel].num;
            }
            else                            status    = CMD_RESULT_FAILURE;
            break;
        case 0x1a:
            status = GetWheelSensorNumber(channel, 0, &value);
            break;
        case 0x1b:
            status = GetWheelSensorNumber(channel, 1, &value);
            break;
        case 0x1c:
            status = GetWheelSensorNumber(channel, 2, &value);
            break;
        case 0x1d:
            status = GetWheelSensorNumber(channel, 3, &value);
            break;
        case 0x1e:
            status = GetWheelSensorNumber(channel, 4, &value);
            break;
        case 0x1f:
            status = GetWheelSensorNumber(channel, 5, &value);
            break;
        case 0x20:
            status = GetWheelSensorNumber(channel, 6, &value);
            break;
        case 0x21:
            status = GetWheelSensorNumber(channel, 7, &value);
            break;
        case 0x22:
            status = GetWheelSensorNumber(channel, 8, &value);
            break;
        case 0x23:
            status = GetWheelSensorNumber(channel, 9, &value);
            break;
        case 0x24:
            if (DF_WHEEL_NUMBER > channel)
            {
                value    = g_wheelInfo[channel].resolution;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
        case 0x25:
            if (DF_WHEEL_NUMBER > channel)
            {
                value    = g_wheelInfo[channel].threshold;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
#else    // WHEEL_USE
        case 0x18:
            value = 0;
            break;
#endif    // WHEEL_USE
        default:
            status = CMD_RESULT_FAILURE;
            break;
    }

    if (status == CMD_RESULT_SUCCESS)
    {
        pcmd->fmt.size        = 3;
        pcmd->fmt.data[0]    = status;
        pcmd->fmt.data[1]    = (uint8_t)(value & 0xff);
        pcmd->fmt.data[2]    = (uint8_t)(value >> 8);
    }
}

static void SensorParameterWriteResponse(com_data_tx_t * pcmd, uint16_t channel)
{
    uint16_t value;
    uint8_t  status;

    pcmd->fmt.size = 1;
    pcmd->fmt.data[0] = CMD_RESULT_FAILURE;    /* Error status */
    value = ((uint16_t)com_data.fmt.data[1] << 8) + com_data.fmt.data[0];
    status = CMD_RESULT_SUCCESS;

    switch (pcmd->fmt.sub)
    {
        case 0x00:
#ifdef    KEY_USE
            g_sensor_function.value    = 0x00;
            
            // Drift correction
            if (value & 0x0001)
            {
                g_sensor_function.function.drift    = ON;
            }
            
            // MSA
            if (value & 0x0002)
            {
                g_sensor_function.function.msa        = ON;
            }
            if (g_sensor_function.function.msa)
            {
                g_msa    = store_value_msa;
            }
            else
            {
                g_msa    = 0;
            }
            
            // ACD Off -> On
            if (value & 0x0004)
            {
                g_sensor_function.function.acd0        = ON;
            }
            if (g_sensor_function.function.acd0)
            {
                g_touch_cmp_val    = store_value_acd0;
            }
            else
            {
                g_touch_cmp_val    = 0;
            }
            
            // ACD On -> Off
            if (value & 0x0008) {
                g_sensor_function.function.acd1        = ON;
            }
            if (g_sensor_function.function.acd1)
            {
                g_non_touch_cmp_val    = store_value_acd1;
            }
            else
            {
                g_non_touch_cmp_val    = 0;
            }
            
            // Multi-touch canceller
            if (value & 0x0010)
            {
                g_sensor_function.function.mtc        = ON;
            }
#endif    // KEY_USE
            break;
        case 0x01:
#ifdef    KEY_USE
            g_dci    = value;
#endif    // KEY_USE
            break;
        case 0x02:
#ifdef    KEY_USE
            store_value_msa    = value;
            if (g_sensor_function.function.msa)
            {
                g_msa    = store_value_msa;
            }
            else
            {
                g_msa    = 0;
            }
#endif    // KEY_USE
            break;
        case 0x03:
#ifdef    KEY_USE
            store_value_acd0    = value;
            if (g_sensor_function.function.acd0)
            {
                g_touch_cmp_val    = store_value_acd0;
            }
            else
            {
                g_touch_cmp_val    = 0;
            }
#endif    // KEY_USE
            break;
        case 0x04:
#ifdef    KEY_USE
            store_value_acd1    = value;
            if (g_sensor_function.function.acd1)
            {
                g_non_touch_cmp_val    = store_value_acd1;
            }
            else
            {
                g_non_touch_cmp_val    = 0;
            }
#endif    // KEY_USE
            break;
        case 0x05:
#ifdef    KEY_USE
            status    = CMD_RESULT_FAILURE;
            if (MAX_TS > value)
            {
                mtc_start_ch    = value;
                status    = CMD_RESULT_SUCCESS;
            }
#endif    // KEY_USE
            break;
        case 0x06:
#ifdef    KEY_USE
            status    = CMD_RESULT_FAILURE;
            if (MAX_TS > value)
            {
                mtc_end_ch    = value;
                status    = CMD_RESULT_SUCCESS;
            }
#endif    // KEY_USE
            break;
        case 0x07:
#ifdef    KEY_USE
            Athr    = value;
#endif    // KEY_USE
            break;
        case 0x08:
#ifdef    KEY_USE
            if (IsSensorKey(channel))
            {
#ifdef    MUTUAL_FUNC_USE
                g_nthr[channel % SEND_NUM][channel / SEND_NUM]    = value;
#else    // MUTUAL_FUNC_USE
                g_nthr[g_key_index[channel]]    = value;
#endif    // MUTUAL_FUNC_USE
            }
#endif    // KEY_USE
            break;
        case 0x09:
#ifdef    KEY_USE
            if (IsSensorKey(channel))
            {
#ifdef    MUTUAL_FUNC_USE
                g_nhys[channel % SEND_NUM][channel / SEND_NUM]    = value;
#else    // MUTUAL_FUNC_USE
                g_nhys[g_key_index[channel]]    = value;
#endif    // MUTUAL_FUNC_USE
            }
#endif    // KEY_USE
            break;
#ifdef    SLIDER_USE
        case 0x16:
            if (DF_SLIDER_NUMBER > channel)
            {
                g_sliderInfo[channel].resolution    = value;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
        case 0x17:
            if (DF_SLIDER_NUMBER > channel)
            {
                g_sliderInfo[channel].threshold    = value;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
#endif    // SLIDER_USE
#ifdef    WHEEL_USE            
        case 0x24:
            if (DF_WHEEL_NUMBER > channel)
            {
                g_wheelInfo[channel].resolution    = value;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
        case 0x25:
            if (DF_WHEEL_NUMBER > channel)
            {
                g_wheelInfo[channel].threshold    = value;
            }
            else
            {
                status    = CMD_RESULT_FAILURE;
            }
            break;
#endif    // WHEEL_USE
        default:
            status = CMD_RESULT_FAILURE;
            break;
    }
    pcmd->fmt.data[0] = status;
}

/***********************************************************************************************************************
* Function Name: SensorRegisterReadResponse
* Description  : Control response
* Arguments    : pcmd - 
*                    Pointer of transfer data
* Return Value : none
***********************************************************************************************************************/
static void SensorRegisterReadResponse(com_data_tx_t * pcmd, uint16_t channel)
{
    uint16_t value;
    uint8_t  status;

    pcmd->fmt.size = 1;
    pcmd->fmt.data[0] = CMD_RESULT_FAILURE;    /* Error status */
    value = 0;
    status = CMD_RESULT_SUCCESS;
    switch (pcmd->fmt.sub)
    {
        case 0x00:    // CR0
            value    = CTSUReadCTSUCR0();
            break;
        case 0x01:    // CR1
            value    = CTSUReadCTSUCR1();
            break;
        case 0x02:    // SDPRS
            value    = CTSUReadCTSUSDPRS();
            break;
        case 0x03:    // SST
            value    = CTSUReadCTSUSST();
            break;
        case 0x04:    // MCH0
            value    = CTSUReadCTSUMCH0();
            break;
        case 0x05:    // MCH1
            value    = CTSUReadCTSUMCH1();
            break;
        case 0x06:    // CHAC0
            value    = CTSUReadCTSUCHAC0();
            break;
        case 0x07:    // CHAC1
            value    = CTSUReadCTSUCHAC1();
            break;
#if    (MAX_TS > 12)
        case 0x08:    // CHAC2
            value    = CTSUReadCTSUCHAC2();
            break;
        case 0x09:    // CHAC3
            value    = CTSUReadCTSUCHAC3();
            break;
#else    // (MAX_TS > 12)
        case 0x08:    // CHAC2
        case 0x09:    // CHAC3
            value    = 0x00;
            break;
#endif    // (MAX_TS > 12)
#if    (MAX_TS > 24)
        case 0x0a:    // CHAC4
            value    = CTSUReadCTSUCHAC4();
            break;
#else    // (MAX_TS > 24)
        case 0x0a:    // CHAC4
            value    = 0x00;
            break;
#endif    // (MAX_TS > 24)
        case 0x0b:    // CHTRC0
            value    = CTSUReadCTSUCHTRC0();
            break;
        case 0x0c:    // CHTRC1
            value    = CTSUReadCTSUCHTRC1();
            break;
#if    (MAX_TS > 12)
        case 0x0d:    // CHTRC2
            value    = CTSUReadCTSUCHTRC2();
            break;
        case 0x0e:    // CHTRC3
            value    = CTSUReadCTSUCHTRC3();
            break;
#else    // (MAX_TS > 12)
        case 0x0d:    // CHTRC2
        case 0x0e:    // CHTRC3
            value    = 0x00;
            break;
#endif    // (MAX_TS > 12)
#if    (MAX_TS > 24)
        case 0x0f:    // CHTRC4
            value    = CTSUReadCTSUCHTRC4();
            break;
#else    // (MAX_TS > 24)
        case 0x0f:    // CHTRC4
            value    = 0x00;
            break;
#endif    // (MAX_TS > 24)
        case 0x10:    // DCLKC
            value    = CTSUReadCTSUDCLKC();
            break;
        case 0x11:    // ST
            value    = CTSUReadCTSUST();
            break;
        case 0x12:    // SSC
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                value    = CTSUReadCTSUSSC(g_write_buf, g_index_sensor, channel ,CTSU_DRIVER_MUTUAL, g_max_key);
            }
#else    // MUTUAL_FUNC_USE
            if (g_index_sensor[channel] != 0xff)
            {
                value    = CTSUReadCTSUSSC(g_write_buf, g_index_sensor, channel ,CTSU_DRIVER_SELF, g_max_key);
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x13:    // SO0
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                value    = CTSUReadCTSUSO0(g_write_buf, g_index_sensor, channel ,CTSU_DRIVER_MUTUAL, g_max_key);
            }
#else    // MUTUAL_FUNC_USE
            if (g_index_sensor[channel] != 0xff)
            {
                value    = CTSUReadCTSUSO0(g_write_buf, g_index_sensor, channel ,CTSU_DRIVER_SELF, g_max_key);
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x14:    // SO1
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                value    = CTSUReadCTSUSO1(g_write_buf, g_index_sensor, channel ,CTSU_DRIVER_MUTUAL, g_max_key);
            }
#else    // MUTUAL_FUNC_USE
            if (g_index_sensor[channel] != 0xff)
            {
                value    = CTSUReadCTSUSO1(g_write_buf, g_index_sensor, channel ,CTSU_DRIVER_SELF, g_max_key);
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x15:
#ifdef    MUTUAL_FUNC_USE
            value    = CTSUReadCTSUSC(g_cntrdummy, g_cntrdata, g_index_sensor, channel, CTSU_DRIVER_MUTUAL, g_max_key);
#else    // MUTUAL_FUNC_USE
            value    = CTSUReadCTSUSC(g_cntrdata, g_cntrdummy, g_index_sensor, channel, CTSU_DRIVER_SELF, g_max_key);
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x16:
#ifdef    MUTUAL_FUNC_USE
            value    = CTSUReadCTSURC(g_cntrdummy, g_cntrdata, g_index_sensor, channel, CTSU_DRIVER_MUTUAL, g_max_key);
#else    // MUTUAL_FUNC_USE
            value    = CTSUReadCTSURC(g_cntrdata, g_cntrdummy, g_index_sensor, channel, CTSU_DRIVER_SELF, g_max_key);
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x17:    // ERRS
            value    = CTSUReadCTSUERRS();
            break;
        default:
            status = CMD_RESULT_FAILURE;
            break;
    }

    if (status != CMD_RESULT_FAILURE)
    {
        pcmd->fmt.size    = 3;
        pcmd->fmt.data[0] = status;
        pcmd->fmt.data[1] = (uint8_t)(value & 0xff);
        pcmd->fmt.data[2] = (uint8_t)(value >> 8);
    }
}

static void SensorRegisterWriteResponse(com_data_tx_t * pcmd, uint16_t channel)
{
    uint16_t value;
    uint8_t  status;

    // Measurement stop
    CTSUSetMeasurementOperation(0x00, 0x00);
    
    pcmd->fmt.size = 1;
    pcmd->fmt.data[0] = CMD_RESULT_FAILURE;    /* Error status */
    value = ((uint16_t)com_data.fmt.data[1] << 8) + com_data.fmt.data[0];
    status = CMD_RESULT_SUCCESS;

    switch (pcmd->fmt.sub)
    {
        case 0x00:    // CR0
            //PRM.Register.CR0 = value;
            CTSUWriteCTSUCR0(value);
            break;
        case 0x01:    // CR1
            CTSUWriteCTSUCR1(value);
            break;
        case 0x02:    // SDPRS
            CTSUWriteCTSUSDPRS(value);
            break;
        case 0x03:    // SST
            CTSUWriteCTSUSST(value);
            break;
        case 0x04:    // MCH0
            CTSUWriteCTSUMCH0(value);
            break;
        case 0x05:    // MCH1
            CTSUWriteCTSUMCH1(value);
            break;
        case 0x06:    // CHAC0
            CTSUWriteCTSUCHAC0(value);
            break;
        case 0x07:    // CHAC1
            CTSUWriteCTSUCHAC1(value);
            break;
#if    (MAX_TS > 12)
        case 0x08:    // CHAC2
            CTSUWriteCTSUCHAC2(value);
            break;
        case 0x09:    // CHAC3
            CTSUWriteCTSUCHAC3(value);
            break;
#else    // (MAX_TS > 12)
        case 0x08:    // CHAC2
        case 0x09:    // CHAC3
            break;
#endif    // (MAX_TS > 12)
#if    (MAX_TS > 24)
        case 0x0a:    // CHAC4
            CTSUWriteCTSUCHAC4(value);
            break;
#else    // (MAX_TS > 24)
        case 0x0a:    // CHAC4
            break;
#endif    // (MAX_TS > 24)
        case 0x0b:    // CHTRC0
            CTSUWriteCTSUCHTRC0(value);
            break;
        case 0x0c:    // CHTRC1
            CTSUWriteCTSUCHTRC1(value);
            break;
#if    (MAX_TS > 12)
        case 0x0d:    // CHTRC2
            CTSUWriteCTSUCHTRC2(value);
            break;
        case 0x0e:    // CHTRC3
            CTSUWriteCTSUCHTRC3(value);
            break;
#else    // (MAX_TS > 12)
        case 0x0d:    // CHTRC2
        case 0x0e:    // CHTRC3
            break;
#endif
#if    (MAX_TS > 24)
        case 0x0f:    // CHTRC4
            CTSUWriteCTSUCHTRC4(value);
            break;
#else    // (MAX_TS > 24)
        case 0x0f:    // CHTRC4
            break;
#endif
        case 0x10:    // DCLKC
            CTSUWriteCTSUDCLKC(value);
            break;
        case 0x11:    // ST
            CTSUWriteCTSUST(value);
            break;
        case 0x12:    // SSC
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                CTSUWriteCTSUSSC(g_write_buf, g_index_sensor, value, channel ,CTSU_DRIVER_MUTUAL, g_max_key);
            }
#else    // MUTUAL_FUNC_USE
            if (0xff != g_index_sensor[channel])
            {
                CTSUWriteCTSUSSC(g_write_buf, g_index_sensor, value, channel ,CTSU_DRIVER_SELF, g_max_key);
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x13:    // SO0
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                CTSUWriteCTSUSO0(g_write_buf, g_index_sensor, value, channel ,CTSU_DRIVER_MUTUAL, g_max_key);
            }
#else    // MUTUAL_FUNC_USE
            if (0xff != g_index_sensor[channel])
            {
                CTSUWriteCTSUSO0(g_write_buf, g_index_sensor, value, channel ,CTSU_DRIVER_SELF, g_max_key);
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x14:    // SO1
#ifdef    MUTUAL_FUNC_USE
            if (IsSensorKey(channel))
            {
                CTSUWriteCTSUSO1(g_write_buf, g_index_sensor, value, channel ,CTSU_DRIVER_MUTUAL, g_max_key);
            }
#else    // MUTUAL_FUNC_USE
            if (0xff != g_index_sensor[channel])
            {
                CTSUWriteCTSUSO1(g_write_buf, g_index_sensor, value, channel ,CTSU_DRIVER_SELF, g_max_key);
            }
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x15:
#ifdef    MUTUAL_FUNC_USE
            CTSUWriteCTSUSC(g_cntrdummy, g_cntrdata, g_index_sensor, value, channel, CTSU_DRIVER_MUTUAL, g_max_key);
#else    // MUTUAL_FUNC_USE
            CTSUWriteCTSUSC(g_cntrdata, g_cntrdummy, g_index_sensor, value, channel, CTSU_DRIVER_SELF, g_max_key);
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x16:
#ifdef    MUTUAL_FUNC_USE
            CTSUWriteCTSURC(g_cntrdummy, g_cntrdata, g_index_sensor, value, channel, CTSU_DRIVER_MUTUAL, g_max_key);
#else    // MUTUAL_FUNC_USE
            CTSUWriteCTSURC(g_cntrdata, g_cntrdummy, g_index_sensor, value, channel, CTSU_DRIVER_SELF, g_max_key);
#endif    // MUTUAL_FUNC_USE
            break;
        case 0x17:
            CTSUWriteCTSUERRS(value);
            break;
        default:
            status = CMD_RESULT_FAILURE;
            break;
    }
    pcmd->fmt.data[0] = status;
    
    // Measurement Re-start
    CTSUSetCtsuStart();
}

static void SensorUtilityReadResponse(com_data_tx_t *pcmd, uint16_t channel)
{
    uint8_t i;
    uint8_t index;
    uint8_t start;
    uint8_t end;
    uint8_t ch;
    uint8_t cmd;
    uint16_t value;
    uint8_t status;

    pcmd->fmt.size = 1;
    pcmd->fmt.data[0]    = CMD_RESULT_FAILURE;
    status    = CMD_RESULT_SUCCESS;

    switch (pcmd->fmt.sub)
    {
        case 0x00:    // UPDATE
            // Touch API�p�����[�^��Touch API���W�X�^�[��L�����ATouch API���X�^�[�g
            status    = CMD_RESULT_SUCCESS;
            value    = CMD_UTILITY_UPDATE_FINISH;
            break;
        case 0x01:    // RESET
            // Touch API�p�����[�^��Touch API���W�X�^�[���������ATouch API���X�^�[�g
            status    = CMD_RESULT_SUCCESS;
            value    = CMD_UTILITY_RESET_FINISH;
            break;
        case 0x02:    // SET_BATCH
            // �o�b�`�R�}���h�Q�Ƃ�RL78/L13�f���{�[�h�����ł̓T�|�[�g���Ȃ��B
            status    = CMD_RESULT_SUCCESS;
            break;
        case 0x03:    // EXEC_BATCH
            index = 1;
            status    = CMD_RESULT_SUCCESS;
            for (i = 0; (i < monitor_command.size) && (status != CMD_RESULT_FAILURE); i++)
            {
                if (monitor_command.command[i] == 0x00/* SC */        ||
                    monitor_command.command[i] == 0x01/* RV */        ||
                    monitor_command.command[i] == 0x02/* SC */        ||
                    monitor_command.command[i] == 0x04/* SLDPOS */    ||
                    monitor_command.command[i] == 0x05/* WHLPOS */    ||
                    monitor_command.command[i] == 0x0a/* SCFRST */    ||
                    monitor_command.command[i] == 0x0b/* SCSCND */    ||
                    monitor_command.command[i] == 0x0c/* RCFRST */    ||
                    monitor_command.command[i] == 0x0d/* RCFRST */
                    )
                {
                    cmd   = monitor_command.command[i++];
                    start = monitor_command.command[i++];
                    end   = monitor_command.command[i];

                    for (ch = start; ch < end; ch++)
                    {
                        if (GetSensorValue(cmd, ch, &value))
                        {
                            pcmd->fmt.data[index++] = (uint8_t)(value & 0xff);
                            pcmd->fmt.data[index++] = (uint8_t)(value >> 8);
                        }
                        else
                        {
                            status    = CMD_RESULT_FAILURE;
                        }
                    }

                }
                else
                {
                    if (GetSensorValue(monitor_command.command[i], 0, &value))
                    {
                        pcmd->fmt.data[index++] = (uint8_t)(value & 0xff);
                        pcmd->fmt.data[index++] = (uint8_t)(value >> 8);
                    }
                    else
                    {
                        status    = CMD_RESULT_FAILURE;
                    }
                }
            }
            if (CMD_RESULT_FAILURE != status)
            {
                pcmd->fmt.size = index;
            }
            break;
        case 0x04:    // MEASURE
            pcmd->fmt.size = 2;
            pcmd->fmt.data[1]    = 1;
            if (CTSU_STOP_MODE == g_ctsu_soft_mode)
            {
                pcmd->fmt.data[1]    = 0;
            }
            break;
        case 0x05:    // FLAGS
            pcmd->fmt.size        = 3;
            pcmd->fmt.data[1]    = g_ctsu_flag.byte;
            pcmd->fmt.data[2]    = 0;
            break;
        case 0x06:    // WAIT
            pcmd->fmt.size        = 3;
            pcmd->fmt.data[1]    = (uint8_t)(WAIT_TIME & 0xff);
            pcmd->fmt.data[2]    = (uint8_t)(WAIT_TIME >> 8);
            break;
        default:
            break;
    }
    if (CMD_RESULT_FAILURE != status)
    {
        pcmd->fmt.data[0]    = status;
    }
}

static void SensorUtilityWriteResponse(com_data_tx_t *pcmd, uint16_t channel)
{
    uint8_t i;
    uint8_t status;

    pcmd->fmt.size = 1;
    pcmd->fmt.data[0]    = CMD_RESULT_FAILURE;
    status    = CMD_RESULT_SUCCESS;

    switch (pcmd->fmt.sub)
    {
        case 0x00:    // UPDATE
            // Touch API�p�����[�^��Touch API���W�X�^�[��L�����ATouch API���X�^�[�g
            g_write_request = CMD_UTILITY_PARAM_UPDATE;
            break;
        case 0x01:    // RESET
            // Touch API�p�����[�^��Touch API���W�X�^�[���������ATouch API���X�^�[�g
            CTSUSetInitial();
            break;
        case 0x02:    // SET_BATCH
            for (i = 0; i < com_data.fmt.size; i++)
            {
                monitor_command.command[i] = com_data.fmt.data[i];
            }
            monitor_command.size = com_data.fmt.size;
            break;
        case 0x03:    // EXEC_BATCH
            // READ ONLY
            status    = CMD_RESULT_FAILURE;
            break;
        case 0x04:    // MEASURE
            if (0 != com_data.fmt.data[0])
            {
                g_ctsu_flag.bit.sens_over    = 0;
                g_ctsu_flag.bit.icomp_error    = 0;
                CtsuSetAutoTuningOnOff(AT_STOP);
                CTSUSetCtsuStart();
            }
            else
            {
                CTSUSetMeasurementOperation(0x00, 0x00);
                g_ctsu_soft_mode = CTSU_STOP_MODE;
            }
            break;
        case 0x05:    // FLAGS
            g_ctsu_flag.byte    = pcmd->fmt.data[0];
            break;
        case 0x06:    // WAIT
            // READ ONLY
            status    = CMD_RESULT_FAILURE;
            break;
        default:     /* Non-support commands */
            status    = CMD_RESULT_FAILURE;
            break;
    }
    if (CMD_RESULT_FAILURE != status)
    {
        pcmd->fmt.data[0]    = status;
    }
}
#endif    //] WORKBENCH_COMMAND_USE

/******************************************************************************
* END OF TEXT
******************************************************************************/
