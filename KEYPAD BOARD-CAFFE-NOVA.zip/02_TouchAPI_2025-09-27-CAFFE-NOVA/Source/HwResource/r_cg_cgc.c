/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_cg_cgc.c
* Version      : Code Generator for RX111 V1.01.00.03 [22 Aug 2013]
* Device(s)    : R5F51111AxFM
* Tool-Chain   : CCRX
* Description  : This file implements device driver for CGC module.
* Creation Date: 2013/11/18
***********************************************************************************************************************/

/***********************************************************************************************************************
Pragma directive
***********************************************************************************************************************/
/* Start user code for pragma. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
/* System include header */
#include "r_cg_macrodriver.h"
#ifdef MUTUAL_FUNC_USE
    #include "r_ctsu_physical_driver_mu.h"
#else
    #include "r_ctsu_physical_driver.h"
#endif    //] MUTUAL_FUNC_USE

/* H/W include header */
#include "r_cg_cgc.h"

/* S/W include header */
#include "r_cg_userdefine.h"

/* Start user code for include. Do not edit comment generated here */
#ifdef USB_SERIAL_USE
static void R_Main16MHz_PLL32MHz_UPLL48MHz_Start(void);
static void R_Main8MHz_PLL32MHz_UPLL48MHz_Start(void);
#endif	// USB_SERIAL_USE
static void R_HOCO32MHz_Start(void);
/* End user code. Do not edit comment generated here */


/***********************************************************************************************************************
Global variables and functions
***********************************************************************************************************************/
/* Start user code for global. Do not edit comment generated here */
/* End user code. Do not edit comment generated here */

/***********************************************************************************************************************
* Function Name: R_CGC_Create
* Description  : This function initializes the clock generator.
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
void R_CGC_Create(void)
{
#ifdef USB_SERIAL_USE
    uint32_t sckcr_dummy;

    if(TOUCH_SAMPLE_CLOCK_SOURCE == TOUCH_CLOCK_SOURCE_PLL)
    {
        /* Set main clock control registers */
        if(TOUCH_SAMPLE_XTAL_HZ >= TOUCH_SAMPLE_10MHZ){
            /* Vcc > 2.4V 10MHz-20MHz                   */
            SYSTEM.MOFCR.BYTE = _00_CGC_MAINOSC_RESONATOR | _20_CGC_MAINOSC_OVER10M;
        }else{
            /* Vcc > 2.4V 1MHz-10MHz                    */
            SYSTEM.MOFCR.BYTE = _00_CGC_MAINOSC_RESONATOR | _00_CGC_MAINOSC_UNDER10M;
        }
        SYSTEM.MOSCWTCR.BYTE  = _07_CGC_OSC_WAIT_CYCLE_65536;   /* Wait time 65536 cycle (16.384ms)         */
        /* Set main clock operation */
        SYSTEM.MOSCCR.BIT.MOSTP = 0U;                           /* Main clock oscillator is operated        */

        /* Wait for main clock oscillator wait counter overflow */
        while (1U != SYSTEM.OSCOVFSR.BIT.MOOVF);

        /* Set system clock */
        sckcr_dummy = _00000000_CGC_PCLKD_DIV_1 | _00000000_CGC_PCLKB_DIV_1 | _00000000_CGC_ICLK_DIV_1 | 
                      _00000000_CGC_FCLK_DIV_1;
        SYSTEM.SCKCR.LONG = sckcr_dummy;

        while (SYSTEM.SCKCR.LONG != sckcr_dummy);

        /* Set PLL circuit */
        if(TOUCH_SAMPLE_XTAL_HZ == TOUCH_SAMPLE_16MHZ)
        {
            R_Main16MHz_PLL32MHz_UPLL48MHz_Start();
        }
        else if(TOUCH_SAMPLE_XTAL_HZ == TOUCH_SAMPLE_8MHZ)
        {
            R_Main8MHz_PLL32MHz_UPLL48MHz_Start();
        }
        else
        {
        }
    }
#endif	// USB_SERIAL_USE
    if(TOUCH_SAMPLE_CLOCK_SOURCE == TOUCH_CLOCK_SOURCE_HOCO)
    {
        R_HOCO32MHz_Start();
    }
}
/* Start user code for adding. Do not edit comment generated here */
#ifdef USB_SERIAL_USE
/***********************************************************************************************************************
* Function Name: R_Main16MHz_PLL32MHz_UPLL48MHz_Start
* Description  : This function initializes the clock.Main=16MHz,PLL=32MHz,UPLL=48MHz
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void R_Main16MHz_PLL32MHz_UPLL48MHz_Start(void)
{
    /* UPLL = 48MHz , PLL = 32MHz */
    SYSTEM.PLLCR.WORD = _0002_CGC_PLL_FREQ_DIV_4 | _0F00_CGC_PLL_FREQ_MUL_8;
    SYSTEM.UPLLCR.WORD = _0001_CGC_PLL_FREQ_DIV_2 | _0B00_CGC_PLL_FREQ_MUL_6;
    SYSTEM.UPLLCR.BIT.UCKUPLLSEL    = 1;            /* UCLK ---> USB PLL select                 */
    SYSTEM.PLLCR2.BIT.PLLEN         = 0;            /* PLL enable                               */
    SYSTEM.UPLLCR2.BIT.UPLLEN       = 0;            /* USB PLL enable                           */

    /* Wait for UPLL wait counter overflow */
    while (1U != SYSTEM.OSCOVFSR.BIT.UPLOVF);

    /* Wait for PLL wait counter overflow */
    while (1U != SYSTEM.OSCOVFSR.BIT.PLOVF);

    /* Disable sub-clock */
    SYSTEM.SOSCCR.BIT.SOSTP = 1U;

    /* Wait for the register modification to complete */
    while (1U != SYSTEM.SOSCCR.BIT.SOSTP);

    /* Disable sub-clock */
    RTC.RCR3.BIT.RTCEN = 0U;

    /* Wait for the register modification to complete */
    while (0U != RTC.RCR3.BIT.RTCEN);

    /* Set clock source */
    SYSTEM.SCKCR3.WORD = _0400_CGC_CLOCKSOURCE_PLL;

    while (SYSTEM.SCKCR3.WORD != _0400_CGC_CLOCKSOURCE_PLL);

    /* Module stop control register (Enable USB0 module(MSTPB19)) */
    SYSTEM.MSTPCRB.BIT.MSTPB19      = 0;
}
/***********************************************************************************************************************
* Function Name: R_Main8MHz_PLL32MHz_UPLL48MHz_Start
* Description  : This function initializes the clock.Main=8MHz,PLL=32MHz,UPLL=48MHz
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void R_Main8MHz_PLL32MHz_UPLL48MHz_Start(void)
{
    /* UPLL = 48MHz , PLL = 32MHz */
    SYSTEM.PLLCR.WORD = _0001_CGC_PLL_FREQ_DIV_2 | _0F00_CGC_PLL_FREQ_MUL_8;
    SYSTEM.UPLLCR.WORD = _0000_CGC_PLL_FREQ_DIV_1 | _0B00_CGC_PLL_FREQ_MUL_6;
    SYSTEM.UPLLCR.BIT.UCKUPLLSEL    = 1;            /* UCLK ---> USB PLL select                 */
    SYSTEM.PLLCR2.BIT.PLLEN         = 0;            /* PLL enable                               */
    SYSTEM.UPLLCR2.BIT.UPLLEN       = 0;            /* USB PLL enable                           */

    /* Wait for UPLL wait counter overflow */
    while (1U != SYSTEM.OSCOVFSR.BIT.UPLOVF);

    /* Wait for PLL wait counter overflow */
    while (1U != SYSTEM.OSCOVFSR.BIT.PLOVF);

    /* Disable sub-clock */
    SYSTEM.SOSCCR.BIT.SOSTP = 1U;

    /* Wait for the register modification to complete */
    while (1U != SYSTEM.SOSCCR.BIT.SOSTP);

    /* Disable sub-clock */
    RTC.RCR3.BIT.RTCEN = 0U;

    /* Wait for the register modification to complete */
    while (0U != RTC.RCR3.BIT.RTCEN);

    /* Set clock source */
    SYSTEM.SCKCR3.WORD = _0400_CGC_CLOCKSOURCE_PLL;

    while (SYSTEM.SCKCR3.WORD != _0400_CGC_CLOCKSOURCE_PLL);

    /* Module stop control register (Enable USB0 module(MSTPB19)) */
    SYSTEM.MSTPCRB.BIT.MSTPB19      = 0;
}
#endif	// USB_SERIAL_USE
/***********************************************************************************************************************
* Function Name: R_HOCO32MHz_Start
* Description  : This function initializes the clock.HOCO=32MHz
* Arguments    : None
* Return Value : None
***********************************************************************************************************************/
static void R_HOCO32MHz_Start(void)
{
    uint32_t sckcr_dummy;
    /* Set system clock */
    sckcr_dummy = _00000000_CGC_PCLKD_DIV_1 | _00000000_CGC_PCLKB_DIV_1 | _00000000_CGC_ICLK_DIV_1 | 
                  _00000000_CGC_FCLK_DIV_1;
    SYSTEM.SCKCR.LONG = sckcr_dummy;

    while (SYSTEM.SCKCR.LONG != sckcr_dummy);

    /* Disable sub-clock */
    SYSTEM.SOSCCR.BIT.SOSTP = 1U;

    /* Wait for the register modification to complete */
    while (1U != SYSTEM.SOSCCR.BIT.SOSTP);

    /* Disable sub-clock */
    RTC.RCR3.BIT.RTCEN = 0U;

    /* Wait for the register modification to complete */
    while (0U != RTC.RCR3.BIT.RTCEN);

    /* Set HOCO */
    SYSTEM.HOCOCR.BIT.HCSTP = 0U;

    /* Wait for HOCO wait counter overflow */
    while (1U != SYSTEM.OSCOVFSR.BIT.HCOVF);

    /* Set HOCO wait time */
    SYSTEM.HOCOWTCR.BYTE = _06_CGC_HOCO_WAIT_CYCLE_266;

    /* Set clock source */
    SYSTEM.SCKCR3.WORD = _0100_CGC_CLOCKSOURCE_HOCO;

    while (SYSTEM.SCKCR3.WORD != _0100_CGC_CLOCKSOURCE_HOCO);

}
/* End user code. Do not edit comment generated here */
