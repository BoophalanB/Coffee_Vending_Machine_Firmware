#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"

void validate_password();
void increment();
void decrement();

extern void error_update_display(unsigned char ,unsigned char ,unsigned char ,unsigned char );
extern void HEX_TO_BCD(unsigned long int num);
extern unsigned char dec_to_hex(unsigned char num);


void password()
{
	if(!password_flag)
	{
		home_sc_flag=0;
		password_flag=SET;
		disp_id2 = PASSWORD;
		line2_flag=1;
		update_data_flag=1;
		value_browser_point = 00;
		HEX_TO_BCD(value_browser_point);
		increment_decrement_flag=SET;
	}
}


void validate_password()
{
	if(password_flag)
	{
		
		if((value_browser_point EQUAL_TO 15)&&(brew)) 
		{
		   password_flag=0;
		   increment_decrement_flag=0;
		   val_password_flag=1;
		}
		else if((value_browser_point EQUAL_TO 25)&&(sett))
		{
		   password_flag=0;
		   increment_decrement_flag=0;
		   val_password_flag=1;
		}
		else if((value_browser_point NOT_EQUAL_TO 25)&&(sett))
		{
		   sett=0;
	           password_flag=0;
		   long_press_flag=short_press_flag=0;
		   increment_decrement_flag=0;
		   inval_password_flag=1;
		}
		else
		{
			if(brew)
			{
				brew=0;
				if(value_browser_point NOT_EQUAL_TO 15)
				{
				   password_flag=0;
				   long_press_flag=short_press_flag=0;
				   increment_decrement_flag=0;
				   inval_password_flag=1;
				}
			}
		}
	}
}

void increment()
{
	if((disp_id3==TEA_DEC_PRE_LTR)||(disp_id3==COF_DEC_PRE_LTR))
	{
		if(value_browser_point==15)
		value_browser_point=30;
		else if(value_browser_point==30)
		value_browser_point=15;
	}
        if(disp_id3==TEA_DEC_1L_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
        if(disp_id3==TEA_DEC_3L_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
        if(disp_id3==COF_DEC_1LTR_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==COF_DEC_3LTR_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==LT_MILK_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==LT_DEC_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==BT_HW_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==BT_DEC_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==TEA_DEC_REV_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==SC_MILK_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==SC_DEC_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==LC_MILK_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==LC_DEC_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==BC_HW_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==BC_DEC_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==COFF_DEC_REV_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==MILK_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==MILK_EXT_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==MILK_REV_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==HW_ON_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	if(disp_id3==BOILER_DR_TM)
	{
		if(value_browser_point==250)
		value_browser_point=0;
	}
	
	if(disp_id3==HEATER_ER_TM)
	{
		if(value_browser_point==300)
		value_browser_point=0;
	}
        if((disp_id3!=TEA_DEC_PRE_LTR)&&(disp_id3!=COF_DEC_PRE_LTR))
	      value_browser_point++;
	      HEX_TO_BCD(value_browser_point);
	      update_data_flag=SET;
	
}

void decrement()
{	
	if((disp_id3==TEA_DEC_PRE_LTR)||(disp_id3==COF_DEC_PRE_LTR))
	{
		if(value_browser_point==15)
		value_browser_point=30;
		else if(value_browser_point==30)
		value_browser_point=15;
	}
	if((value_browser_point>0)&&(disp_id3!=TEA_DEC_PRE_LTR)&&(disp_id3!=COF_DEC_PRE_LTR))
	  value_browser_point--;
	 HEX_TO_BCD(value_browser_point);
	 update_data_flag=SET;
}