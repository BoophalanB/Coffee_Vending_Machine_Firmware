/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_cg_userdefine.h"

/***********************************************************************************************************************
* File Name    : r_ctsu_setup.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

#ifndef __R_CTSU_SETUP_H__    //[
#define __R_CTSU_SETUP_H__

#ifdef __R_CTSU_SETUP_C__
    #define CTSU_SETUP_EXTERN
#else
    #define CTSU_SETUP_EXTERN    extern
#endif

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_ctsu_parameter_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***** Tracking timing ************************************************************************************************/
#define DF_TRACKING_TIME        (200)                 /* 200*TOUCH_MEASUREMENT_CYCLE_MS cycle(20ms or 40ms) */

/***** Protect enable set up data *************************************************************************************/
#define PRCR1_ENA        (0xA502)      /* 803FEh    Protect register                                                  */
#define PRCR1_DIS        (0xA500)      /* 803FEh    Protect register                                                  */

/***** Function select set up data ************************************************************************************/
#define P02PFS_TS2       (0x19)        /* 8C142h    P02 Pin function control register(TS2)                            */
#define P04PFS_TS1       (0x19)        /* 8C144h    P04 Pin function control register(TS1)                            */
#define P07PFS_TS0       (0x19)        /* 8C147h    P07 Pin function control register(TS0)                            */

#define P20PFS_TS9       (0x19)        /* 8C150h    P20 Pin function control register(TS9)                            */
#define P21PFS_TS8       (0x19)        /* 8C151h    P21 Pin function control register(TS8)                            */
#define P22PFS_TS7       (0x19)        /* 8C152h    P22 Pin function control register(TS7)                            */
#define P23PFS_TS6       (0x19)        /* 8C153h    P23 Pin function control register(TS6)                            */
#define P24PFS_TS5       (0x19)        /* 8C154h    P24 Pin function control register(TS5)                            */
#define P25PFS_TS4       (0x19)        /* 8C155h    P25 Pin function control register(TS4)                            */
#define P26PFS_TSCAP     (0x19)        /* 8C156h    P26 Pin function control register(TSCAP)                          */
#define P27PFS_TS10      (0x19)        /* 8C157h    P27 Pin function control register(TS10)                           */

#define P32PFS_TS11      (0x19)        /* 8C15Ah    P32 Pin function control register(TS11)                           */
#define PJ3PFS_TS3       (0x19)        /* 8C1D3h    P32 Pin function control register(TS3)                            */

#ifdef DRIVE_PULSE_DEBUG
    #define P15PFS_DEGUG    (0x09)     /* Sensor drive pulse output setting                                           */
#endif

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
#pragma pack

typedef union
{
    uint16_t    word;
    struct
    {
        uint8_t    low;        /* Low  8 bit */
        uint8_t    high;       /* High 8 bit */
    } byte;
} WORD_ACS_T;

typedef struct
{
    uint8_t    hard_macro_power_sw;
    uint8_t    lpf_charge_sw;
    uint8_t    analogue_signal_mode;
    uint8_t    analogue_output_mode;
    uint8_t    ctsu_count_source;
    uint8_t    measure_mode;
} ctsu_ctsucr1_data_t;

typedef struct
{
    uint8_t    diffusion_clock_mode;           /* CTSU diffusion clock mode select data                             */
    uint8_t    diffusion_clock_control;        /* CTSU diffusion clock control data                                 */
} ctsu_ctsudclkc_data_t;

typedef struct
{
    uint8_t    drive_pulse_cycle;              /* CTSU measurement time and pulse count adjustment data             */
    uint8_t    drive_pulse_mode;               /* CTSU base period and pulse count setting data                     */
    uint8_t    sensor_edge_control;            /* CTSU high-pass noise reduction function Off Setting data          */
} ctsu_ctsusdprs_data_t;

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
CTSU_SETUP_EXTERN ctsu_ctsucr1_data_t      g_ctsucr1_param;          /* CTSUCR1 register data                         */
CTSU_SETUP_EXTERN ctsu_ctsudclkc_data_t    g_ctsudclkc_param;        /* CTSUDCLKC register data                       */
CTSU_SETUP_EXTERN ctsu_ctsusdprs_data_t    g_ctsusdprs_param;        /* CTSUSDPRS register data                       */
CTSU_SETUP_EXTERN uint8_t                  g_ctsu_wait_time;         /* CTSUSST register data                         */
CTSU_SETUP_EXTERN uint16_t                 g_ctsu_chanel_enable;     /* CTSUCHAC0 | ( CTSUCHAC1 >> 8 ) register data  */
CTSU_SETUP_EXTERN uint8_t                  g_ctsu_measure_chanel;    /* CTSUMCH0 register data                        */
CTSU_SETUP_EXTERN uint16_t                 g_ctsu_chanel_txrx;       /* CTSUCHTRC0 | ( CTSUCHTRC1 <<8 ) register data */
CTSU_SETUP_EXTERN uint8_t                  g_index_sensor[MAX_TS];   /* TS number index buffer                        */
CTSU_SETUP_EXTERN uint8_t                  g_max_key;                /* Max key data                                  */

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CTSUSetInitial(void);
void CTSUInitialRegisterValueStorage(void);
void CTSUSetWriteBuffer(void);
void CTSUFunctionPinControl(void);
void CTSUStartSetup(void);
void CTSUParameterBufInit(void);

#endif //] __R_TOUCH_CONTROL_H__
