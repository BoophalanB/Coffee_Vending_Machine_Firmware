/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_common_control.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#ifndef __R_CTSU_COMMON_CONTROL_H__    //[
#define __R_CTSU_COMMON_CONTROL_H__

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_ctsu_parameter_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef __R_CTSU_COMMON_CONTROL_C__
    #define CTSU_COMMON_EXTERN
#else
    #define CTSU_COMMON_EXTERN    extern
#endif

#define SENS_OK          (0x00)
#define SENS_OVER        (0x01)
#define REF_OVER         (0x02)
#define SENS_REF_OVER    (0x03)

#define ADD_TIME         (4)

#define ADD4_WAIT_FREQUENCY    (42)
#define ADD5_WAIT_FREQUENCY    (56)
#define ADD6_WAIT_FREQUENCY    (67)
#define ADD7_WAIT_FREQUENCY    (78)
#define ADD8_WAIT_FREQUENCY    (90)

#define AT_CONTI    (0)
#define AT_FINISH   (1)
#define AT_OK       (0)
#define AT_NG       (1)

#define DT_PLUS     (0)
#define DT_MINUS    (1)

#define TRACKING_UPPER_LIMIT   (200)
#define TRACKING_LOWER_LIMIT   (50)

#ifndef MUTUAL_FUNC_USE
    #define CTSU_WR_BUF_SIZE    (3*SUM_TS)            /* 3word (CTSUSSC + CTSUSO0 + CTSUSO1) * sum_ch             */
    #define CTSU_RD_BUF_SIZE    (SUM_TS)              /* 1struct (Sensor counter + Reference counter) * sum_ch    */
#else
    #define CTSU_WR_BUF_SIZE_M    (3*MEASURE_NUM)     /* 1word * (CTSUSSC + CTSUSO0 + CTSUSO1) * sum_ch           */
    #define CTSU_RD_BUF_SIZE_M    (MEASURE_NUM)       /* 1word * (Sensor counter + Reference counter) * sum_ch    */
#endif    //] MUTUAL_FUNC_USE

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
/* Flag define */
typedef union
{
    uint8_t        byte;    /* flag data       */
    struct
    {
        uint8_t    sens_over       : 1;    /* 0 sensor counter overflow flag              */
        uint8_t    ref_over        : 1;    /* 1 reference counter overflow flag           */
        uint8_t    icomp_error     : 1;    /* 2 TSCAP voltage error                       */
        uint8_t    ctsu_measure    : 1;    /* 3 CTSU measurement on flag                  */
        uint8_t    first_storage   : 1;    /* 4 Moving average first data storage flag    */
        uint8_t    data_update     : 1;    /* 5 measurement data updata flug              */
        uint8_t    msr_calib       : 1;    /* 6 g_nref initial calibration (tmp)          */
        uint8_t    ctsu_period     : 1;    /* 7 CTSU period (tmp)                         */
    } bit;
} ctsu_flag_t;

/* CTSU measure mode */
typedef enum
{
    CTSU_STOP_MODE        = 0,
    CTSU_READY_MODE       = 1,
    CTSU_RUN_MODE         = 2,
    CTSU_FINISH_MODE      = 3
} ctsu_measure_mode;

/* CTSU auto tuning mode */
typedef enum
{
    CTSU_AT_INIT                = 0,
    CTSU_AT_INITIAL_OFFSET      = 1,
    CTSU_AT_TRACKING_OFFSET     = 2,
    CTSU_AT_STOP                = 3,
    CTSU_AT_PAUSE               = 4,
    CTSU_AT_TSCAP_ERR           = 0xFF,
} ctsu_auto_tuning_mode;

typedef enum
{
    CTSU_OT_INIT               = 0,
    CTSU_OT_TUNING             = 1,
    CTSU_OT_FINISH             = 2,
    CTSU_OT_TSCAP_ERR          = 0xFE,
    CTSU_OT_SC_OVERFLOW_ERR    = 0xFF
} ctsu_offset_tuning_mode;

/* TS function status */
typedef struct
{
    uint16_t    ts_low;        /* TS00-TS15 */
#if (SUM_TS > 16)
    uint16_t    ts_mid;        /* TS16-TS31 */
#endif
#if (SUM_TS > 32)
    uint16_t    ts_high;       /* TS32-TS35 */
#endif
} ts_function_sta_t;

/*===== Measurement data ====================================================*/
typedef struct
{
    uint16_t    sen_cntr;   /* dtc->sen_cntr */
    uint16_t    ref_cntr;   /* dtc->ref_cntr */
} ctsu_in_data_t;

typedef struct
{
    uint16_t    sen_cntr;   /* dtc->sen_cntr */
    uint16_t    ref_cntr;   /* dtc->ref_cntr */
    uint16_t    sen_cntr_2; /* dtc->sen_cntr */
    uint16_t    ref_cntr_2; /* dtc->ref_cntr */
} ctsu_in_data_t_mu;

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                    Self global variables                   ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#ifndef MUTUAL_FUNC_USE
    CTSU_COMMON_EXTERN uint16_t    g_s_addbuf[SUM_TS];                     /* Sensor counter data adding buffer       */
    CTSU_COMMON_EXTERN uint16_t    g_r_addbuf[SUM_TS];                     /* Reference counter data adding buffer    */
    CTSU_COMMON_EXTERN uint16_t    g_scount[SUM_TS];                       /* Sensor counter data buffer              */
    CTSU_COMMON_EXTERN uint16_t    g_rcount[SUM_TS];                       /* Reference counter data buffer           */
    CTSU_COMMON_EXTERN uint8_t     offset_tuning_mode[SUM_TS];             /* Auto Tuning mode                        */
    CTSU_COMMON_EXTERN uint16_t    g_scount_bak[SUM_TS];                   /* g_scount backup data                    */
    CTSU_COMMON_EXTERN uint16_t    g_offset_bak[SUM_TS];                   /* Sensor Offset Register backup data      */
    CTSU_COMMON_EXTERN uint16_t    g_CTSUSO_bak[SUM_TS];                   /* Sensor Offset Register backup data      */
    CTSU_COMMON_EXTERN uint16_t    g_offset_data_bak[SUM_TS];              /* Sensor Offset Register backup data      */

    CTSU_COMMON_EXTERN uint16_t            g_write_buf[CTSU_WR_BUF_SIZE];
    CTSU_COMMON_EXTERN ctsu_in_data_t      g_cntrdata[CTSU_RD_BUF_SIZE];
    CTSU_COMMON_EXTERN ctsu_in_data_t_mu   g_cntrdummy[1];

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                   Mutual global variables                  ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#else
    CTSU_COMMON_EXTERN uint16_t    g_s_addbuf[MEASURE_NUM];                 /* Sensor primary counter data adding buffer         */
    CTSU_COMMON_EXTERN uint16_t    g_s_addbuf2[MEASURE_NUM];                /* Sensor secondary counter data adding buffer       */
    CTSU_COMMON_EXTERN uint16_t    g_r_addbuf[MEASURE_NUM];                 /* Reference primary counter data adding buffer      */
    CTSU_COMMON_EXTERN uint16_t    g_r_addbuf2[MEASURE_NUM];                /* Reference secondary counter data adding buffer    */
    CTSU_COMMON_EXTERN uint16_t    g_s_primary[SEND_NUM][RECEIVE_NUM];      /* Sensor primary counter data buffer                */
    CTSU_COMMON_EXTERN uint16_t    g_s_secondary[SEND_NUM][RECEIVE_NUM];    /* Sensor secondary counter data buffer              */
    CTSU_COMMON_EXTERN uint16_t    g_r_primary[SEND_NUM][RECEIVE_NUM];      /* Reference primary counter data buffer             */
    CTSU_COMMON_EXTERN uint16_t    g_r_secondary[SEND_NUM][RECEIVE_NUM];    /* Reference secondary counter data buffer           */
    CTSU_COMMON_EXTERN uint16_t    g_diff_scount[SEND_NUM][RECEIVE_NUM];    /* g_s_secondary[] - g_s_primary[]                   */
    CTSU_COMMON_EXTERN uint16_t    g_diff_rcount[SEND_NUM][RECEIVE_NUM];    /* g_r_secondary[] - g_r_primary[]                   */
    CTSU_COMMON_EXTERN uint8_t     offset_tuning_mode[MEASURE_NUM];         /* Auto Tuning mode                                  */
    CTSU_COMMON_EXTERN uint16_t    g_scount_bak[MEASURE_NUM];               /* g_scount backup data                              */
    CTSU_COMMON_EXTERN uint16_t    g_offset_bak[MEASURE_NUM];               /* Sensor Offset Register backup data                */
    CTSU_COMMON_EXTERN uint16_t    g_CTSUSO_bak[MEASURE_NUM];               /* Sensor Offset Register backup data                */
    CTSU_COMMON_EXTERN uint16_t    g_offset_data_bak[MEASURE_NUM];          /* Sensor Offset Register backup data                */

    CTSU_COMMON_EXTERN uint16_t             g_write_buf[CTSU_WR_BUF_SIZE_M];
    CTSU_COMMON_EXTERN ctsu_in_data_t_mu    g_cntrdata[CTSU_RD_BUF_SIZE_M];
    CTSU_COMMON_EXTERN ctsu_in_data_t       g_cntrdummy[1];

#endif //] MUTUAL_FUNC_USE

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                   Common global variables                  ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
CTSU_COMMON_EXTERN volatile ctsu_flag_t    g_ctsu_flag;                     /* CTSU measurement status flag           */
CTSU_COMMON_EXTERN volatile uint8_t        g_ctsu_soft_mode;                /* CTSU operating mode flag               */

CTSU_COMMON_EXTERN uint16_t     g_c_at_timing;                              /* Auto Tuning Timing                     */
CTSU_COMMON_EXTERN uint8_t      g_c_at_times;                               /* Auto Tuning number of times            */
CTSU_COMMON_EXTERN uint16_t     ref_count[SUM_TS];                          /* Reference value (used Offset auto tuning)    */
CTSU_COMMON_EXTERN uint8_t      g_ctsu_at_mode;                             /* Auto Tuning mode                       */
CTSU_COMMON_EXTERN uint8_t      g_ctsu_at_mode_bak;                         /* Auto Tuning mode                       */
CTSU_COMMON_EXTERN uint16_t     g_tracking_timing;                          /* Auto Tuning (Tracking) timing          */

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CTSUMainProc(void);
void CTSUChkErrMode( void );
void CTSUMovingAverage( void );
void CTSUAutoTuning( void );
uint8_t InitialOffsetTuning( void );
void TrackingOffsetTuning( void );
void CTSUSetCtsuStart(void);

#endif //] __R_CTSU_COMMON_CONTROL_H__
