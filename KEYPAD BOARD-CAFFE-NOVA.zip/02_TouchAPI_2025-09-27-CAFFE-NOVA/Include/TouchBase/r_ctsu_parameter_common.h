/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_parameter_common.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#ifndef __R_CTSU_PARAMETER_COMMON_H__    //[
#define __R_CTSU_PARAMETER_COMMON_H__

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* S/W driver version information(Year/Month) */
#define DF_VERSIONu (0x1409)
/*                     ||++--------------- set Month (BCD) */
/*                     ++----------------- set Year  (BCD / 2011 -> 11) */

/* S/W driver version information(Day/Sub) */
#define DF_VERSIONd (0x050a)
/*                     ||++--------------- set Sub Number (0, a -> f) */
/*                     ++----------------- set Day   (BCD) */

/* CTSU touch sensor enable control definition */
#define DF_ENABLE_TS00    (1u)
#define DF_ENABLE_TS01    (1u)
#define DF_ENABLE_TS02    (1u)
#define DF_ENABLE_TS03    (0u)
#define DF_ENABLE_TS04    (0u)
#define DF_ENABLE_TS05    (0u)
#define DF_ENABLE_TS06    (0u)
#define DF_ENABLE_TS07    (1u)
#define DF_ENABLE_TS08    (1u)
#define DF_ENABLE_TS09    (1u)
#define DF_ENABLE_TS10    (1u)
#define DF_ENABLE_TS11    (0u)
#define DF_ENABLE_TS12    (0u)
#define DF_ENABLE_TS13    (0u)
#define DF_ENABLE_TS14    (0u)
#define DF_ENABLE_TS15    (0u)
#define DF_ENABLE_TS16    (0u)
#define DF_ENABLE_TS17    (0u)
#define DF_ENABLE_TS18    (0u)
#define DF_ENABLE_TS19    (0u)
#define DF_ENABLE_TS20    (0u)
#define DF_ENABLE_TS21    (0u)
#define DF_ENABLE_TS22    (0u)
#define DF_ENABLE_TS23    (0u)
#define DF_ENABLE_TS24    (0u)
#define DF_ENABLE_TS25    (0u)
#define DF_ENABLE_TS26    (0u)
#define DF_ENABLE_TS27    (0u)
#define DF_ENABLE_TS28    (0u)
#define DF_ENABLE_TS29    (0u)
#define DF_ENABLE_TS30    (0u)
#define DF_ENABLE_TS31    (0u)
#define DF_ENABLE_TS32    (0u)
#define DF_ENABLE_TS33    (0u)
#define DF_ENABLE_TS34    (0u)
#define DF_ENABLE_TS35    (0u)

/* SUM of Channels */ /* Do not edit this macro definition */
#define SUM_TS (DF_ENABLE_TS00 + DF_ENABLE_TS01 + DF_ENABLE_TS02 + DF_ENABLE_TS03 + \
                DF_ENABLE_TS04 + DF_ENABLE_TS05 + DF_ENABLE_TS06 + DF_ENABLE_TS07 + \
                DF_ENABLE_TS08 + DF_ENABLE_TS09 + DF_ENABLE_TS10 + DF_ENABLE_TS11 + \
                DF_ENABLE_TS12 + DF_ENABLE_TS13 + DF_ENABLE_TS14 + DF_ENABLE_TS15 + \
                DF_ENABLE_TS16 + DF_ENABLE_TS17 + DF_ENABLE_TS18 + DF_ENABLE_TS19 + \
                DF_ENABLE_TS20 + DF_ENABLE_TS21 + DF_ENABLE_TS22 + DF_ENABLE_TS23 + \
                DF_ENABLE_TS24 + DF_ENABLE_TS25 + DF_ENABLE_TS26 + DF_ENABLE_TS27 + \
                DF_ENABLE_TS28 + DF_ENABLE_TS29 + DF_ENABLE_TS30 + DF_ENABLE_TS31 + \
                DF_ENABLE_TS32 + DF_ENABLE_TS33 + DF_ENABLE_TS34 + DF_ENABLE_TS35)
#define MAX_TS    (12u)  /* (for RX113 / not change) */

#define KEY_USE
#undef SLIDER_USE
#undef WHEEL_USE

#if !defined(KEY_USE) && !defined(SLIDER_USE) && !defined(WHEEL_USE)
    #error "Exactly one of USE-options (KEY_USE/SLIDER_USE/WHEEL_USE) must be specified "
#endif

/* Communication command version */
#define DF_CCMD_VER    (0)

/* Chip ID */
//#define    DF_CHIP_ID    ((DF_CCMD_VER << 8) | MAX_TS)

/* Profile information */
#define DF_PROFILE    (0x1234)
#define WORKBENCH_COMMAND_USE
#define TS_NON    (0xff)

/* Multi Touch Cancel */
#define DF_MTC_ONOFF       (OFF)      /* ON/OFF */
#define DF_MTC_START_TS    (0)
#define DF_MTC_END_TS      (11)

/* Touch ON/OFF judgment */
#define DF_ACD_ON     (3)      /* 0-255 The cumulative number of determinations of [ON]     */
#define DF_ACD_OFF    (3)      /* 0-255 The cumulative number of determinations of [OFF]    */
#define DF_MSA        (0)      /* 0-65535 Maximum continuous [ON], 0:no use                 */

/* Drift Correction */
#define DF_DC_FUNCTION    (ON)      /* ON/OFF     */
#define DF_DCI            (128)     /* 0-65535    */

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                  Self parameter definition                 ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#ifndef MUTUAL_FUNC_USE

/* ON/OFF threshold set up data */
#define DF_TS00_THR    (1000)
#define DF_TS01_THR    (1001)
#define DF_TS02_THR    (1002)
#define DF_TS03_THR    (1003)
#define DF_TS04_THR    (1004)
#define DF_TS05_THR    (1005)
#define DF_TS06_THR    (1006)
#define DF_TS07_THR    (1007)
#define DF_TS08_THR    (1008)
#define DF_TS09_THR    (1009)
#define DF_TS10_THR    (1010)
#define DF_TS11_THR    (1011)
#define DF_TS12_THR    (1012)
#define DF_TS13_THR    (1013)
#define DF_TS14_THR    (1014)
#define DF_TS15_THR    (1015)
#define DF_TS16_THR    (1016)
#define DF_TS17_THR    (1017)
#define DF_TS18_THR    (1018)
#define DF_TS19_THR    (1019)
#define DF_TS20_THR    (1020)
#define DF_TS21_THR    (1021)
#define DF_TS22_THR    (1022)
#define DF_TS23_THR    (1023)
#define DF_TS24_THR    (1024)
#define DF_TS25_THR    (1025)
#define DF_TS26_THR    (1026)
#define DF_TS27_THR    (1027)
#define DF_TS28_THR    (1028)
#define DF_TS29_THR    (1029)
#define DF_TS30_THR    (1030)
#define DF_TS31_THR    (1031)
#define DF_TS32_THR    (1032)
#define DF_TS33_THR    (1033)
#define DF_TS34_THR    (1034)
#define DF_TS35_THR    (1035)

/* Hysteresis set up data */
#define DF_TS00_HYS    (50)
#define DF_TS01_HYS    (51)
#define DF_TS02_HYS    (52)
#define DF_TS03_HYS    (53)
#define DF_TS04_HYS    (54)
#define DF_TS05_HYS    (55)
#define DF_TS06_HYS    (56)
#define DF_TS07_HYS    (57)
#define DF_TS08_HYS    (58)
#define DF_TS09_HYS    (59)
#define DF_TS10_HYS    (60)
#define DF_TS11_HYS    (61)
#define DF_TS12_HYS    (62)
#define DF_TS13_HYS    (63)
#define DF_TS14_HYS    (64)
#define DF_TS15_HYS    (65)
#define DF_TS16_HYS    (66)
#define DF_TS17_HYS    (67)
#define DF_TS18_HYS    (68)
#define DF_TS19_HYS    (69)
#define DF_TS20_HYS    (70)
#define DF_TS21_HYS    (71)
#define DF_TS22_HYS    (72)
#define DF_TS23_HYS    (73)
#define DF_TS24_HYS    (74)
#define DF_TS25_HYS    (75)
#define DF_TS26_HYS    (76)
#define DF_TS27_HYS    (77)
#define DF_TS28_HYS    (78)
#define DF_TS29_HYS    (79)
#define DF_TS30_HYS    (80)
#define DF_TS31_HYS    (81)
#define DF_TS32_HYS    (82)
#define DF_TS33_HYS    (83)
#define DF_TS34_HYS    (84)
#define DF_TS35_HYS    (85)

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                Mutual parameter definition                 ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#else

#define RECEIVE_FUNCITON    (0)
#define SEND_FUNCITON       (1)

#define DF_TS00_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS01_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS02_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS03_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS04_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS05_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS06_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS07_FUNCTION    (SEND_FUNCITON)             /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS08_FUNCTION    (SEND_FUNCITON)             /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS09_FUNCTION    (SEND_FUNCITON)             /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS10_FUNCTION    (SEND_FUNCITON)             /* SEND_FUNCITON or RECEIVE_FUNCITON                */
#define DF_TS11_FUNCTION    (RECEIVE_FUNCITON)          /* SEND_FUNCITON or RECEIVE_FUNCITON                */

#define SEND_NUM (DF_TS00_FUNCTION + DF_TS01_FUNCTION + DF_TS02_FUNCTION + DF_TS03_FUNCTION + \
                  DF_TS04_FUNCTION + DF_TS05_FUNCTION + DF_TS06_FUNCTION + DF_TS07_FUNCTION + \
                  DF_TS08_FUNCTION + DF_TS09_FUNCTION + DF_TS10_FUNCTION + DF_TS11_FUNCTION)
#define RECEIVE_NUM    (SUM_TS - SEND_NUM)
#define MEASURE_NUM    (SEND_NUM * RECEIVE_NUM)

#if SEND_NUM == 0
    #error "Send TS Setting error ( SEND_NUM = 0 )"
#endif
#if RECEIVE_NUM == 0
    #error "Receive TS Setting error ( RECEIVE_NUM = 0 )"
#endif

/* ON/OFF threshold set up data */
#define DF_TS00_00_THR    (200)
#define DF_TS00_01_THR    (200)
#define DF_TS00_02_THR    (200)
#define DF_TS00_03_THR    (200)
#define DF_TS00_04_THR    (200)
#define DF_TS00_05_THR    (200)
#define DF_TS00_06_THR    (1000)
#define DF_TS00_07_THR    (1000)
#define DF_TS00_08_THR    (1000)
#define DF_TS00_09_THR    (1000)
#define DF_TS00_10_THR    (1000)

#define DF_TS01_00_THR    (201)
#define DF_TS01_01_THR    (201)
#define DF_TS01_02_THR    (201)
#define DF_TS01_03_THR    (201)
#define DF_TS01_04_THR    (201)
#define DF_TS01_05_THR    (201)
#define DF_TS01_06_THR    (1001)
#define DF_TS01_07_THR    (1001)
#define DF_TS01_08_THR    (1001)
#define DF_TS01_09_THR    (1001)
#define DF_TS01_10_THR    (1001)

#define DF_TS02_00_THR    (202)
#define DF_TS02_01_THR    (202)
#define DF_TS02_02_THR    (202)
#define DF_TS02_03_THR    (202)
#define DF_TS02_04_THR    (202)
#define DF_TS02_05_THR    (202)
#define DF_TS02_06_THR    (1002)
#define DF_TS02_07_THR    (1002)
#define DF_TS02_08_THR    (1002)
#define DF_TS02_09_THR    (1002)
#define DF_TS02_10_THR    (1002)

#define DF_TS03_00_THR    (203)
#define DF_TS03_01_THR    (203)
#define DF_TS03_02_THR    (203)
#define DF_TS03_03_THR    (203)
#define DF_TS03_04_THR    (203)
#define DF_TS03_05_THR    (203)
#define DF_TS03_06_THR    (1003)
#define DF_TS03_07_THR    (1003)
#define DF_TS03_08_THR    (1003)
#define DF_TS03_09_THR    (1003)
#define DF_TS03_10_THR    (1003)

#define DF_TS04_00_THR    (204)
#define DF_TS04_01_THR    (204)
#define DF_TS04_02_THR    (204)
#define DF_TS04_03_THR    (204)
#define DF_TS04_04_THR    (204)
#define DF_TS04_05_THR    (204)
#define DF_TS04_06_THR    (1004)
#define DF_TS04_07_THR    (1004)
#define DF_TS04_08_THR    (1004)
#define DF_TS04_09_THR    (1004)
#define DF_TS04_10_THR    (1004)

#define DF_TS05_00_THR    (205)
#define DF_TS05_01_THR    (205)
#define DF_TS05_02_THR    (205)
#define DF_TS05_03_THR    (205)
#define DF_TS05_04_THR    (205)
#define DF_TS05_05_THR    (205)
#define DF_TS05_06_THR    (1005)
#define DF_TS05_07_THR    (1005)
#define DF_TS05_08_THR    (1005)
#define DF_TS05_09_THR    (1005)
#define DF_TS05_10_THR    (1005)

#define DF_TS06_00_THR    (1006)
#define DF_TS06_01_THR    (1006)
#define DF_TS06_02_THR    (1006)
#define DF_TS06_03_THR    (1006)
#define DF_TS06_04_THR    (1006)
#define DF_TS06_05_THR    (1006)
#define DF_TS06_06_THR    (1006)
#define DF_TS06_07_THR    (1006)
#define DF_TS06_08_THR    (1006)
#define DF_TS06_09_THR    (1006)
#define DF_TS06_10_THR    (1006)

#define DF_TS07_00_THR    (811)
#define DF_TS07_01_THR    (973)
#define DF_TS07_02_THR    (963)
#define DF_TS07_03_THR    (1007)
#define DF_TS07_04_THR    (1007)
#define DF_TS07_05_THR    (1007)
#define DF_TS07_06_THR    (1007)
#define DF_TS07_07_THR    (1007)
#define DF_TS07_08_THR    (1007)
#define DF_TS07_09_THR    (1007)
#define DF_TS07_10_THR    (1007)

#define DF_TS08_00_THR    (609)
#define DF_TS08_01_THR    (679)
#define DF_TS08_02_THR    (812)
#define DF_TS08_03_THR    (1008)
#define DF_TS08_04_THR    (1008)
#define DF_TS08_05_THR    (1008)
#define DF_TS08_06_THR    (1008)
#define DF_TS08_07_THR    (1008)
#define DF_TS08_08_THR    (1008)
#define DF_TS08_09_THR    (1008)
#define DF_TS08_10_THR    (1008)

#define DF_TS09_00_THR    (717)
#define DF_TS09_01_THR    (1302)
#define DF_TS09_02_THR    (858)
#define DF_TS09_03_THR    (1009)
#define DF_TS09_04_THR    (1009)
#define DF_TS09_05_THR    (1009)
#define DF_TS09_06_THR    (1009)
#define DF_TS09_07_THR    (1009)
#define DF_TS09_08_THR    (1009)
#define DF_TS09_09_THR    (1009)
#define DF_TS09_10_THR    (1009)

#define DF_TS10_00_THR    (924)
#define DF_TS10_01_THR    (1110)
#define DF_TS10_02_THR    (1274)
#define DF_TS10_03_THR    (1010)
#define DF_TS10_04_THR    (1010)
#define DF_TS10_05_THR    (1010)
#define DF_TS10_06_THR    (1010)
#define DF_TS10_07_THR    (1010)
#define DF_TS10_08_THR    (1010)
#define DF_TS10_09_THR    (1010)
#define DF_TS10_10_THR    (1010)

#define DF_TS11_00_THR    (1011)
#define DF_TS11_01_THR    (1011)
#define DF_TS11_02_THR    (1011)
#define DF_TS11_03_THR    (1011)
#define DF_TS11_04_THR    (1011)
#define DF_TS11_05_THR    (1011)
#define DF_TS11_06_THR    (1011)
#define DF_TS11_07_THR    (1011)
#define DF_TS11_08_THR    (1011)
#define DF_TS11_09_THR    (1011)
#define DF_TS11_10_THR    (1011)

/* Hysteresis set up data */
#define DF_TS00_00_HYS    (10)
#define DF_TS00_01_HYS    (10)
#define DF_TS00_02_HYS    (10)
#define DF_TS00_03_HYS    (10)
#define DF_TS00_04_HYS    (10)
#define DF_TS00_05_HYS    (10)
#define DF_TS00_06_HYS    (50)
#define DF_TS00_07_HYS    (50)
#define DF_TS00_08_HYS    (50)
#define DF_TS00_09_HYS    (50)
#define DF_TS00_10_HYS    (50)

#define DF_TS01_00_HYS    (11)
#define DF_TS01_01_HYS    (11)
#define DF_TS01_02_HYS    (11)
#define DF_TS01_03_HYS    (11)
#define DF_TS01_04_HYS    (11)
#define DF_TS01_05_HYS    (11)
#define DF_TS01_06_HYS    (51)
#define DF_TS01_07_HYS    (51)
#define DF_TS01_08_HYS    (51)
#define DF_TS01_09_HYS    (51)
#define DF_TS01_10_HYS    (51)

#define DF_TS02_00_HYS    (12)
#define DF_TS02_01_HYS    (12)
#define DF_TS02_02_HYS    (12)
#define DF_TS02_03_HYS    (12)
#define DF_TS02_04_HYS    (12)
#define DF_TS02_05_HYS    (12)
#define DF_TS02_06_HYS    (52)
#define DF_TS02_07_HYS    (52)
#define DF_TS02_08_HYS    (52)
#define DF_TS02_09_HYS    (52)
#define DF_TS02_10_HYS    (52)

#define DF_TS03_00_HYS    (13)
#define DF_TS03_01_HYS    (13)
#define DF_TS03_02_HYS    (13)
#define DF_TS03_03_HYS    (13)
#define DF_TS03_04_HYS    (13)
#define DF_TS03_05_HYS    (13)
#define DF_TS03_06_HYS    (53)
#define DF_TS03_07_HYS    (53)
#define DF_TS03_08_HYS    (53)
#define DF_TS03_09_HYS    (53)
#define DF_TS03_10_HYS    (53)

#define DF_TS04_00_HYS    (14)
#define DF_TS04_01_HYS    (14)
#define DF_TS04_02_HYS    (14)
#define DF_TS04_03_HYS    (14)
#define DF_TS04_04_HYS    (14)
#define DF_TS04_05_HYS    (14)
#define DF_TS04_06_HYS    (54)
#define DF_TS04_07_HYS    (54)
#define DF_TS04_08_HYS    (54)
#define DF_TS04_09_HYS    (54)
#define DF_TS04_10_HYS    (54)

#define DF_TS05_00_HYS    (15)
#define DF_TS05_01_HYS    (15)
#define DF_TS05_02_HYS    (15)
#define DF_TS05_03_HYS    (15)
#define DF_TS05_04_HYS    (15)
#define DF_TS05_05_HYS    (15)
#define DF_TS05_06_HYS    (55)
#define DF_TS05_07_HYS    (55)
#define DF_TS05_08_HYS    (55)
#define DF_TS05_09_HYS    (55)
#define DF_TS05_10_HYS    (55)

#define DF_TS06_00_HYS    (56)
#define DF_TS06_01_HYS    (56)
#define DF_TS06_02_HYS    (56)
#define DF_TS06_03_HYS    (56)
#define DF_TS06_04_HYS    (56)
#define DF_TS06_05_HYS    (56)
#define DF_TS06_06_HYS    (56)
#define DF_TS06_07_HYS    (56)
#define DF_TS06_08_HYS    (56)
#define DF_TS06_09_HYS    (56)
#define DF_TS06_10_HYS    (56)

#define DF_TS07_00_HYS    (57)
#define DF_TS07_01_HYS    (57)
#define DF_TS07_02_HYS    (57)
#define DF_TS07_03_HYS    (57)
#define DF_TS07_04_HYS    (57)
#define DF_TS07_05_HYS    (57)
#define DF_TS07_06_HYS    (57)
#define DF_TS07_07_HYS    (57)
#define DF_TS07_08_HYS    (57)
#define DF_TS07_09_HYS    (57)
#define DF_TS07_10_HYS    (57)

#define DF_TS08_00_HYS    (58)
#define DF_TS08_01_HYS    (58)
#define DF_TS08_02_HYS    (58)
#define DF_TS08_03_HYS    (58)
#define DF_TS08_04_HYS    (58)
#define DF_TS08_05_HYS    (58)
#define DF_TS08_06_HYS    (58)
#define DF_TS08_07_HYS    (58)
#define DF_TS08_08_HYS    (58)
#define DF_TS08_09_HYS    (58)
#define DF_TS08_10_HYS    (58)

#define DF_TS09_00_HYS    (59)
#define DF_TS09_01_HYS    (59)
#define DF_TS09_02_HYS    (59)
#define DF_TS09_03_HYS    (59)
#define DF_TS09_04_HYS    (59)
#define DF_TS09_05_HYS    (59)
#define DF_TS09_06_HYS    (59)
#define DF_TS09_07_HYS    (59)
#define DF_TS09_08_HYS    (59)
#define DF_TS09_09_HYS    (59)
#define DF_TS09_10_HYS    (59)

#define DF_TS10_00_HYS    (60)
#define DF_TS10_01_HYS    (60)
#define DF_TS10_02_HYS    (60)
#define DF_TS10_03_HYS    (60)
#define DF_TS10_04_HYS    (60)
#define DF_TS10_05_HYS    (60)
#define DF_TS10_06_HYS    (60)
#define DF_TS10_07_HYS    (60)
#define DF_TS10_08_HYS    (60)
#define DF_TS10_09_HYS    (60)
#define DF_TS10_10_HYS    (60)

#define DF_TS11_00_HYS    (61)
#define DF_TS11_01_HYS    (61)
#define DF_TS11_02_HYS    (61)
#define DF_TS11_03_HYS    (61)
#define DF_TS11_04_HYS    (61)
#define DF_TS11_05_HYS    (61)
#define DF_TS11_06_HYS    (61)
#define DF_TS11_07_HYS    (61)
#define DF_TS11_08_HYS    (61)
#define DF_TS11_09_HYS    (61)
#define DF_TS11_10_HYS    (61)

#endif    //] MUTUAL_FUNC_USE

/* Chip ID */
#ifdef MUTUAL_FUNC_USE
    #define DF_CHIP_ID    ((DF_CCMD_VER << 8) | MEASURE_NUM)
#else    // MUTUAL_FUNC_USE
    #define DF_CHIP_ID    ((DF_CCMD_VER << 8) | MAX_TS)
#endif    // MUTUAL_FUNC_USE

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef struct
{
    uint8_t     ts[10];                /* Touch sensor number                          */
    uint8_t     num;                   /* Electrodes number                            */
    uint16_t    threshold;             /* Position calculation startthreshold value    */
    uint16_t    resolution;            /* Position resolution                          */
    uint16_t    value;                 /*                                              */
} slider_wheel_info_t;

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/

#endif //] __R_CTSC_PARAMETER_COMMON_H__
