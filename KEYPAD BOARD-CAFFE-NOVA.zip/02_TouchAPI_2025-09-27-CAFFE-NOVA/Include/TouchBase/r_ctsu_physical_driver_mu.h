/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_physical_driver_mu.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#ifndef __R_CTSU_PHYSICAL_DRIVER_MU_H__ //[
#define __R_CTSU_PHYSICAL_DRIVER_MU_H__

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_ctsu_parameter_common.h"
#include "r_ctsu_common_control.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef  __R_CTSU_PHYSICAL_DRIVER_C__
    #define CTSU_EXTERN
#else
    #define CTSU_EXTERN extern
#endif

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* #define WORKBENCH_USB     (1) */

/* Select the clock condition */
#define TOUCH_SAMPLE_CLOCK_SOURCE    (4)
#define TOUCH_SAMPLE_HOCO_HZ         (32000000)
#define TOUCH_SAMPLE_XTAL_HZ         (16000000)
#define TOUCH_SAMPLE_SYSTEM_HZ       (32000000)

/* Clock Source */
#define TOUCH_CLOCK_SOURCE_LOCO     (0)         /* Low Speed On-Chip Oscillator  (LOCO)                  */
#define TOUCH_CLOCK_SOURCE_HOCO     (1)         /* High Speed On-Chip Oscillator (HOCO)                  */
#define TOUCH_CLOCK_SOURCE_MAIN     (2)         /* Main Clock Oscillator                                 */
#define TOUCH_CLOCK_SOURCE_SUB      (3)         /* Sub-Clock Oscillator                                  */
#define TOUCH_CLOCK_SOURCE_PLL      (4)         /* PLL Circuit                                           */

/* Clock Frequency */
#define TOUCH_SAMPLE_6MHZ           (6000000)   /* 6MHz                                                  */
#define TOUCH_SAMPLE_8MHZ           (8000000)   /* 8MHz                                                  */
#define TOUCH_SAMPLE_10MHZ          (10000000)  /* 10MHz                                                 */
#define TOUCH_SAMPLE_12MHZ          (12000000)  /* 12MHz                                                 */
#define TOUCH_SAMPLE_16MHZ          (16000000)  /* 16MHz                                                 */
#define TOUCH_SAMPLE_32MHZ          (32000000)  /* 32MHz                                                 */

/* USB Serial Use */
#if(TOUCH_SAMPLE_CLOCK_SOURCE == TOUCH_CLOCK_SOURCE_PLL)    /* PLL Select(Main Clock)                    */
  #if((TOUCH_SAMPLE_XTAL_HZ == TOUCH_SAMPLE_16MHZ) || (TOUCH_SAMPLE_XTAL_HZ == TOUCH_SAMPLE_8MHZ))
    #define USB_SERIAL_USE
  #else
    #undef USB_SERIAL_USE
  #endif
#elif(TOUCH_SAMPLE_CLOCK_SOURCE == TOUCH_CLOCK_SOURCE_HOCO) /* HOCO Select                               */
    #undef USB_SERIAL_USE
#else
    #undef USB_SERIAL_USE
#endif

/***** Touch measurement cycle ****************************************************************************************/
/* Touch Measurement cycle (ms) */
#define TOUCH_MEASUREMENT_CYCLE_MS       (20)

/* Touch Measurement cycle macro (ms) */
#define TOUCH_MEASUREMENT_20MS           (20)
#define TOUCH_MEASUREMENT_40MS           (40)

/* Compare Match Timer Control Register Clock Select PCLK/xxx */
#define CTSU_CMCOR_CKS         (128)

#if(TOUCH_MEASUREMENT_CYCLE_MS == TOUCH_MEASUREMENT_20MS)
    #define TOUCH_CMT_FREQUENCY_HZ      (50)       /* 20ms = 50Hz */
#elif(TOUCH_MEASUREMENT_CYCLE_MS == TOUCH_MEASUREMENT_40MS)
    #define TOUCH_CMT_FREQUENCY_HZ      (25)       /* 40ms = 25Hz */
#else
#endif

/* Compare Match Constant Register for Touch */
#define TOUCH_CMCOR_VALUE       (TOUCH_SAMPLE_SYSTEM_HZ/CTSU_CMCOR_CKS)/TOUCH_CMT_FREQUENCY_HZ

/***** A0900h   CTSU control register0  *********************************************************************/
#define DF_CTSUCAP      (0)             /* 0 = software trigger                                             */
                                        /* 1 = external trigger                                             */
#define DF_CTSUIOC      (0)             /* 0 = non-measurement pin low level                                */
                                        /* 1 = non-measurement pin high level                               */

/***** A0901h   CTSU channel register1  *********************************************************************/
#define DF_CTSUPON      (1)             /* 0 = CTSU hardware macro power off                                */
                                        /* 1 = CTSU hardware macro power on                                 */
#define DF_CTSUCSW      (1)             /* 0 = Capacitance switch turned off                                */
                                        /* 1 = Capacitance switch turned on                                 */
#define DF_CTSUATUNE0   (0)             /* 0 = Normal operating mode                                        */
                                        /* 1 = Low-voltage operating mode                                   */
#define DF_CTSUATUNE1   (1)             /* 0 = Normal output                                                */
                                        /* 1 = High-current output                                          */
#define DF_CTSUCLK      (0)             /* 0 = PCLK                                                         */
                                        /* 1 = PCLK/2                                                       */
                                        /* 2 = PCLK/4                                                       */
#define DF_CTSUMD       (3)             /* 0 = Self-capacitance single scan mode                            */
                                        /* 1 = Self-capacitance multi-scan mode                             */
                                        /* 2 = Setting prohibited                                           */
                                        /* 3 = Mutual capacitance full scan mode                            */
#define DF_CTSUCR1      ((DF_CTSUMD << 6)  | (DF_CTSUCLK << 4) | (DF_CTSUATUNE1 << 3) | (DF_CTSUATUNE0 << 2)| \
                         (DF_CTSUCSW << 1) | DF_CTSUPON)

/***** A0902h   CTSU Sensor drive pulse spectrum diffusion set register *************************************/
#define DF_CTSUPRRATIO  (3)             /* 3 = Recommended setting value                                    */
#define DF_CTSUPRMODE   (2)             /* 0 = 510 pulses                                                   */
                                        /* 1 = 126 pulses                                                   */
                                        /* 2 = 62 pulses (recommended setting value)                        */
                                        /* 3 = Setting prohibited                                           */
#define DF_CTSUSOFF     (0)             /* 0 = High-pass noise reduction function turned on                 */
                                        /* 1 = High-pass noise reduction function turned off                */
#define DF_CTSUSDPRS    (DF_CTSUSOFF << 6) | (DF_CTSUPRMODE << 4) | DF_CTSUPRRATIO

/***** A0903h   CTSU Sensor wait time register **************************************************************/
#define DF_CTSUSST      (16)            /* The value of these bits should be fixed to 00010000b             */

/***** A0904h   CTSU Measurement channel register0 **********************************************************/
#define DF_CTSUMCH0     (0x00)          /* 0x00 = TS1 ---> 0x0B = TS11                                      */

/***** A0905h   CTSU Measurement channel register1 **********************************************************/
#define DF_CTSUMCH1     (0x00)          /* 0x00 = TS1 ---> 0x0B = TS11                                      */

/***** A0906h   CTSU Channel enable control register0 ******************************************************/
#define DF_CTSUCHAC0    ((DF_ENABLE_TS00 << 0) | (DF_ENABLE_TS01 << 1) | (DF_ENABLE_TS02 << 2) | \
                         (DF_ENABLE_TS03 << 3) | (DF_ENABLE_TS04 << 4) | (DF_ENABLE_TS05 << 5) | \
                         (DF_ENABLE_TS06 << 6) | (DF_ENABLE_TS07 << 7))
                                        /* 0 = disenable                                                    */
                                        /* 1 = enable                                                       */
                                        /* ex) 0x03 ---> TS0-TS1 enable   0xFF ---> TS0-TS7 enable          */

/***** A0907h   CTSU Channel enable control register1 ******************************************************/
#define DF_CTSUCHAC1    ((DF_ENABLE_TS08 << 0) | (DF_ENABLE_TS09 << 1) | (DF_ENABLE_TS10 << 2) | \
                         (DF_ENABLE_TS11 << 3) | (DF_ENABLE_TS12 << 4) | (DF_ENABLE_TS13 << 5) | \
                         (DF_ENABLE_TS14 << 6) | (DF_ENABLE_TS15 << 7))
                                        /* 0 = disenable                                                    */
                                        /* 1 = enable                                                       */
                                        /* ex) 0x03 ---> TS8-TS9 enable   0x0F ---> TS8-TS11 enable         */

/***** A090*h   CTSU Channel enable control register2 ******************************************************/
#define DF_CTSUCHAC2    ((DF_ENABLE_TS16 << 0) | (DF_ENABLE_TS17 << 1) | (DF_ENABLE_TS18 << 2) | \
                         (DF_ENABLE_TS19 << 3) | (DF_ENABLE_TS20 << 4) | (DF_ENABLE_TS21 << 5) | \
                         (DF_ENABLE_TS22 << 6) | (DF_ENABLE_TS23 << 7))

/***** A090*h   CTSU Channel enable control register3 ******************************************************/
#define DF_CTSUCHAC3    ((DF_ENABLE_TS24 << 0) | (DF_ENABLE_TS25 << 1) | (DF_ENABLE_TS26 << 2) | \
                         (DF_ENABLE_TS27 << 3) | (DF_ENABLE_TS28 << 4) | (DF_ENABLE_TS29 << 5) | \
                         (DF_ENABLE_TS30 << 6) | (DF_ENABLE_TS31 << 7))

/***** A090*h   CTSU Channel enable control register4 ******************************************************/
#define DF_CTSUCHAC4    ((DF_ENABLE_TS32 << 0) | (DF_ENABLE_TS33 << 1) | (DF_ENABLE_TS34 << 2) | \
                         (DF_ENABLE_TS35 << 3))

/***** A090Bh   CTSU Channel send and receive control register0 *********************************************/
#define DF_CTSUCHTRC0   ((DF_TS00_FUNCTION << 0) | (DF_TS01_FUNCTION << 1) | (DF_TS02_FUNCTION << 2) | \
                         (DF_TS03_FUNCTION << 3) | (DF_TS04_FUNCTION << 4) | (DF_TS05_FUNCTION << 5) | \
                         (DF_TS06_FUNCTION << 6) | (DF_TS07_FUNCTION << 7))
                                        /* 0 = receive                                                      */
                                        /* 1 = send                                                         */
                                        /* ex) 0x03 ---> TS0-TS1 send   TS2-TS7 receive                     */

/***** A090Ch   CTSU Channel send and receive control register1 *********************************************/
#define DF_CTSUCHTRC1   ((DF_TS08_FUNCTION << 0) | (DF_TS09_FUNCTION << 1) | (DF_TS10_FUNCTION << 2) | \
                         (DF_TS11_FUNCTION << 3))
                                        /* 0 = receive                                                      */
                                        /* 1 = send                                                         */
                                        /* ex) 0x03 ---> TS8-TS9 send   TS10-TS11 receive                   */

/***** A0910h   CTSU Diffusion clock  control register ******************************************************/
#define DF_CTSUSSMOD    (0)             /* These bits should be set to 00b.                                 */
#define DF_CTSUSSCNT    (3)             /* These bits should be set to 11b.                                 */
#define DF_CTSUDCLKC    ((DF_CTSUSSCNT << 4) | DF_CTSUSSMOD)

/***** A0912h   CTSU Spectrum diffusion control register ****************************************************/
/* CTSU Spectrum Diffusion Sampling Cycle Control
   b3-b0 -> 0-15 (or 0x00-0x0F)
   The sampling cycle of the edge diffusion function can be set to divided by 1 to divided by 16. */
#if DF_TS00_FUNCTION == 1
        #define DF_TS00_00_SSDIV        (0x01)
        #define DF_TS00_00_CTSUSSC      (DF_TS00_00_SSDIV << 8)
        #define DF_TS00_00_SO           (0x000)
        #define DF_TS00_00_SNUM         (3)
        #define DF_TS00_00_CTSUSO0      ((DF_TS00_00_SNUM << 10) | DF_TS00_00_SO)
        #define DF_TS00_00_RICOA        (0x3F)
        #define DF_TS00_00_SDPA         (7)
        #define DF_TS00_00_ICOG         (1)
        #define DF_TS00_00_CTSUSO1      ((DF_TS00_00_ICOG << 13) | (DF_TS00_00_SDPA << 8) | DF_TS00_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS00_01_SSDIV        (0x01)
        #define DF_TS00_01_CTSUSSC      (DF_TS00_01_SSDIV << 8)
        #define DF_TS00_01_SO           (0x000)
        #define DF_TS00_01_SNUM         (3)
        #define DF_TS00_01_CTSUSO0      ((DF_TS00_01_SNUM << 10) | DF_TS00_01_SO)
        #define DF_TS00_01_RICOA        (0x3F)
        #define DF_TS00_01_SDPA         (7)
        #define DF_TS00_01_ICOG         (1)
        #define DF_TS00_01_CTSUSO1      ((DF_TS00_01_ICOG << 13) | (DF_TS00_01_SDPA << 8) | DF_TS00_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS00_02_SSDIV        (0x01)
        #define DF_TS00_02_CTSUSSC      (DF_TS00_02_SSDIV << 8)
        #define DF_TS00_02_SO           (0x000)
        #define DF_TS00_02_SNUM         (3)
        #define DF_TS00_02_CTSUSO0      ((DF_TS00_02_SNUM << 10) | DF_TS00_02_SO)
        #define DF_TS00_02_RICOA        (0x3F)
        #define DF_TS00_02_SDPA         (7)
        #define DF_TS00_02_ICOG         (1)
        #define DF_TS00_02_CTSUSO1      ((DF_TS00_02_ICOG << 13) | (DF_TS00_02_SDPA << 8) | DF_TS00_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS00_03_SSDIV        (0x01)
        #define DF_TS00_03_CTSUSSC      (DF_TS00_03_SSDIV << 8)
        #define DF_TS00_03_SO           (0x000)
        #define DF_TS00_03_SNUM         (3)
        #define DF_TS00_03_CTSUSO0      ((DF_TS00_03_SNUM << 10) | DF_TS00_03_SO)
        #define DF_TS00_03_RICOA        (0x3F)
        #define DF_TS00_03_SDPA         (7)
        #define DF_TS00_03_ICOG         (1)
        #define DF_TS00_03_CTSUSO1      ((DF_TS00_03_ICOG << 13) | (DF_TS00_03_SDPA << 8) | DF_TS00_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS00_04_SSDIV        (0x01)
        #define DF_TS00_04_CTSUSSC      (DF_TS00_04_SSDIV << 8)
        #define DF_TS00_04_SO           (0x000)
        #define DF_TS00_04_SNUM         (3)
        #define DF_TS00_04_CTSUSO0      ((DF_TS00_04_SNUM << 10) | DF_TS00_04_SO)
        #define DF_TS00_04_RICOA        (0x3F)
        #define DF_TS00_04_SDPA         (7)
        #define DF_TS00_04_ICOG         (1)
        #define DF_TS00_04_CTSUSO1      ((DF_TS00_04_ICOG << 13) | (DF_TS00_04_SDPA << 8) | DF_TS00_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS00_05_SSDIV        (0x01)
        #define DF_TS00_05_CTSUSSC      (DF_TS00_05_SSDIV << 8)
        #define DF_TS00_05_SO           (0x000)
        #define DF_TS00_05_SNUM         (3)
        #define DF_TS00_05_CTSUSO0      ((DF_TS00_05_SNUM << 10) | DF_TS00_05_SO)
        #define DF_TS00_05_RICOA        (0x3F)
        #define DF_TS00_05_SDPA         (7)
        #define DF_TS00_05_ICOG         (1)
        #define DF_TS00_05_CTSUSO1      ((DF_TS00_05_ICOG << 13) | (DF_TS00_05_SDPA << 8) | DF_TS00_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS00_06_SSDIV        (0x01)
        #define DF_TS00_06_CTSUSSC      (DF_TS00_06_SSDIV << 8)
        #define DF_TS00_06_SO           (0x000)
        #define DF_TS00_06_SNUM         (3)
        #define DF_TS00_06_CTSUSO0      ((DF_TS00_06_SNUM << 10) | DF_TS00_06_SO)
        #define DF_TS00_06_RICOA        (0x3F)
        #define DF_TS00_06_SDPA         (7)
        #define DF_TS00_06_ICOG         (1)
        #define DF_TS00_06_CTSUSO1      ((DF_TS00_06_ICOG << 13) | (DF_TS00_06_SDPA << 8) | DF_TS00_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS00_07_SSDIV        (0x01)
        #define DF_TS00_07_CTSUSSC      (DF_TS00_07_SSDIV << 8)
        #define DF_TS00_07_SO           (0x000)
        #define DF_TS00_07_SNUM         (3)
        #define DF_TS00_07_CTSUSO0      ((DF_TS00_07_SNUM << 10) | DF_TS00_07_SO)
        #define DF_TS00_07_RICOA        (0x3F)
        #define DF_TS00_07_SDPA         (7)
        #define DF_TS00_07_ICOG         (1)
        #define DF_TS00_07_CTSUSO1      ((DF_TS00_07_ICOG << 13) | (DF_TS00_07_SDPA << 8) | DF_TS00_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS00_08_SSDIV        (0x01)
        #define DF_TS00_08_CTSUSSC      (DF_TS00_08_SSDIV << 8)
        #define DF_TS00_08_SO           (0x000)
        #define DF_TS00_08_SNUM         (3)
        #define DF_TS00_08_CTSUSO0      ((DF_TS00_08_SNUM << 10) | DF_TS00_08_SO)
        #define DF_TS00_08_RICOA        (0x3F)
        #define DF_TS00_08_SDPA         (7)
        #define DF_TS00_08_ICOG         (1)
        #define DF_TS00_08_CTSUSO1      ((DF_TS00_08_ICOG << 13) | (DF_TS00_08_SDPA << 8) | DF_TS00_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS00_09_SSDIV        (0x01)
        #define DF_TS00_09_CTSUSSC      (DF_TS00_09_SSDIV << 8)
        #define DF_TS00_09_SO           (0x000)
        #define DF_TS00_09_SNUM         (3)
        #define DF_TS00_09_CTSUSO0      ((DF_TS00_09_SNUM << 10) | DF_TS00_09_SO)
        #define DF_TS00_09_RICOA        (0x3F)
        #define DF_TS00_09_SDPA         (7)
        #define DF_TS00_09_ICOG         (1)
        #define DF_TS00_09_CTSUSO1      ((DF_TS00_09_ICOG << 13) | (DF_TS00_09_SDPA << 8) | DF_TS00_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS00_10_SSDIV        (0x01)
        #define DF_TS00_10_CTSUSSC      (DF_TS00_10_SSDIV << 8)
        #define DF_TS00_10_SO           (0x000)
        #define DF_TS00_10_SNUM         (3)
        #define DF_TS00_10_CTSUSO0      ((DF_TS00_10_SNUM << 10) | DF_TS00_10_SO)
        #define DF_TS00_10_RICOA        (0x3F)
        #define DF_TS00_10_SDPA         (7)
        #define DF_TS00_10_ICOG         (1)
        #define DF_TS00_10_CTSUSO1      ((DF_TS00_10_ICOG << 13) | (DF_TS00_10_SDPA << 8) | DF_TS00_10_RICOA)
    #endif
#endif

#if DF_TS01_FUNCTION == 1
        #define DF_TS01_00_SSDIV        (0x01)
        #define DF_TS01_00_CTSUSSC      (DF_TS01_00_SSDIV << 8)
        #define DF_TS01_00_SO           (0x000)
        #define DF_TS01_00_SNUM         (3)
        #define DF_TS01_00_CTSUSO0      ((DF_TS01_00_SNUM << 10) | DF_TS01_00_SO)
        #define DF_TS01_00_RICOA        (0x3F)
        #define DF_TS01_00_SDPA         (7)
        #define DF_TS01_00_ICOG         (1)
        #define DF_TS01_00_CTSUSO1      ((DF_TS01_00_ICOG << 13) | (DF_TS01_00_SDPA << 8) | DF_TS01_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS01_01_SSDIV        (0x01)
        #define DF_TS01_01_CTSUSSC      (DF_TS01_01_SSDIV << 8)
        #define DF_TS01_01_SO           (0x000)
        #define DF_TS01_01_SNUM         (3)
        #define DF_TS01_01_CTSUSO0      ((DF_TS01_01_SNUM << 10) | DF_TS01_01_SO)
        #define DF_TS01_01_RICOA        (0x3F)
        #define DF_TS01_01_SDPA         (7)
        #define DF_TS01_01_ICOG         (1)
        #define DF_TS01_01_CTSUSO1      ((DF_TS01_01_ICOG << 13) | (DF_TS01_01_SDPA << 8) | DF_TS01_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS01_02_SSDIV        (0x01)
        #define DF_TS01_02_CTSUSSC      (DF_TS01_02_SSDIV << 8)
        #define DF_TS01_02_SO           (0x000)
        #define DF_TS01_02_SNUM         (3)
        #define DF_TS01_02_CTSUSO0      ((DF_TS01_02_SNUM << 10) | DF_TS01_02_SO)
        #define DF_TS01_02_RICOA        (0x3F)
        #define DF_TS01_02_SDPA         (7)
        #define DF_TS01_02_ICOG         (1)
        #define DF_TS01_02_CTSUSO1      ((DF_TS01_02_ICOG << 13) | (DF_TS01_02_SDPA << 8) | DF_TS01_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS01_03_SSDIV        (0x01)
        #define DF_TS01_03_CTSUSSC      (DF_TS01_03_SSDIV << 8)
        #define DF_TS01_03_SO           (0x000)
        #define DF_TS01_03_SNUM         (3)
        #define DF_TS01_03_CTSUSO0      ((DF_TS01_03_SNUM << 10) | DF_TS01_03_SO)
        #define DF_TS01_03_RICOA        (0x3F)
        #define DF_TS01_03_SDPA         (7)
        #define DF_TS01_03_ICOG         (1)
        #define DF_TS01_03_CTSUSO1      ((DF_TS01_03_ICOG << 13) | (DF_TS01_03_SDPA << 8) | DF_TS01_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS01_04_SSDIV        (0x01)
        #define DF_TS01_04_CTSUSSC      (DF_TS01_04_SSDIV << 8)
        #define DF_TS01_04_SO           (0x000)
        #define DF_TS01_04_SNUM         (3)
        #define DF_TS01_04_CTSUSO0      ((DF_TS01_04_SNUM << 10) | DF_TS01_04_SO)
        #define DF_TS01_04_RICOA        (0x3F)
        #define DF_TS01_04_SDPA         (7)
        #define DF_TS01_04_ICOG         (1)
        #define DF_TS01_04_CTSUSO1      ((DF_TS01_04_ICOG << 13) | (DF_TS01_04_SDPA << 8) | DF_TS01_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS01_05_SSDIV        (0x01)
        #define DF_TS01_05_CTSUSSC      (DF_TS01_05_SSDIV << 8)
        #define DF_TS01_05_SO           0x064
        #define DF_TS01_05_SNUM         (3)
        #define DF_TS01_05_CTSUSO0      ((DF_TS01_05_SNUM << 10) | DF_TS01_05_SO)
        #define DF_TS01_05_RICOA        (0x3F)
        #define DF_TS01_05_SDPA         (7)
        #define DF_TS01_05_ICOG         (1)
        #define DF_TS01_05_CTSUSO1      ((DF_TS01_05_ICOG << 13) | (DF_TS01_05_SDPA << 8) | DF_TS01_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS01_06_SSDIV        (0x01)
        #define DF_TS01_06_CTSUSSC      (DF_TS01_06_SSDIV << 8)
        #define DF_TS01_06_SO           (0x000)
        #define DF_TS01_06_SNUM         (3)
        #define DF_TS01_06_CTSUSO0      ((DF_TS01_06_SNUM << 10) | DF_TS01_06_SO)
        #define DF_TS01_06_RICOA        (0x3F)
        #define DF_TS01_06_SDPA         (7)
        #define DF_TS01_06_ICOG         (1)
        #define DF_TS01_06_CTSUSO1      ((DF_TS01_06_ICOG << 13) | (DF_TS01_06_SDPA << 8) | DF_TS01_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS01_07_SSDIV        (0x01)
        #define DF_TS01_07_CTSUSSC      (DF_TS01_07_SSDIV << 8)
        #define DF_TS01_07_SO           (0x000)
        #define DF_TS01_07_SNUM         (3)
        #define DF_TS01_07_CTSUSO0      ((DF_TS01_07_SNUM << 10) | DF_TS01_07_SO)
        #define DF_TS01_07_RICOA        (0x3F)
        #define DF_TS01_07_SDPA         (7)
        #define DF_TS01_07_ICOG         (1)
        #define DF_TS01_07_CTSUSO1      ((DF_TS01_07_ICOG << 13) | (DF_TS01_07_SDPA << 8) | DF_TS01_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS01_08_SSDIV        (0x01)
        #define DF_TS01_08_CTSUSSC      (DF_TS01_08_SSDIV << 8)
        #define DF_TS01_08_SO           (0x000)
        #define DF_TS01_08_SNUM         (3)
        #define DF_TS01_08_CTSUSO0      ((DF_TS01_08_SNUM << 10) | DF_TS01_08_SO)
        #define DF_TS01_08_RICOA        (0x3F)
        #define DF_TS01_08_SDPA         (7)
        #define DF_TS01_08_ICOG         (1)
        #define DF_TS01_08_CTSUSO1      ((DF_TS01_08_ICOG << 13) | (DF_TS01_08_SDPA << 8) | DF_TS01_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS01_09_SSDIV        (0x01)
        #define DF_TS01_09_CTSUSSC      (DF_TS01_09_SSDIV << 8)
        #define DF_TS01_09_SO           (0x000)
        #define DF_TS01_09_SNUM         (3)
        #define DF_TS01_09_CTSUSO0      ((DF_TS01_09_SNUM << 10) | DF_TS01_09_SO)
        #define DF_TS01_09_RICOA        (0x3F)
        #define DF_TS01_09_SDPA         (7)
        #define DF_TS01_09_ICOG         (1)
        #define DF_TS01_09_CTSUSO1      ((DF_TS01_09_ICOG << 13) | (DF_TS01_09_SDPA << 8) | DF_TS01_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS01_10_SSDIV        (0x01)
        #define DF_TS01_10_CTSUSSC      (DF_TS01_10_SSDIV << 8)
        #define DF_TS01_10_SO           (0x000)
        #define DF_TS01_10_SNUM         (3)
        #define DF_TS01_10_CTSUSO0      ((DF_TS01_10_SNUM << 10) | DF_TS01_10_SO)
        #define DF_TS01_10_RICOA        (0x3F)
        #define DF_TS01_10_SDPA         (7)
        #define DF_TS01_10_ICOG         (1)
        #define DF_TS01_10_CTSUSO1      ((DF_TS01_10_ICOG << 13) | (DF_TS01_10_SDPA << 8) | DF_TS01_10_RICOA)
    #endif
#endif

#if DF_TS02_FUNCTION == 1
        #define DF_TS02_00_SSDIV        (0x01)
        #define DF_TS02_00_CTSUSSC      (DF_TS02_00_SSDIV << 8)
        #define DF_TS02_00_SO           (0x000)
        #define DF_TS02_00_SNUM         (3)
        #define DF_TS02_00_CTSUSO0      ((DF_TS02_00_SNUM << 10) | DF_TS02_00_SO)
        #define DF_TS02_00_RICOA        (0x3F)
        #define DF_TS02_00_SDPA         (7)
        #define DF_TS02_00_ICOG         (1)
        #define DF_TS02_00_CTSUSO1      ((DF_TS02_00_ICOG << 13) | (DF_TS02_00_SDPA << 8) | DF_TS02_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS02_01_SSDIV        (0x01)
        #define DF_TS02_01_CTSUSSC      (DF_TS02_01_SSDIV << 8)
        #define DF_TS02_01_SO           (0x000)
        #define DF_TS02_01_SNUM         (3)
        #define DF_TS02_01_CTSUSO0      ((DF_TS02_01_SNUM << 10) | DF_TS02_01_SO)
        #define DF_TS02_01_RICOA        (0x3F)
        #define DF_TS02_01_SDPA         (7)
        #define DF_TS02_01_ICOG         (1)
        #define DF_TS02_01_CTSUSO1      ((DF_TS02_01_ICOG << 13) | (DF_TS02_01_SDPA << 8) | DF_TS02_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS02_02_SSDIV        (0x01)
        #define DF_TS02_02_CTSUSSC      (DF_TS02_02_SSDIV << 8)
        #define DF_TS02_02_SO           (0x000)
        #define DF_TS02_02_SNUM         (3)
        #define DF_TS02_02_CTSUSO0      ((DF_TS02_02_SNUM << 10) | DF_TS02_02_SO)
        #define DF_TS02_02_RICOA        (0x3F)
        #define DF_TS02_02_SDPA         (7)
        #define DF_TS02_02_ICOG         (1)
        #define DF_TS02_02_CTSUSO1      ((DF_TS02_02_ICOG << 13) | (DF_TS02_02_SDPA << 8) | DF_TS02_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS02_03_SSDIV        (0x01)
        #define DF_TS02_03_CTSUSSC      (DF_TS02_03_SSDIV << 8)
        #define DF_TS02_03_SO           (0x000)
        #define DF_TS02_03_SNUM         (3)
        #define DF_TS02_03_CTSUSO0      ((DF_TS02_03_SNUM << 10) | DF_TS02_03_SO)
        #define DF_TS02_03_RICOA        (0x3F)
        #define DF_TS02_03_SDPA         (7)
        #define DF_TS02_03_ICOG         (1)
        #define DF_TS02_03_CTSUSO1      ((DF_TS02_03_ICOG << 13) | (DF_TS02_03_SDPA << 8) | DF_TS02_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS02_04_SSDIV        (0x01)
        #define DF_TS02_04_CTSUSSC      (DF_TS02_04_SSDIV << 8)
        #define DF_TS02_04_SO           (0x000)
        #define DF_TS02_04_SNUM         (3)
        #define DF_TS02_04_CTSUSO0      ((DF_TS02_04_SNUM << 10) | DF_TS02_04_SO)
        #define DF_TS02_04_RICOA        (0x3F)
        #define DF_TS02_04_SDPA         (7)
        #define DF_TS02_04_ICOG         (1)
        #define DF_TS02_04_CTSUSO1      ((DF_TS02_04_ICOG << 13) | (DF_TS02_04_SDPA << 8) | DF_TS02_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS02_05_SSDIV        (0x01)
        #define DF_TS02_05_CTSUSSC      (DF_TS02_05_SSDIV << 8)
        #define DF_TS02_05_SO           0x064
        #define DF_TS02_05_SNUM         (3)
        #define DF_TS02_05_CTSUSO0      ((DF_TS02_05_SNUM << 10) | DF_TS02_05_SO)
        #define DF_TS02_05_RICOA        (0x3F)
        #define DF_TS02_05_SDPA         (7)
        #define DF_TS02_05_ICOG         (1)
        #define DF_TS02_05_CTSUSO1      ((DF_TS02_05_ICOG << 13) | (DF_TS02_05_SDPA << 8) | DF_TS02_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS02_06_SSDIV        (0x01)
        #define DF_TS02_06_CTSUSSC      (DF_TS02_06_SSDIV << 8)
        #define DF_TS02_06_SO           (0x000)
        #define DF_TS02_06_SNUM         (3)
        #define DF_TS02_06_CTSUSO0      ((DF_TS02_06_SNUM << 10) | DF_TS02_06_SO)
        #define DF_TS02_06_RICOA        (0x3F)
        #define DF_TS02_06_SDPA         (7)
        #define DF_TS02_06_ICOG         (1)
        #define DF_TS02_06_CTSUSO1      ((DF_TS02_06_ICOG << 13) | (DF_TS02_06_SDPA << 8) | DF_TS02_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS02_07_SSDIV        (0x01)
        #define DF_TS02_07_CTSUSSC      (DF_TS02_07_SSDIV << 8)
        #define DF_TS02_07_SO           (0x000)
        #define DF_TS02_07_SNUM         (3)
        #define DF_TS02_07_CTSUSO0      ((DF_TS02_07_SNUM << 10) | DF_TS02_07_SO)
        #define DF_TS02_07_RICOA        (0x3F)
        #define DF_TS02_07_SDPA         (7)
        #define DF_TS02_07_ICOG         (1)
        #define DF_TS02_07_CTSUSO1      ((DF_TS02_07_ICOG << 13) | (DF_TS02_07_SDPA << 8) | DF_TS02_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS02_08_SSDIV        (0x01)
        #define DF_TS02_08_CTSUSSC      (DF_TS02_08_SSDIV << 8)
        #define DF_TS02_08_SO           (0x000)
        #define DF_TS02_08_SNUM         (3)
        #define DF_TS02_08_CTSUSO0      ((DF_TS02_08_SNUM << 10) | DF_TS02_08_SO)
        #define DF_TS02_08_RICOA        (0x3F)
        #define DF_TS02_08_SDPA         (7)
        #define DF_TS02_08_ICOG         (1)
        #define DF_TS02_08_CTSUSO1      ((DF_TS02_08_ICOG << 13) | (DF_TS02_08_SDPA << 8) | DF_TS02_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS02_09_SSDIV        (0x01)
        #define DF_TS02_09_CTSUSSC      (DF_TS02_09_SSDIV << 8)
        #define DF_TS02_09_SO           (0x000)
        #define DF_TS02_09_SNUM         (3)
        #define DF_TS02_09_CTSUSO0      ((DF_TS02_09_SNUM << 10) | DF_TS02_09_SO)
        #define DF_TS02_09_RICOA        (0x3F)
        #define DF_TS02_09_SDPA         (7)
        #define DF_TS02_09_ICOG         (1)
        #define DF_TS02_09_CTSUSO1      ((DF_TS02_09_ICOG << 13) | (DF_TS02_09_SDPA << 8) | DF_TS02_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS02_10_SSDIV        (0x01)
        #define DF_TS02_10_CTSUSSC      (DF_TS02_10_SSDIV << 8)
        #define DF_TS02_10_SO           (0x000)
        #define DF_TS02_10_SNUM         (3)
        #define DF_TS02_10_CTSUSO0      ((DF_TS02_10_SNUM << 10) | DF_TS02_10_SO)
        #define DF_TS02_10_RICOA        (0x3F)
        #define DF_TS02_10_SDPA         (7)
        #define DF_TS02_10_ICOG         (1)
        #define DF_TS02_10_CTSUSO1      ((DF_TS02_10_ICOG << 13) | (DF_TS02_10_SDPA << 8) | DF_TS02_10_RICOA)
    #endif
#endif

#if DF_TS03_FUNCTION == 1
        #define DF_TS03_00_SSDIV        (0x01)
        #define DF_TS03_00_CTSUSSC      (DF_TS03_00_SSDIV << 8)
        #define DF_TS03_00_SO           (0x000)
        #define DF_TS03_00_SNUM         (3)
        #define DF_TS03_00_CTSUSO0      ((DF_TS03_00_SNUM << 10) | DF_TS03_00_SO)
        #define DF_TS03_00_RICOA        (0x3F)
        #define DF_TS03_00_SDPA         (7)
        #define DF_TS03_00_ICOG         (1)
        #define DF_TS03_00_CTSUSO1      ((DF_TS03_00_ICOG << 13) | (DF_TS03_00_SDPA << 8) | DF_TS03_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS03_01_SSDIV        (0x01)
        #define DF_TS03_01_CTSUSSC      (DF_TS03_01_SSDIV << 8)
        #define DF_TS03_01_SO           (0x000)
        #define DF_TS03_01_SNUM         (3)
        #define DF_TS03_01_CTSUSO0      ((DF_TS03_01_SNUM << 10) | DF_TS03_01_SO)
        #define DF_TS03_01_RICOA        (0x3F)
        #define DF_TS03_01_SDPA         (7)
        #define DF_TS03_01_ICOG         (1)
        #define DF_TS03_01_CTSUSO1      ((DF_TS03_01_ICOG << 13) | (DF_TS03_01_SDPA << 8) | DF_TS03_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS03_02_SSDIV        (0x01)
        #define DF_TS03_02_CTSUSSC      (DF_TS03_02_SSDIV << 8)
        #define DF_TS03_02_SO           (0x000)
        #define DF_TS03_02_SNUM         (3)
        #define DF_TS03_02_CTSUSO0      ((DF_TS03_02_SNUM << 10) | DF_TS03_02_SO)
        #define DF_TS03_02_RICOA        (0x3F)
        #define DF_TS03_02_SDPA         (7)
        #define DF_TS03_02_ICOG         (1)
        #define DF_TS03_02_CTSUSO1      ((DF_TS03_02_ICOG << 13) | (DF_TS03_02_SDPA << 8) | DF_TS03_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS03_03_SSDIV        (0x01)
        #define DF_TS03_03_CTSUSSC      (DF_TS03_03_SSDIV << 8)
        #define DF_TS03_03_SO           (0x000)
        #define DF_TS03_03_SNUM         (3)
        #define DF_TS03_03_CTSUSO0      ((DF_TS03_03_SNUM << 10) | DF_TS03_03_SO)
        #define DF_TS03_03_RICOA        (0x3F)
        #define DF_TS03_03_SDPA         (7)
        #define DF_TS03_03_ICOG         (1)
        #define DF_TS03_03_CTSUSO1      ((DF_TS03_03_ICOG << 13) | (DF_TS03_03_SDPA << 8) | DF_TS03_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS03_04_SSDIV        (0x01)
        #define DF_TS03_04_CTSUSSC      (DF_TS03_04_SSDIV << 8)
        #define DF_TS03_04_SO           (0x000)
        #define DF_TS03_04_SNUM         (3)
        #define DF_TS03_04_CTSUSO0      ((DF_TS03_04_SNUM << 10) | DF_TS03_04_SO)
        #define DF_TS03_04_RICOA        (0x3F)
        #define DF_TS03_04_SDPA         (7)
        #define DF_TS03_04_ICOG         (1)
        #define DF_TS03_04_CTSUSO1      ((DF_TS03_04_ICOG << 13) | (DF_TS03_04_SDPA << 8) | DF_TS03_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS03_05_SSDIV        (0x01)
        #define DF_TS03_05_CTSUSSC      (DF_TS03_05_SSDIV << 8)
        #define DF_TS03_05_SO           (0x000)
        #define DF_TS03_05_SNUM         (3)
        #define DF_TS03_05_CTSUSO0      ((DF_TS03_05_SNUM << 10) | DF_TS03_05_SO)
        #define DF_TS03_05_RICOA        (0x3F)
        #define DF_TS03_05_SDPA         (7)
        #define DF_TS03_05_ICOG         (1)
        #define DF_TS03_05_CTSUSO1      ((DF_TS03_05_ICOG << 13) | (DF_TS03_05_SDPA << 8) | DF_TS03_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS03_06_SSDIV        (0x01)
        #define DF_TS03_06_CTSUSSC      (DF_TS03_06_SSDIV << 8)
        #define DF_TS03_06_SO           (0x000)
        #define DF_TS03_06_SNUM         (3)
        #define DF_TS03_06_CTSUSO0      ((DF_TS03_06_SNUM << 10) | DF_TS03_06_SO)
        #define DF_TS03_06_RICOA        (0x3F)
        #define DF_TS03_06_SDPA         (7)
        #define DF_TS03_06_ICOG         (1)
        #define DF_TS03_06_CTSUSO1      ((DF_TS03_06_ICOG << 13) | (DF_TS03_06_SDPA << 8) | DF_TS03_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS03_07_SSDIV        (0x01)
        #define DF_TS03_07_CTSUSSC      (DF_TS03_07_SSDIV << 8)
        #define DF_TS03_07_SO           (0x000)
        #define DF_TS03_07_SNUM         (3)
        #define DF_TS03_07_CTSUSO0      ((DF_TS03_07_SNUM << 10) | DF_TS03_07_SO)
        #define DF_TS03_07_RICOA        (0x3F)
        #define DF_TS03_07_SDPA         (7)
        #define DF_TS03_07_ICOG         (1)
        #define DF_TS03_07_CTSUSO1      ((DF_TS03_07_ICOG << 13) | (DF_TS03_07_SDPA << 8) | DF_TS03_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS03_08_SSDIV        (0x01)
        #define DF_TS03_08_CTSUSSC      (DF_TS03_08_SSDIV << 8)
        #define DF_TS03_08_SO           (0x000)
        #define DF_TS03_08_SNUM         (3)
        #define DF_TS03_08_CTSUSO0      ((DF_TS03_08_SNUM << 10) | DF_TS03_08_SO)
        #define DF_TS03_08_RICOA        (0x3F)
        #define DF_TS03_08_SDPA         (7)
        #define DF_TS03_08_ICOG         (1)
        #define DF_TS03_08_CTSUSO1      ((DF_TS03_08_ICOG << 13) | (DF_TS03_08_SDPA << 8) | DF_TS03_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS03_09_SSDIV        (0x01)
        #define DF_TS03_09_CTSUSSC      (DF_TS03_09_SSDIV << 8)
        #define DF_TS03_09_SO           (0x000)
        #define DF_TS03_09_SNUM         (3)
        #define DF_TS03_09_CTSUSO0      ((DF_TS03_09_SNUM << 10) | DF_TS03_09_SO)
        #define DF_TS03_09_RICOA        (0x3F)
        #define DF_TS03_09_SDPA         (7)
        #define DF_TS03_09_ICOG         (1)
        #define DF_TS03_09_CTSUSO1      ((DF_TS03_09_ICOG << 13) | (DF_TS03_09_SDPA << 8) | DF_TS03_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS03_10_SSDIV        (0x01)
        #define DF_TS03_10_CTSUSSC      (DF_TS03_10_SSDIV << 8)
        #define DF_TS03_10_SO           (0x000)
        #define DF_TS03_10_SNUM         (3)
        #define DF_TS03_10_CTSUSO0      ((DF_TS03_10_SNUM << 10) | DF_TS03_10_SO)
        #define DF_TS03_10_RICOA        (0x3F)
        #define DF_TS03_10_SDPA         (7)
        #define DF_TS03_10_ICOG         (1)
        #define DF_TS03_10_CTSUSO1      ((DF_TS03_10_ICOG << 13) | (DF_TS03_10_SDPA << 8) | DF_TS03_10_RICOA)
    #endif
#endif

#if DF_TS04_FUNCTION == 1
        #define DF_TS04_00_SSDIV        (0x01)
        #define DF_TS04_00_CTSUSSC      (DF_TS04_00_SSDIV << 8)
        #define DF_TS04_00_SO           (0x000)
        #define DF_TS04_00_SNUM         (3)
        #define DF_TS04_00_CTSUSO0      ((DF_TS04_00_SNUM << 10) | DF_TS04_00_SO)
        #define DF_TS04_00_RICOA        (0x3F)
        #define DF_TS04_00_SDPA         (7)
        #define DF_TS04_00_ICOG         (1)
        #define DF_TS04_00_CTSUSO1      ((DF_TS04_00_ICOG << 13) | (DF_TS04_00_SDPA << 8) | DF_TS04_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS04_01_SSDIV        (0x01)
        #define DF_TS04_01_CTSUSSC      (DF_TS04_01_SSDIV << 8)
        #define DF_TS04_01_SO           (0x000)
        #define DF_TS04_01_SNUM         (3)
        #define DF_TS04_01_CTSUSO0      ((DF_TS04_01_SNUM << 10) | DF_TS04_01_SO)
        #define DF_TS04_01_RICOA        (0x3F)
        #define DF_TS04_01_SDPA         (7)
        #define DF_TS04_01_ICOG         (1)
        #define DF_TS04_01_CTSUSO1      ((DF_TS04_01_ICOG << 13) | (DF_TS04_01_SDPA << 8) | DF_TS04_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS04_02_SSDIV        (0x01)
        #define DF_TS04_02_CTSUSSC      (DF_TS04_02_SSDIV << 8)
        #define DF_TS04_02_SO           (0x000)
        #define DF_TS04_02_SNUM         (3)
        #define DF_TS04_02_CTSUSO0      ((DF_TS04_02_SNUM << 10) | DF_TS04_02_SO)
        #define DF_TS04_02_RICOA        (0x3F)
        #define DF_TS04_02_SDPA         (7)
        #define DF_TS04_02_ICOG         (1)
        #define DF_TS04_02_CTSUSO1      ((DF_TS04_02_ICOG << 13) | (DF_TS04_02_SDPA << 8) | DF_TS04_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS04_03_SSDIV        (0x01)
        #define DF_TS04_03_CTSUSSC      (DF_TS04_03_SSDIV << 8)
        #define DF_TS04_03_SO           (0x000)
        #define DF_TS04_03_SNUM         (3)
        #define DF_TS04_03_CTSUSO0      ((DF_TS04_03_SNUM << 10) | DF_TS04_03_SO)
        #define DF_TS04_03_RICOA        (0x3F)
        #define DF_TS04_03_SDPA         (7)
        #define DF_TS04_03_ICOG         (1)
        #define DF_TS04_03_CTSUSO1      ((DF_TS04_03_ICOG << 13) | (DF_TS04_03_SDPA << 8) | DF_TS04_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS04_04_SSDIV        (0x01)
        #define DF_TS04_04_CTSUSSC      (DF_TS04_04_SSDIV << 8)
        #define DF_TS04_04_SO           (0x000)
        #define DF_TS04_04_SNUM         (3)
        #define DF_TS04_04_CTSUSO0      ((DF_TS04_04_SNUM << 10) | DF_TS04_04_SO)
        #define DF_TS04_04_RICOA        (0x3F)
        #define DF_TS04_04_SDPA         (7)
        #define DF_TS04_04_ICOG         (1)
        #define DF_TS04_04_CTSUSO1      ((DF_TS04_04_ICOG << 13) | (DF_TS04_04_SDPA << 8) | DF_TS04_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS04_05_SSDIV        (0x01)
        #define DF_TS04_05_CTSUSSC      (DF_TS04_05_SSDIV << 8)
        #define DF_TS04_05_SO           0x064
        #define DF_TS04_05_SNUM         (3)
        #define DF_TS04_05_CTSUSO0      ((DF_TS04_05_SNUM << 10) | DF_TS04_05_SO)
        #define DF_TS04_05_RICOA        (0x3F)
        #define DF_TS04_05_SDPA         (7)
        #define DF_TS04_05_ICOG         (1)
        #define DF_TS04_05_CTSUSO1      ((DF_TS04_05_ICOG << 13) | (DF_TS04_05_SDPA << 8) | DF_TS04_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS04_06_SSDIV        (0x01)
        #define DF_TS04_06_CTSUSSC      (DF_TS04_06_SSDIV << 8)
        #define DF_TS04_06_SO           (0x000)
        #define DF_TS04_06_SNUM         (3)
        #define DF_TS04_06_CTSUSO0      ((DF_TS04_06_SNUM << 10) | DF_TS04_06_SO)
        #define DF_TS04_06_RICOA        (0x3F)
        #define DF_TS04_06_SDPA         (7)
        #define DF_TS04_06_ICOG         (1)
        #define DF_TS04_06_CTSUSO1      ((DF_TS04_06_ICOG << 13) | (DF_TS04_06_SDPA << 8) | DF_TS04_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS04_07_SSDIV        (0x01)
        #define DF_TS04_07_CTSUSSC      (DF_TS04_07_SSDIV << 8)
        #define DF_TS04_07_SO           (0x000)
        #define DF_TS04_07_SNUM         (3)
        #define DF_TS04_07_CTSUSO0      ((DF_TS04_07_SNUM << 10) | DF_TS04_07_SO)
        #define DF_TS04_07_RICOA        (0x3F)
        #define DF_TS04_07_SDPA         (7)
        #define DF_TS04_07_ICOG         (1)
        #define DF_TS04_07_CTSUSO1      ((DF_TS04_07_ICOG << 13) | (DF_TS04_07_SDPA << 8) | DF_TS04_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS04_08_SSDIV        (0x01)
        #define DF_TS04_08_CTSUSSC      (DF_TS04_08_SSDIV << 8)
        #define DF_TS04_08_SO           (0x000)
        #define DF_TS04_08_SNUM         (3)
        #define DF_TS04_08_CTSUSO0      ((DF_TS04_08_SNUM << 10) | DF_TS04_08_SO)
        #define DF_TS04_08_RICOA        (0x3F)
        #define DF_TS04_08_SDPA         (7)
        #define DF_TS04_08_ICOG         (1)
        #define DF_TS04_08_CTSUSO1      ((DF_TS04_08_ICOG << 13) | (DF_TS04_08_SDPA << 8) | DF_TS04_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS04_09_SSDIV        (0x01)
        #define DF_TS04_09_CTSUSSC      (DF_TS04_09_SSDIV << 8)
        #define DF_TS04_09_SO           (0x000)
        #define DF_TS04_09_SNUM         (3)
        #define DF_TS04_09_CTSUSO0      ((DF_TS04_09_SNUM << 10) | DF_TS04_09_SO)
        #define DF_TS04_09_RICOA        (0x3F)
        #define DF_TS04_09_SDPA         (7)
        #define DF_TS04_09_ICOG         (1)
        #define DF_TS04_09_CTSUSO1      ((DF_TS04_09_ICOG << 13) | (DF_TS04_09_SDPA << 8) | DF_TS04_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS04_10_SSDIV        (0x01)
        #define DF_TS04_10_CTSUSSC      (DF_TS04_10_SSDIV << 8)
        #define DF_TS04_10_SO           (0x000)
        #define DF_TS04_10_SNUM         (3)
        #define DF_TS04_10_CTSUSO0      ((DF_TS04_10_SNUM << 10) | DF_TS04_10_SO)
        #define DF_TS04_10_RICOA        (0x3F)
        #define DF_TS04_10_SDPA         (7)
        #define DF_TS04_10_ICOG         (1)
        #define DF_TS04_10_CTSUSO1      ((DF_TS04_10_ICOG << 13) | (DF_TS04_10_SDPA << 8) | DF_TS04_10_RICOA)
    #endif
#endif

#if DF_TS05_FUNCTION == 1
        #define DF_TS05_00_SSDIV        (0x01)
        #define DF_TS05_00_CTSUSSC      (DF_TS05_00_SSDIV << 8)
        #define DF_TS05_00_SO           (0x000)
        #define DF_TS05_00_SNUM         (3)
        #define DF_TS05_00_CTSUSO0      ((DF_TS05_00_SNUM << 10) | DF_TS05_00_SO)
        #define DF_TS05_00_RICOA        (0x3F)
        #define DF_TS05_00_SDPA         (7)
        #define DF_TS05_00_ICOG         (1)
        #define DF_TS05_00_CTSUSO1      ((DF_TS05_00_ICOG << 13) | (DF_TS05_00_SDPA << 8) | DF_TS05_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS05_01_SSDIV        (0x01)
        #define DF_TS05_01_CTSUSSC      (DF_TS05_01_SSDIV << 8)
        #define DF_TS05_01_SO           (0x000)
        #define DF_TS05_01_SNUM         (3)
        #define DF_TS05_01_CTSUSO0      ((DF_TS05_01_SNUM << 10) | DF_TS05_01_SO)
        #define DF_TS05_01_RICOA        (0x3F)
        #define DF_TS05_01_SDPA         (7)
        #define DF_TS05_01_ICOG         (1)
        #define DF_TS05_01_CTSUSO1      ((DF_TS05_01_ICOG << 13) | (DF_TS05_01_SDPA << 8) | DF_TS05_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS05_02_SSDIV        (0x01)
        #define DF_TS05_02_CTSUSSC      (DF_TS05_02_SSDIV << 8)
        #define DF_TS05_02_SO           (0x000)
        #define DF_TS05_02_SNUM         (3)
        #define DF_TS05_02_CTSUSO0      ((DF_TS05_02_SNUM << 10) | DF_TS05_02_SO)
        #define DF_TS05_02_RICOA        (0x3F)
        #define DF_TS05_02_SDPA         (7)
        #define DF_TS05_02_ICOG         (1)
        #define DF_TS05_02_CTSUSO1      ((DF_TS05_02_ICOG << 13) | (DF_TS05_02_SDPA << 8) | DF_TS05_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS05_03_SSDIV        (0x01)
        #define DF_TS05_03_CTSUSSC      (DF_TS05_03_SSDIV << 8)
        #define DF_TS05_03_SO           (0x000)
        #define DF_TS05_03_SNUM         (3)
        #define DF_TS05_03_CTSUSO0      ((DF_TS05_03_SNUM << 10) | DF_TS05_03_SO)
        #define DF_TS05_03_RICOA        (0x3F)
        #define DF_TS05_03_SDPA         (7)
        #define DF_TS05_03_ICOG         (1)
        #define DF_TS05_03_CTSUSO1      ((DF_TS05_03_ICOG << 13) | (DF_TS05_03_SDPA << 8) | DF_TS05_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS05_04_SSDIV        (0x01)
        #define DF_TS05_04_CTSUSSC      (DF_TS05_04_SSDIV << 8)
        #define DF_TS05_04_SO           (0x000)
        #define DF_TS05_04_SNUM         (3)
        #define DF_TS05_04_CTSUSO0      ((DF_TS05_04_SNUM << 10) | DF_TS05_04_SO)
        #define DF_TS05_04_RICOA        (0x3F)
        #define DF_TS05_04_SDPA         (7)
        #define DF_TS05_04_ICOG         (1)
        #define DF_TS05_04_CTSUSO1      ((DF_TS05_04_ICOG << 13) | (DF_TS05_04_SDPA << 8) | DF_TS05_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS05_05_SSDIV        (0x01)
        #define DF_TS05_05_CTSUSSC      (DF_TS05_05_SSDIV << 8)
        #define DF_TS05_05_SO           (0x000)
        #define DF_TS05_05_SNUM         (3)
        #define DF_TS05_05_CTSUSO0      ((DF_TS05_05_SNUM << 10) | DF_TS05_05_SO)
        #define DF_TS05_05_RICOA        (0x3F)
        #define DF_TS05_05_SDPA         (7)
        #define DF_TS05_05_ICOG         (1)
        #define DF_TS05_05_CTSUSO1      ((DF_TS05_05_ICOG << 13) | (DF_TS05_05_SDPA << 8) | DF_TS05_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS05_06_SSDIV        (0x01)
        #define DF_TS05_06_CTSUSSC      (DF_TS05_06_SSDIV << 8)
        #define DF_TS05_06_SO           (0x000)
        #define DF_TS05_06_SNUM         (3)
        #define DF_TS05_06_CTSUSO0      ((DF_TS05_06_SNUM << 10) | DF_TS05_06_SO)
        #define DF_TS05_06_RICOA        (0x3F)
        #define DF_TS05_06_SDPA         (7)
        #define DF_TS05_06_ICOG         (1)
        #define DF_TS05_06_CTSUSO1      ((DF_TS05_06_ICOG << 13) | (DF_TS05_06_SDPA << 8) | DF_TS05_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS05_07_SSDIV        (0x01)
        #define DF_TS05_07_CTSUSSC      (DF_TS05_07_SSDIV << 8)
        #define DF_TS05_07_SO           (0x000)
        #define DF_TS05_07_SNUM         (3)
        #define DF_TS05_07_CTSUSO0      ((DF_TS05_07_SNUM << 10) | DF_TS05_07_SO)
        #define DF_TS05_07_RICOA        (0x3F)
        #define DF_TS05_07_SDPA         (7)
        #define DF_TS05_07_ICOG         (1)
        #define DF_TS05_07_CTSUSO1      ((DF_TS05_07_ICOG << 13) | (DF_TS05_07_SDPA << 8) | DF_TS05_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS05_08_SSDIV        (0x01)
        #define DF_TS05_08_CTSUSSC      (DF_TS05_08_SSDIV << 8)
        #define DF_TS05_08_SO           (0x000)
        #define DF_TS05_08_SNUM         (3)
        #define DF_TS05_08_CTSUSO0      ((DF_TS05_08_SNUM << 10) | DF_TS05_08_SO)
        #define DF_TS05_08_RICOA        (0x3F)
        #define DF_TS05_08_SDPA         (7)
        #define DF_TS05_08_ICOG         (1)
        #define DF_TS05_08_CTSUSO1      ((DF_TS05_08_ICOG << 13) | (DF_TS05_08_SDPA << 8) | DF_TS05_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS05_09_SSDIV        (0x01)
        #define DF_TS05_09_CTSUSSC      (DF_TS05_09_SSDIV << 8)
        #define DF_TS05_09_SO           (0x000)
        #define DF_TS05_09_SNUM         (3)
        #define DF_TS05_09_CTSUSO0      ((DF_TS05_09_SNUM << 10) | DF_TS05_09_SO)
        #define DF_TS05_09_RICOA        (0x3F)
        #define DF_TS05_09_SDPA         (7)
        #define DF_TS05_09_ICOG         (1)
        #define DF_TS05_09_CTSUSO1      ((DF_TS05_09_ICOG << 13) | (DF_TS05_09_SDPA << 8) | DF_TS05_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS05_10_SSDIV        (0x01)
        #define DF_TS05_10_CTSUSSC      (DF_TS05_10_SSDIV << 8)
        #define DF_TS05_10_SO           (0x000)
        #define DF_TS05_10_SNUM         (3)
        #define DF_TS05_10_CTSUSO0      ((DF_TS05_10_SNUM << 10) | DF_TS05_10_SO)
        #define DF_TS05_10_RICOA        (0x3F)
        #define DF_TS05_10_SDPA         (7)
        #define DF_TS05_10_ICOG         (1)
        #define DF_TS05_10_CTSUSO1      ((DF_TS05_10_ICOG << 13) | (DF_TS05_10_SDPA << 8) | DF_TS05_10_RICOA)
    #endif
#endif

#if DF_TS06_FUNCTION == 1
        #define DF_TS06_00_SSDIV        (0x01)
        #define DF_TS06_00_CTSUSSC      (DF_TS06_00_SSDIV << 8)
        #define DF_TS06_00_SO           (0x000)
        #define DF_TS06_00_SNUM         (3)
        #define DF_TS06_00_CTSUSO0      ((DF_TS06_00_SNUM << 10) | DF_TS06_00_SO)
        #define DF_TS06_00_RICOA        (0x3F)
        #define DF_TS06_00_SDPA         (7)
        #define DF_TS06_00_ICOG         (1)
        #define DF_TS06_00_CTSUSO1      ((DF_TS06_00_ICOG << 13) | (DF_TS06_00_SDPA << 8) | DF_TS06_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS06_01_SSDIV        (0x01)
        #define DF_TS06_01_CTSUSSC      (DF_TS06_01_SSDIV << 8)
        #define DF_TS06_01_SO           (0x000)
        #define DF_TS06_01_SNUM         (3)
        #define DF_TS06_01_CTSUSO0      ((DF_TS06_01_SNUM << 10) | DF_TS06_01_SO)
        #define DF_TS06_01_RICOA        (0x3F)
        #define DF_TS06_01_SDPA         (7)
        #define DF_TS06_01_ICOG         (1)
        #define DF_TS06_01_CTSUSO1      ((DF_TS06_01_ICOG << 13) | (DF_TS06_01_SDPA << 8) | DF_TS06_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS06_02_SSDIV        (0x01)
        #define DF_TS06_02_CTSUSSC      (DF_TS06_02_SSDIV << 8)
        #define DF_TS06_02_SO           (0x000)
        #define DF_TS06_02_SNUM         (3)
        #define DF_TS06_02_CTSUSO0      ((DF_TS06_02_SNUM << 10) | DF_TS06_02_SO)
        #define DF_TS06_02_RICOA        (0x3F)
        #define DF_TS06_02_SDPA         (7)
        #define DF_TS06_02_ICOG         (1)
        #define DF_TS06_02_CTSUSO1      ((DF_TS06_02_ICOG << 13) | (DF_TS06_02_SDPA << 8) | DF_TS06_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS06_03_SSDIV        (0x01)
        #define DF_TS06_03_CTSUSSC      (DF_TS06_03_SSDIV << 8)
        #define DF_TS06_03_SO           (0x000)
        #define DF_TS06_03_SNUM         (3)
        #define DF_TS06_03_CTSUSO0      ((DF_TS06_03_SNUM << 10) | DF_TS06_03_SO)
        #define DF_TS06_03_RICOA        (0x3F)
        #define DF_TS06_03_SDPA         (7)
        #define DF_TS06_03_ICOG         (1)
        #define DF_TS06_03_CTSUSO1      ((DF_TS06_03_ICOG << 13) | (DF_TS06_03_SDPA << 8) | DF_TS06_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS06_04_SSDIV        (0x01)
        #define DF_TS06_04_CTSUSSC      (DF_TS06_04_SSDIV << 8)
        #define DF_TS06_04_SO           (0x000)
        #define DF_TS06_04_SNUM         (3)
        #define DF_TS06_04_CTSUSO0      ((DF_TS06_04_SNUM << 10) | DF_TS06_04_SO)
        #define DF_TS06_04_RICOA        (0x3F)
        #define DF_TS06_04_SDPA         (7)
        #define DF_TS06_04_ICOG         (1)
        #define DF_TS06_04_CTSUSO1      ((DF_TS06_04_ICOG << 13) | (DF_TS06_04_SDPA << 8) | DF_TS06_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS06_05_SSDIV        (0x01)
        #define DF_TS06_05_CTSUSSC      (DF_TS06_05_SSDIV << 8)
        #define DF_TS06_05_SO           (0x000)
        #define DF_TS06_05_SNUM         (3)
        #define DF_TS06_05_CTSUSO0      ((DF_TS06_05_SNUM << 10) | DF_TS06_05_SO)
        #define DF_TS06_05_RICOA        (0x3F)
        #define DF_TS06_05_SDPA         (7)
        #define DF_TS06_05_ICOG         (1)
        #define DF_TS06_05_CTSUSO1      ((DF_TS06_05_ICOG << 13) | (DF_TS06_05_SDPA << 8) | DF_TS06_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS06_06_SSDIV        (0x01)
        #define DF_TS06_06_CTSUSSC      (DF_TS06_06_SSDIV << 8)
        #define DF_TS06_06_SO           (0x000)
        #define DF_TS06_06_SNUM         (3)
        #define DF_TS06_06_CTSUSO0      ((DF_TS06_06_SNUM << 10) | DF_TS06_06_SO)
        #define DF_TS06_06_RICOA        (0x3F)
        #define DF_TS06_06_SDPA         (7)
        #define DF_TS06_06_ICOG         (1)
        #define DF_TS06_06_CTSUSO1      ((DF_TS06_06_ICOG << 13) | (DF_TS06_06_SDPA << 8) | DF_TS06_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS06_07_SSDIV        (0x01)
        #define DF_TS06_07_CTSUSSC      (DF_TS06_07_SSDIV << 8)
        #define DF_TS06_07_SO           (0x000)
        #define DF_TS06_07_SNUM         (3)
        #define DF_TS06_07_CTSUSO0      ((DF_TS06_07_SNUM << 10) | DF_TS06_07_SO)
        #define DF_TS06_07_RICOA        (0x3F)
        #define DF_TS06_07_SDPA         (7)
        #define DF_TS06_07_ICOG         (1)
        #define DF_TS06_07_CTSUSO1      ((DF_TS06_07_ICOG << 13) | (DF_TS06_07_SDPA << 8) | DF_TS06_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS06_08_SSDIV        (0x01)
        #define DF_TS06_08_CTSUSSC      (DF_TS06_08_SSDIV << 8)
        #define DF_TS06_08_SO           (0x000)
        #define DF_TS06_08_SNUM         (3)
        #define DF_TS06_08_CTSUSO0      ((DF_TS06_08_SNUM << 10) | DF_TS06_08_SO)
        #define DF_TS06_08_RICOA        (0x3F)
        #define DF_TS06_08_SDPA         (7)
        #define DF_TS06_08_ICOG         (1)
        #define DF_TS06_08_CTSUSO1      ((DF_TS06_08_ICOG << 13) | (DF_TS06_08_SDPA << 8) | DF_TS06_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS06_09_SSDIV        (0x01)
        #define DF_TS06_09_CTSUSSC      (DF_TS06_09_SSDIV << 8)
        #define DF_TS06_09_SO           (0x000)
        #define DF_TS06_09_SNUM         (3)
        #define DF_TS06_09_CTSUSO0      ((DF_TS06_09_SNUM << 10) | DF_TS06_09_SO)
        #define DF_TS06_09_RICOA        (0x3F)
        #define DF_TS06_09_SDPA         (7)
        #define DF_TS06_09_ICOG         (1)
        #define DF_TS06_09_CTSUSO1      ((DF_TS06_09_ICOG << 13) | (DF_TS06_09_SDPA << 8) | DF_TS06_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS06_10_SSDIV        (0x01)
        #define DF_TS06_10_CTSUSSC      (DF_TS06_10_SSDIV << 8)
        #define DF_TS06_10_SO           (0x000)
        #define DF_TS06_10_SNUM         (3)
        #define DF_TS06_10_CTSUSO0      ((DF_TS06_10_SNUM << 10) | DF_TS06_10_SO)
        #define DF_TS06_10_RICOA        (0x3F)
        #define DF_TS06_10_SDPA         (7)
        #define DF_TS06_10_ICOG         (1)
        #define DF_TS06_10_CTSUSO1      ((DF_TS06_10_ICOG << 13) | (DF_TS06_10_SDPA << 8) | DF_TS06_10_RICOA)
    #endif
#endif

#if DF_TS07_FUNCTION == 1
        #define DF_TS07_00_SSDIV        (0x01)
        #define DF_TS07_00_CTSUSSC      (DF_TS07_00_SSDIV << 8)
        #define DF_TS07_00_SO           (0x000)
        #define DF_TS07_00_SNUM         (3)
        #define DF_TS07_00_CTSUSO0      ((DF_TS07_00_SNUM << 10) | DF_TS07_00_SO)
        #define DF_TS07_00_RICOA        (0x3F)
        #define DF_TS07_00_SDPA         (7)
        #define DF_TS07_00_ICOG         (1)
        #define DF_TS07_00_CTSUSO1      ((DF_TS07_00_ICOG << 13) | (DF_TS07_00_SDPA << 8) | DF_TS07_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS07_01_SSDIV        (0x01)
        #define DF_TS07_01_CTSUSSC      (DF_TS07_01_SSDIV << 8)
        #define DF_TS07_01_SO           (0x000)
        #define DF_TS07_01_SNUM         (3)
        #define DF_TS07_01_CTSUSO0      ((DF_TS07_01_SNUM << 10) | DF_TS07_01_SO)
        #define DF_TS07_01_RICOA        (0x3F)
        #define DF_TS07_01_SDPA         (7)
        #define DF_TS07_01_ICOG         (1)
        #define DF_TS07_01_CTSUSO1      ((DF_TS07_01_ICOG << 13) | (DF_TS07_01_SDPA << 8) | DF_TS07_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS07_02_SSDIV        (0x01)
        #define DF_TS07_02_CTSUSSC      (DF_TS07_02_SSDIV << 8)
        #define DF_TS07_02_SO           (0x000)
        #define DF_TS07_02_SNUM         (3)
        #define DF_TS07_02_CTSUSO0      ((DF_TS07_02_SNUM << 10) | DF_TS07_02_SO)
        #define DF_TS07_02_RICOA        (0x3F)
        #define DF_TS07_02_SDPA         (7)
        #define DF_TS07_02_ICOG         (1)
        #define DF_TS07_02_CTSUSO1      ((DF_TS07_02_ICOG << 13) | (DF_TS07_02_SDPA << 8) | DF_TS07_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS07_03_SSDIV        (0x01)
        #define DF_TS07_03_CTSUSSC      (DF_TS07_03_SSDIV << 8)
        #define DF_TS07_03_SO           (0x000)
        #define DF_TS07_03_SNUM         (3)
        #define DF_TS07_03_CTSUSO0      ((DF_TS07_03_SNUM << 10) | DF_TS07_03_SO)
        #define DF_TS07_03_RICOA        (0x3F)
        #define DF_TS07_03_SDPA         (7)
        #define DF_TS07_03_ICOG         (1)
        #define DF_TS07_03_CTSUSO1      ((DF_TS07_03_ICOG << 13) | (DF_TS07_03_SDPA << 8) | DF_TS07_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS07_04_SSDIV        (0x01)
        #define DF_TS07_04_CTSUSSC      (DF_TS07_04_SSDIV << 8)
        #define DF_TS07_04_SO           (0x000)
        #define DF_TS07_04_SNUM         (3)
        #define DF_TS07_04_CTSUSO0      ((DF_TS07_04_SNUM << 10) | DF_TS07_04_SO)
        #define DF_TS07_04_RICOA        (0x3F)
        #define DF_TS07_04_SDPA         (7)
        #define DF_TS07_04_ICOG         (1)
        #define DF_TS07_04_CTSUSO1      ((DF_TS07_04_ICOG << 13) | (DF_TS07_04_SDPA << 8) | DF_TS07_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS07_05_SSDIV        (0x01)
        #define DF_TS07_05_CTSUSSC      (DF_TS07_05_SSDIV << 8)
        #define DF_TS07_05_SO           (0x000)
        #define DF_TS07_05_SNUM         (3)
        #define DF_TS07_05_CTSUSO0      ((DF_TS07_05_SNUM << 10) | DF_TS07_05_SO)
        #define DF_TS07_05_RICOA        (0x3F)
        #define DF_TS07_05_SDPA         (7)
        #define DF_TS07_05_ICOG         (1)
        #define DF_TS07_05_CTSUSO1      ((DF_TS07_05_ICOG << 13) | (DF_TS07_05_SDPA << 8) | DF_TS07_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS07_06_SSDIV        (0x01)
        #define DF_TS07_06_CTSUSSC      (DF_TS07_06_SSDIV << 8)
        #define DF_TS07_06_SO           (0x000)
        #define DF_TS07_06_SNUM         (3)
        #define DF_TS07_06_CTSUSO0      ((DF_TS07_06_SNUM << 10) | DF_TS07_06_SO)
        #define DF_TS07_06_RICOA        (0x3F)
        #define DF_TS07_06_SDPA         (7)
        #define DF_TS07_06_ICOG         (1)
        #define DF_TS07_06_CTSUSO1      ((DF_TS07_06_ICOG << 13) | (DF_TS07_06_SDPA << 8) | DF_TS07_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS07_07_SSDIV        (0x01)
        #define DF_TS07_07_CTSUSSC      (DF_TS07_07_SSDIV << 8)
        #define DF_TS07_07_SO           (0x000)
        #define DF_TS07_07_SNUM         (3)
        #define DF_TS07_07_CTSUSO0      ((DF_TS07_07_SNUM << 10) | DF_TS07_07_SO)
        #define DF_TS07_07_RICOA        (0x3F)
        #define DF_TS07_07_SDPA         (7)
        #define DF_TS07_07_ICOG         (1)
        #define DF_TS07_07_CTSUSO1      ((DF_TS07_07_ICOG << 13) | (DF_TS07_07_SDPA << 8) | DF_TS07_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS07_08_SSDIV        (0x01)
        #define DF_TS07_08_CTSUSSC      (DF_TS07_08_SSDIV << 8)
        #define DF_TS07_08_SO           (0x000)
        #define DF_TS07_08_SNUM         (3)
        #define DF_TS07_08_CTSUSO0      ((DF_TS07_08_SNUM << 10) | DF_TS07_08_SO)
        #define DF_TS07_08_RICOA        (0x3F)
        #define DF_TS07_08_SDPA         (7)
        #define DF_TS07_08_ICOG         (1)
        #define DF_TS07_08_CTSUSO1      ((DF_TS07_08_ICOG << 13) | (DF_TS07_08_SDPA << 8) | DF_TS07_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS07_09_SSDIV        (0x01)
        #define DF_TS07_09_CTSUSSC      (DF_TS07_09_SSDIV << 8)
        #define DF_TS07_09_SO           (0x000)
        #define DF_TS07_09_SNUM         (3)
        #define DF_TS07_09_CTSUSO0      ((DF_TS07_09_SNUM << 10) | DF_TS07_09_SO)
        #define DF_TS07_09_RICOA        (0x3F)
        #define DF_TS07_09_SDPA         (7)
        #define DF_TS07_09_ICOG         (1)
        #define DF_TS07_09_CTSUSO1      ((DF_TS07_09_ICOG << 13) | (DF_TS07_09_SDPA << 8) | DF_TS07_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS07_10_SSDIV        (0x01)
        #define DF_TS07_10_CTSUSSC      (DF_TS07_10_SSDIV << 8)
        #define DF_TS07_10_SO           (0x000)
        #define DF_TS07_10_SNUM         (3)
        #define DF_TS07_10_CTSUSO0      ((DF_TS07_10_SNUM << 10) | DF_TS07_10_SO)
        #define DF_TS07_10_RICOA        (0x3F)
        #define DF_TS07_10_SDPA         (7)
        #define DF_TS07_10_ICOG         (1)
        #define DF_TS07_10_CTSUSO1      ((DF_TS07_10_ICOG << 13) | (DF_TS07_10_SDPA << 8) | DF_TS07_10_RICOA)
    #endif
#endif

#if DF_TS08_FUNCTION == 1
        #define DF_TS08_00_SSDIV        (0x01)
        #define DF_TS08_00_CTSUSSC      (DF_TS08_00_SSDIV << 8)
        #define DF_TS08_00_SO           (0x000)
        #define DF_TS08_00_SNUM         (3)
        #define DF_TS08_00_CTSUSO0      ((DF_TS08_00_SNUM << 10) | DF_TS08_00_SO)
        #define DF_TS08_00_RICOA        (0x3F)
        #define DF_TS08_00_SDPA         (7)
        #define DF_TS08_00_ICOG         (1)
        #define DF_TS08_00_CTSUSO1      ((DF_TS08_00_ICOG << 13) | (DF_TS08_00_SDPA << 8) | DF_TS08_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS08_01_SSDIV        (0x01)
        #define DF_TS08_01_CTSUSSC      (DF_TS08_01_SSDIV << 8)
        #define DF_TS08_01_SO           (0x000)
        #define DF_TS08_01_SNUM         (3)
        #define DF_TS08_01_CTSUSO0      ((DF_TS08_01_SNUM << 10) | DF_TS08_01_SO)
        #define DF_TS08_01_RICOA        (0x3F)
        #define DF_TS08_01_SDPA         (7)
        #define DF_TS08_01_ICOG         (1)
        #define DF_TS08_01_CTSUSO1      ((DF_TS08_01_ICOG << 13) | (DF_TS08_01_SDPA << 8) | DF_TS08_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS08_02_SSDIV        (0x01)
        #define DF_TS08_02_CTSUSSC      (DF_TS08_02_SSDIV << 8)
        #define DF_TS08_02_SO           (0x000)
        #define DF_TS08_02_SNUM         (3)
        #define DF_TS08_02_CTSUSO0      ((DF_TS08_02_SNUM << 10) | DF_TS08_02_SO)
        #define DF_TS08_02_RICOA        (0x3F)
        #define DF_TS08_02_SDPA         (7)
        #define DF_TS08_02_ICOG         (1)
        #define DF_TS08_02_CTSUSO1      ((DF_TS08_02_ICOG << 13) | (DF_TS08_02_SDPA << 8) | DF_TS08_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS08_03_SSDIV        (0x01)
        #define DF_TS08_03_CTSUSSC      (DF_TS08_03_SSDIV << 8)
        #define DF_TS08_03_SO           (0x000)
        #define DF_TS08_03_SNUM         (3)
        #define DF_TS08_03_CTSUSO0      ((DF_TS08_03_SNUM << 10) | DF_TS08_03_SO)
        #define DF_TS08_03_RICOA        (0x3F)
        #define DF_TS08_03_SDPA         (7)
        #define DF_TS08_03_ICOG         (1)
        #define DF_TS08_03_CTSUSO1      ((DF_TS08_03_ICOG << 13) | (DF_TS08_03_SDPA << 8) | DF_TS08_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS08_04_SSDIV        (0x01)
        #define DF_TS08_04_CTSUSSC      (DF_TS08_04_SSDIV << 8)
        #define DF_TS08_04_SO           (0x000)
        #define DF_TS08_04_SNUM         (3)
        #define DF_TS08_04_CTSUSO0      ((DF_TS08_04_SNUM << 10) | DF_TS08_04_SO)
        #define DF_TS08_04_RICOA        (0x3F)
        #define DF_TS08_04_SDPA         (7)
        #define DF_TS08_04_ICOG         (1)
        #define DF_TS08_04_CTSUSO1      ((DF_TS08_04_ICOG << 13) | (DF_TS08_04_SDPA << 8) | DF_TS08_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS08_05_SSDIV        (0x01)
        #define DF_TS08_05_CTSUSSC      (DF_TS08_05_SSDIV << 8)
        #define DF_TS08_05_SO           (0x000)
        #define DF_TS08_05_SNUM         (3)
        #define DF_TS08_05_CTSUSO0      ((DF_TS08_05_SNUM << 10) | DF_TS08_05_SO)
        #define DF_TS08_05_RICOA        (0x3F)
        #define DF_TS08_05_SDPA         (7)
        #define DF_TS08_05_ICOG         (1)
        #define DF_TS08_05_CTSUSO1      ((DF_TS08_05_ICOG << 13) | (DF_TS08_05_SDPA << 8) | DF_TS08_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS08_06_SSDIV        (0x01)
        #define DF_TS08_06_CTSUSSC      (DF_TS08_06_SSDIV << 8)
        #define DF_TS08_06_SO           (0x000)
        #define DF_TS08_06_SNUM         (3)
        #define DF_TS08_06_CTSUSO0      ((DF_TS08_06_SNUM << 10) | DF_TS08_06_SO)
        #define DF_TS08_06_RICOA        (0x3F)
        #define DF_TS08_06_SDPA         (7)
        #define DF_TS08_06_ICOG         (1)
        #define DF_TS08_06_CTSUSO1      ((DF_TS08_06_ICOG << 13) | (DF_TS08_06_SDPA << 8) | DF_TS08_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS08_07_SSDIV        (0x01)
        #define DF_TS08_07_CTSUSSC      (DF_TS08_07_SSDIV << 8)
        #define DF_TS08_07_SO           (0x000)
        #define DF_TS08_07_SNUM         (3)
        #define DF_TS08_07_CTSUSO0      ((DF_TS08_07_SNUM << 10) | DF_TS08_07_SO)
        #define DF_TS08_07_RICOA        (0x3F)
        #define DF_TS08_07_SDPA         (7)
        #define DF_TS08_07_ICOG         (1)
        #define DF_TS08_07_CTSUSO1      ((DF_TS08_07_ICOG << 13) | (DF_TS08_07_SDPA << 8) | DF_TS08_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS08_08_SSDIV        (0x01)
        #define DF_TS08_08_CTSUSSC      (DF_TS08_08_SSDIV << 8)
        #define DF_TS08_08_SO           (0x000)
        #define DF_TS08_08_SNUM         (3)
        #define DF_TS08_08_CTSUSO0      ((DF_TS08_08_SNUM << 10) | DF_TS08_08_SO)
        #define DF_TS08_08_RICOA        (0x3F)
        #define DF_TS08_08_SDPA         (7)
        #define DF_TS08_08_ICOG         (1)
        #define DF_TS08_08_CTSUSO1      ((DF_TS08_08_ICOG << 13) | (DF_TS08_08_SDPA << 8) | DF_TS08_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS08_09_SSDIV        (0x01)
        #define DF_TS08_09_CTSUSSC      (DF_TS08_09_SSDIV << 8)
        #define DF_TS08_09_SO           (0x000)
        #define DF_TS08_09_SNUM         (3)
        #define DF_TS08_09_CTSUSO0      ((DF_TS08_09_SNUM << 10) | DF_TS08_09_SO)
        #define DF_TS08_09_RICOA        (0x3F)
        #define DF_TS08_09_SDPA         (7)
        #define DF_TS08_09_ICOG         (1)
        #define DF_TS08_09_CTSUSO1      ((DF_TS08_09_ICOG << 13) | (DF_TS08_09_SDPA << 8) | DF_TS08_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS08_10_SSDIV        (0x01)
        #define DF_TS08_10_CTSUSSC      (DF_TS08_10_SSDIV << 8)
        #define DF_TS08_10_SO           (0x000)
        #define DF_TS08_10_SNUM         (3)
        #define DF_TS08_10_CTSUSO0      ((DF_TS08_10_SNUM << 10) | DF_TS08_10_SO)
        #define DF_TS08_10_RICOA        (0x3F)
        #define DF_TS08_10_SDPA         (7)
        #define DF_TS08_10_ICOG         (1)
        #define DF_TS08_10_CTSUSO1      ((DF_TS08_10_ICOG << 13) | (DF_TS08_10_SDPA << 8) | DF_TS08_10_RICOA)
    #endif
#endif

#if DF_TS09_FUNCTION == 1
        #define DF_TS09_00_SSDIV        (0x01)
        #define DF_TS09_00_CTSUSSC      (DF_TS09_00_SSDIV << 8)
        #define DF_TS09_00_SO           (0x000)
        #define DF_TS09_00_SNUM         (3)
        #define DF_TS09_00_CTSUSO0      ((DF_TS09_00_SNUM << 10) | DF_TS09_00_SO)
        #define DF_TS09_00_RICOA        (0x3F)
        #define DF_TS09_00_SDPA         (7)
        #define DF_TS09_00_ICOG         (1)
        #define DF_TS09_00_CTSUSO1      ((DF_TS09_00_ICOG << 13) | (DF_TS09_00_SDPA << 8) | DF_TS09_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS09_01_SSDIV        (0x01)
        #define DF_TS09_01_CTSUSSC      (DF_TS09_01_SSDIV << 8)
        #define DF_TS09_01_SO           (0x000)
        #define DF_TS09_01_SNUM         (3)
        #define DF_TS09_01_CTSUSO0      ((DF_TS09_01_SNUM << 10) | DF_TS09_01_SO)
        #define DF_TS09_01_RICOA        (0x3F)
        #define DF_TS09_01_SDPA         (7)
        #define DF_TS09_01_ICOG         (1)
        #define DF_TS09_01_CTSUSO1      ((DF_TS09_01_ICOG << 13) | (DF_TS09_01_SDPA << 8) | DF_TS09_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS09_02_SSDIV        (0x01)
        #define DF_TS09_02_CTSUSSC      (DF_TS09_02_SSDIV << 8)
        #define DF_TS09_02_SO           (0x000)
        #define DF_TS09_02_SNUM         (3)
        #define DF_TS09_02_CTSUSO0      ((DF_TS09_02_SNUM << 10) | DF_TS09_02_SO)
        #define DF_TS09_02_RICOA        (0x3F)
        #define DF_TS09_02_SDPA         (7)
        #define DF_TS09_02_ICOG         (1)
        #define DF_TS09_02_CTSUSO1      ((DF_TS09_02_ICOG << 13) | (DF_TS09_02_SDPA << 8) | DF_TS09_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS09_03_SSDIV        (0x01)
        #define DF_TS09_03_CTSUSSC      (DF_TS09_03_SSDIV << 8)
        #define DF_TS09_03_SO           (0x000)
        #define DF_TS09_03_SNUM         (3)
        #define DF_TS09_03_CTSUSO0      ((DF_TS09_03_SNUM << 10) | DF_TS09_03_SO)
        #define DF_TS09_03_RICOA        (0x3F)
        #define DF_TS09_03_SDPA         (7)
        #define DF_TS09_03_ICOG         (1)
        #define DF_TS09_03_CTSUSO1      ((DF_TS09_03_ICOG << 13) | (DF_TS09_03_SDPA << 8) | DF_TS09_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS09_04_SSDIV        (0x01)
        #define DF_TS09_04_CTSUSSC      (DF_TS09_04_SSDIV << 8)
        #define DF_TS09_04_SO           (0x000)
        #define DF_TS09_04_SNUM         (3)
        #define DF_TS09_04_CTSUSO0      ((DF_TS09_04_SNUM << 10) | DF_TS09_04_SO)
        #define DF_TS09_04_RICOA        (0x3F)
        #define DF_TS09_04_SDPA         (7)
        #define DF_TS09_04_ICOG         (1)
        #define DF_TS09_04_CTSUSO1      ((DF_TS09_04_ICOG << 13) | (DF_TS09_04_SDPA << 8) | DF_TS09_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS09_05_SSDIV        (0x01)
        #define DF_TS09_05_CTSUSSC      (DF_TS09_05_SSDIV << 8)
        #define DF_TS09_05_SO           (0x000)
        #define DF_TS09_05_SNUM         (3)
        #define DF_TS09_05_CTSUSO0      ((DF_TS09_05_SNUM << 10) | DF_TS09_05_SO)
        #define DF_TS09_05_RICOA        (0x3F)
        #define DF_TS09_05_SDPA         (7)
        #define DF_TS09_05_ICOG         (1)
        #define DF_TS09_05_CTSUSO1      ((DF_TS09_05_ICOG << 13) | (DF_TS09_05_SDPA << 8) | DF_TS09_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS09_06_SSDIV        (0x01)
        #define DF_TS09_06_CTSUSSC      (DF_TS09_06_SSDIV << 8)
        #define DF_TS09_06_SO           (0x000)
        #define DF_TS09_06_SNUM         (3)
        #define DF_TS09_06_CTSUSO0      ((DF_TS09_06_SNUM << 10) | DF_TS09_06_SO)
        #define DF_TS09_06_RICOA        (0x3F)
        #define DF_TS09_06_SDPA         (7)
        #define DF_TS09_06_ICOG         (1)
        #define DF_TS09_06_CTSUSO1      ((DF_TS09_06_ICOG << 13) | (DF_TS09_06_SDPA << 8) | DF_TS09_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS09_07_SSDIV        (0x01)
        #define DF_TS09_07_CTSUSSC      (DF_TS09_07_SSDIV << 8)
        #define DF_TS09_07_SO           (0x000)
        #define DF_TS09_07_SNUM         (3)
        #define DF_TS09_07_CTSUSO0      ((DF_TS09_07_SNUM << 10) | DF_TS09_07_SO)
        #define DF_TS09_07_RICOA        (0x3F)
        #define DF_TS09_07_SDPA         (7)
        #define DF_TS09_07_ICOG         (1)
        #define DF_TS09_07_CTSUSO1      ((DF_TS09_07_ICOG << 13) | (DF_TS09_07_SDPA << 8) | DF_TS09_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS09_08_SSDIV        (0x01)
        #define DF_TS09_08_CTSUSSC      (DF_TS09_08_SSDIV << 8)
        #define DF_TS09_08_SO           (0x000)
        #define DF_TS09_08_SNUM         (3)
        #define DF_TS09_08_CTSUSO0      ((DF_TS09_08_SNUM << 10) | DF_TS09_08_SO)
        #define DF_TS09_08_RICOA        (0x3F)
        #define DF_TS09_08_SDPA         (7)
        #define DF_TS09_08_ICOG         (1)
        #define DF_TS09_08_CTSUSO1      ((DF_TS09_08_ICOG << 13) | (DF_TS09_08_SDPA << 8) | DF_TS09_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS09_09_SSDIV        (0x01)
        #define DF_TS09_09_CTSUSSC      (DF_TS09_09_SSDIV << 8)
        #define DF_TS09_09_SO           (0x000)
        #define DF_TS09_09_SNUM         (3)
        #define DF_TS09_09_CTSUSO0      ((DF_TS09_09_SNUM << 10) | DF_TS09_09_SO)
        #define DF_TS09_09_RICOA        (0x3F)
        #define DF_TS09_09_SDPA         (7)
        #define DF_TS09_09_ICOG         (1)
        #define DF_TS09_09_CTSUSO1      ((DF_TS09_09_ICOG << 13) | (DF_TS09_09_SDPA << 8) | DF_TS09_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS09_10_SSDIV        (0x01)
        #define DF_TS09_10_CTSUSSC      (DF_TS09_10_SSDIV << 8)
        #define DF_TS09_10_SO           (0x000)
        #define DF_TS09_10_SNUM         (3)
        #define DF_TS09_10_CTSUSO0      ((DF_TS09_10_SNUM << 10) | DF_TS09_10_SO)
        #define DF_TS09_10_RICOA        (0x3F)
        #define DF_TS09_10_SDPA         (7)
        #define DF_TS09_10_ICOG         (1)
        #define DF_TS09_10_CTSUSO1      ((DF_TS09_10_ICOG << 13) | (DF_TS09_10_SDPA << 8) | DF_TS09_10_RICOA)
    #endif
#endif

#if DF_TS10_FUNCTION == 1
        #define DF_TS10_00_SSDIV        (0x01)
        #define DF_TS10_00_CTSUSSC      (DF_TS10_00_SSDIV << 8)
        #define DF_TS10_00_SO           (0x000)
        #define DF_TS10_00_SNUM         (3)
        #define DF_TS10_00_CTSUSO0      ((DF_TS10_00_SNUM << 10) | DF_TS10_00_SO)
        #define DF_TS10_00_RICOA        (0x3F)
        #define DF_TS10_00_SDPA         (7)
        #define DF_TS10_00_ICOG         (1)
        #define DF_TS10_00_CTSUSO1      ((DF_TS10_00_ICOG << 13) | (DF_TS10_00_SDPA << 8) | DF_TS10_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS10_01_SSDIV        (0x01)
        #define DF_TS10_01_CTSUSSC      (DF_TS10_01_SSDIV << 8)
        #define DF_TS10_01_SO           (0x000)
        #define DF_TS10_01_SNUM         (3)
        #define DF_TS10_01_CTSUSO0      ((DF_TS10_01_SNUM << 10) | DF_TS10_01_SO)
        #define DF_TS10_01_RICOA        (0x3F)
        #define DF_TS10_01_SDPA         (7)
        #define DF_TS10_01_ICOG         (1)
        #define DF_TS10_01_CTSUSO1      ((DF_TS10_01_ICOG << 13) | (DF_TS10_01_SDPA << 8) | DF_TS10_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS10_02_SSDIV        (0x01)
        #define DF_TS10_02_CTSUSSC      (DF_TS10_02_SSDIV << 8)
        #define DF_TS10_02_SO           (0x000)
        #define DF_TS10_02_SNUM         (3)
        #define DF_TS10_02_CTSUSO0      ((DF_TS10_02_SNUM << 10) | DF_TS10_02_SO)
        #define DF_TS10_02_RICOA        (0x3F)
        #define DF_TS10_02_SDPA         (7)
        #define DF_TS10_02_ICOG         (1)
        #define DF_TS10_02_CTSUSO1      ((DF_TS10_02_ICOG << 13) | (DF_TS10_02_SDPA << 8) | DF_TS10_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS10_03_SSDIV        (0x01)
        #define DF_TS10_03_CTSUSSC      (DF_TS10_03_SSDIV << 8)
        #define DF_TS10_03_SO           (0x000)
        #define DF_TS10_03_SNUM         (3)
        #define DF_TS10_03_CTSUSO0      ((DF_TS10_03_SNUM << 10) | DF_TS10_03_SO)
        #define DF_TS10_03_RICOA        (0x3F)
        #define DF_TS10_03_SDPA         (7)
        #define DF_TS10_03_ICOG         (1)
        #define DF_TS10_03_CTSUSO1      ((DF_TS10_03_ICOG << 13) | (DF_TS10_03_SDPA << 8) | DF_TS10_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS10_04_SSDIV        (0x01)
        #define DF_TS10_04_CTSUSSC      (DF_TS10_04_SSDIV << 8)
        #define DF_TS10_04_SO           (0x000)
        #define DF_TS10_04_SNUM         (3)
        #define DF_TS10_04_CTSUSO0      ((DF_TS10_04_SNUM << 10) | DF_TS10_04_SO)
        #define DF_TS10_04_RICOA        (0x3F)
        #define DF_TS10_04_SDPA         (7)
        #define DF_TS10_04_ICOG         (1)
        #define DF_TS10_04_CTSUSO1      ((DF_TS10_04_ICOG << 13) | (DF_TS10_04_SDPA << 8) | DF_TS10_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS10_05_SSDIV        (0x01)
        #define DF_TS10_05_CTSUSSC      (DF_TS10_05_SSDIV << 8)
        #define DF_TS10_05_SO           (0x000)
        #define DF_TS10_05_SNUM         (3)
        #define DF_TS10_05_CTSUSO0      ((DF_TS10_05_SNUM << 10) | DF_TS10_05_SO)
        #define DF_TS10_05_RICOA        (0x3F)
        #define DF_TS10_05_SDPA         (7)
        #define DF_TS10_05_ICOG         (1)
        #define DF_TS10_05_CTSUSO1      ((DF_TS10_05_ICOG << 13) | (DF_TS10_05_SDPA << 8) | DF_TS10_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS10_06_SSDIV        (0x01)
        #define DF_TS10_06_CTSUSSC      (DF_TS10_06_SSDIV << 8)
        #define DF_TS10_06_SO           (0x000)
        #define DF_TS10_06_SNUM         (3)
        #define DF_TS10_06_CTSUSO0      ((DF_TS10_06_SNUM << 10) | DF_TS10_06_SO)
        #define DF_TS10_06_RICOA        (0x3F)
        #define DF_TS10_06_SDPA         (7)
        #define DF_TS10_06_ICOG         (1)
        #define DF_TS10_06_CTSUSO1      ((DF_TS10_06_ICOG << 13) | (DF_TS10_06_SDPA << 8) | DF_TS10_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS10_07_SSDIV        (0x01)
        #define DF_TS10_07_CTSUSSC      (DF_TS10_07_SSDIV << 8)
        #define DF_TS10_07_SO           (0x000)
        #define DF_TS10_07_SNUM         (3)
        #define DF_TS10_07_CTSUSO0      ((DF_TS10_07_SNUM << 10) | DF_TS10_07_SO)
        #define DF_TS10_07_RICOA        (0x3F)
        #define DF_TS10_07_SDPA         (7)
        #define DF_TS10_07_ICOG         (1)
        #define DF_TS10_07_CTSUSO1      ((DF_TS10_07_ICOG << 13) | (DF_TS10_07_SDPA << 8) | DF_TS10_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS10_08_SSDIV        (0x01)
        #define DF_TS10_08_CTSUSSC      (DF_TS10_08_SSDIV << 8)
        #define DF_TS10_08_SO           (0x000)
        #define DF_TS10_08_SNUM         (3)
        #define DF_TS10_08_CTSUSO0      ((DF_TS10_08_SNUM << 10) | DF_TS10_08_SO)
        #define DF_TS10_08_RICOA        (0x3F)
        #define DF_TS10_08_SDPA         (7)
        #define DF_TS10_08_ICOG         (1)
        #define DF_TS10_08_CTSUSO1      ((DF_TS10_08_ICOG << 13) | (DF_TS10_08_SDPA << 8) | DF_TS10_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS10_09_SSDIV        (0x01)
        #define DF_TS10_09_CTSUSSC      (DF_TS10_09_SSDIV << 8)
        #define DF_TS10_09_SO           (0x000)
        #define DF_TS10_09_SNUM         (3)
        #define DF_TS10_09_CTSUSO0      ((DF_TS10_09_SNUM << 10) | DF_TS10_09_SO)
        #define DF_TS10_09_RICOA        (0x3F)
        #define DF_TS10_09_SDPA         (7)
        #define DF_TS10_09_ICOG         (1)
        #define DF_TS10_09_CTSUSO1      ((DF_TS10_09_ICOG << 13) | (DF_TS10_09_SDPA << 8) | DF_TS10_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS10_10_SSDIV        (0x01)
        #define DF_TS10_10_CTSUSSC      (DF_TS10_10_SSDIV << 8)
        #define DF_TS10_10_SO           (0x000)
        #define DF_TS10_10_SNUM         (3)
        #define DF_TS10_10_CTSUSO0      ((DF_TS10_10_SNUM << 10) | DF_TS10_10_SO)
        #define DF_TS10_10_RICOA        (0x3F)
        #define DF_TS10_10_SDPA         (7)
        #define DF_TS10_10_ICOG         (1)
        #define DF_TS10_10_CTSUSO1      ((DF_TS10_10_ICOG << 13) | (DF_TS10_10_SDPA << 8) | DF_TS10_10_RICOA)
    #endif
#endif

#if DF_TS11_FUNCTION == 1
        #define DF_TS11_00_SSDIV        (0x01)
        #define DF_TS11_00_CTSUSSC      (DF_TS11_00_SSDIV << 8)
        #define DF_TS11_00_SO           (0x000)
        #define DF_TS11_00_SNUM         (3)
        #define DF_TS11_00_CTSUSO0      ((DF_TS11_00_SNUM << 10) | DF_TS11_00_SO)
        #define DF_TS11_00_RICOA        (0x3F)
        #define DF_TS11_00_SDPA         (7)
        #define DF_TS11_00_ICOG         (1)
        #define DF_TS11_00_CTSUSO1      ((DF_TS11_00_ICOG << 13) | (DF_TS11_00_SDPA << 8) | DF_TS11_00_RICOA)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS11_01_SSDIV        (0x01)
        #define DF_TS11_01_CTSUSSC      (DF_TS11_01_SSDIV << 8)
        #define DF_TS11_01_SO           (0x000)
        #define DF_TS11_01_SNUM         (3)
        #define DF_TS11_01_CTSUSO0      ((DF_TS11_01_SNUM << 10) | DF_TS11_01_SO)
        #define DF_TS11_01_RICOA        (0x3F)
        #define DF_TS11_01_SDPA         (7)
        #define DF_TS11_01_ICOG         (1)
        #define DF_TS11_01_CTSUSO1      ((DF_TS11_01_ICOG << 13) | (DF_TS11_01_SDPA << 8) | DF_TS11_01_RICOA)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS11_02_SSDIV        (0x01)
        #define DF_TS11_02_CTSUSSC      (DF_TS11_02_SSDIV << 8)
        #define DF_TS11_02_SO           (0x000)
        #define DF_TS11_02_SNUM         (3)
        #define DF_TS11_02_CTSUSO0      ((DF_TS11_02_SNUM << 10) | DF_TS11_02_SO)
        #define DF_TS11_02_RICOA        (0x3F)
        #define DF_TS11_02_SDPA         (7)
        #define DF_TS11_02_ICOG         (1)
        #define DF_TS11_02_CTSUSO1      ((DF_TS11_02_ICOG << 13) | (DF_TS11_02_SDPA << 8) | DF_TS11_02_RICOA)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS11_03_SSDIV        (0x01)
        #define DF_TS11_03_CTSUSSC      (DF_TS11_03_SSDIV << 8)
        #define DF_TS11_03_SO           (0x000)
        #define DF_TS11_03_SNUM         (3)
        #define DF_TS11_03_CTSUSO0      ((DF_TS11_03_SNUM << 10) | DF_TS11_03_SO)
        #define DF_TS11_03_RICOA        (0x3F)
        #define DF_TS11_03_SDPA         (7)
        #define DF_TS11_03_ICOG         (1)
        #define DF_TS11_03_CTSUSO1      ((DF_TS11_03_ICOG << 13) | (DF_TS11_03_SDPA << 8) | DF_TS11_03_RICOA)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS11_04_SSDIV        (0x01)
        #define DF_TS11_04_CTSUSSC      (DF_TS11_04_SSDIV << 8)
        #define DF_TS11_04_SO           (0x000)
        #define DF_TS11_04_SNUM         (3)
        #define DF_TS11_04_CTSUSO0      ((DF_TS11_04_SNUM << 10) | DF_TS11_04_SO)
        #define DF_TS11_04_RICOA        (0x3F)
        #define DF_TS11_04_SDPA         (7)
        #define DF_TS11_04_ICOG         (1)
        #define DF_TS11_04_CTSUSO1      ((DF_TS11_04_ICOG << 13) | (DF_TS11_04_SDPA << 8) | DF_TS11_04_RICOA)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS11_05_SSDIV        (0x01)
        #define DF_TS11_05_CTSUSSC      (DF_TS11_05_SSDIV << 8)
        #define DF_TS11_05_SO           (0x000)
        #define DF_TS11_05_SNUM         (3)
        #define DF_TS11_05_CTSUSO0      ((DF_TS11_05_SNUM << 10) | DF_TS11_05_SO)
        #define DF_TS11_05_RICOA        (0x3F)
        #define DF_TS11_05_SDPA         (7)
        #define DF_TS11_05_ICOG         (1)
        #define DF_TS11_05_CTSUSO1      ((DF_TS11_05_ICOG << 13) | (DF_TS11_05_SDPA << 8) | DF_TS11_05_RICOA)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS11_06_SSDIV        (0x01)
        #define DF_TS11_06_CTSUSSC      (DF_TS11_06_SSDIV << 8)
        #define DF_TS11_06_SO           (0x000)
        #define DF_TS11_06_SNUM         (3)
        #define DF_TS11_06_CTSUSO0      ((DF_TS11_06_SNUM << 10) | DF_TS11_06_SO)
        #define DF_TS11_06_RICOA        (0x3F)
        #define DF_TS11_06_SDPA         (7)
        #define DF_TS11_06_ICOG         (1)
        #define DF_TS11_06_CTSUSO1      ((DF_TS11_06_ICOG << 13) | (DF_TS11_06_SDPA << 8) | DF_TS11_06_RICOA)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS11_07_SSDIV        (0x01)
        #define DF_TS11_07_CTSUSSC      (DF_TS11_07_SSDIV << 8)
        #define DF_TS11_07_SO           (0x000)
        #define DF_TS11_07_SNUM         (3)
        #define DF_TS11_07_CTSUSO0      ((DF_TS11_07_SNUM << 10) | DF_TS11_07_SO)
        #define DF_TS11_07_RICOA        (0x3F)
        #define DF_TS11_07_SDPA         (7)
        #define DF_TS11_07_ICOG         (1)
        #define DF_TS11_07_CTSUSO1      ((DF_TS11_07_ICOG << 13) | (DF_TS11_07_SDPA << 8) | DF_TS11_07_RICOA)
    #endif
    #if ( RECEIVE_NUM > 8 )
        #define DF_TS11_08_SSDIV        (0x01)
        #define DF_TS11_08_CTSUSSC      (DF_TS11_08_SSDIV << 8)
        #define DF_TS11_08_SO           (0x000)
        #define DF_TS11_08_SNUM         (3)
        #define DF_TS11_08_CTSUSO0      ((DF_TS11_08_SNUM << 10) | DF_TS11_08_SO)
        #define DF_TS11_08_RICOA        (0x3F)
        #define DF_TS11_08_SDPA         (7)
        #define DF_TS11_08_ICOG         (1)
        #define DF_TS11_08_CTSUSO1      ((DF_TS11_08_ICOG << 13) | (DF_TS11_08_SDPA << 8) | DF_TS11_08_RICOA)
    #endif
    #if ( RECEIVE_NUM > 9 )
        #define DF_TS11_09_SSDIV        (0x01)
        #define DF_TS11_09_CTSUSSC      (DF_TS11_09_SSDIV << 8)
        #define DF_TS11_09_SO           (0x000)
        #define DF_TS11_09_SNUM         (3)
        #define DF_TS11_09_CTSUSO0      ((DF_TS11_09_SNUM << 10) | DF_TS11_09_SO)
        #define DF_TS11_09_RICOA        (0x3F)
        #define DF_TS11_09_SDPA         (7)
        #define DF_TS11_09_ICOG         (1)
        #define DF_TS11_09_CTSUSO1      ((DF_TS11_09_ICOG << 13) | (DF_TS11_09_SDPA << 8) | DF_TS11_09_RICOA)
    #endif
    #if ( RECEIVE_NUM > 10 )
        #define DF_TS11_10_SSDIV        (0x01)
        #define DF_TS11_10_CTSUSSC      (DF_TS11_10_SSDIV << 8)
        #define DF_TS11_10_SO           (0x000)
        #define DF_TS11_10_SNUM         (3)
        #define DF_TS11_10_CTSUSO0      ((DF_TS11_10_SNUM << 10) | DF_TS11_10_SO)
        #define DF_TS11_10_RICOA        (0x3F)
        #define DF_TS11_10_SDPA         (7)
        #define DF_TS11_10_ICOG         (1)
        #define DF_TS11_10_CTSUSO1      ((DF_TS11_10_ICOG << 13) | (DF_TS11_10_SDPA << 8) | DF_TS11_10_RICOA)
    #endif
#endif

/* Measurement Mode */
#define MD_SELF_SINGLE      (0)
#define MD_SELF_MULTI       (1)
#define MD_MUTUAL_SIMPLE    (2)
#define MD_MUTUAL_FULL      (3)

/* DTC for CTSU */
#define CTSU_DTC_WR_CNT     (0x0303)              /* DTC Write count / 3byte */
#define CTSU_DTC_RD_CNT     (0x0202)              /* DTC Read count / 2word */

/* DTC Mode Register A (MRA) */
/* Transfer Source Address Addressing Mode */
#define DTC_SM_FIXED        (0)   /* Address in the SAR register is fixed. */
#define DTC_SM_FIXEDb       (1)   /* Address in the SAR register is fixed. */
#define DTC_SM_INC          (2)   /* SAR value is incremented after data transfer. */
#define DTC_SM_DEC          (3)   /* SAR value is decremented after data transfer. */
/* DTC Data Transfer Size */
#define DTC_SZ_BYTE         (0)   /* Byte (8-bit) transfer */
#define DTC_SZ_WORD         (1)   /* Word (16-bit) transfer */
#define DTC_SZ_LONG         (2)   /* Longword (32-bit) transfer */
/* DTC Transfer Mode Select */
#define DTC_MD_NORMAL       (0)   /* Normal transfer mode */
#define DTC_MD_REPEAT       (1)   /* Repeat transfer mode */
#define DTC_MD_BLOCK        (2)   /* Block transfer mode */

/* DTC Mode Register B (MRB) */
/* Transfer Destination Address Addressing Mode */
#define DTC_DM_FIXED        (0)   /* Address in the DAR register is fixed. */
#define DTC_DM_FIXEDb       (1)   /* Address in the DAR register is fixed. */
#define DTC_DM_INC          (2)   /* DAR value is incremented after data transfer. */
#define DTC_DM_DEC          (3)   /* DAR value is decremented after data transfer. */
/* DTC Transfer Mode Select */
#define DTC_DTS_DAR         (0)   /* Transfer destination side is repeat area or block area. */
#define DTC_DTS_SAR         (1)   /* Transfer source side is repeat area or block area. */
/* DTC Interrupt Select */
#define DTC_DISEL_COMPLETED (0)   /* An interrupt request to the CPU is generated 
                                   when specified data transfer is completed. */
#define DTC_DISEL_EACH      (1)   /* An interrupt request to the CPU is generated each time
                                   DTC data transfer is performed. */
/* DTC Chain Transfer Select */
#define DTC_CHNS_CONTINUE   (0)   /* Chain transfer is performed continuously. */
#define DTC_CHNS_CONTER     (1)   /* Chain transfer is performed only when the transfer counter is
                                   changed from 1 to 0 or 1 to CRAH. */
/* DTC Chain Transfer Enable */
#define DTC_CHNE_DISABLE    (0)   /* Chain transfer is disabled. */
#define DTC_CHNE_ENABLE     (1)   /* Chain transfer is enabled. */

/* DTC Module Start Register (DTCST) */
/* DTC Module Start */
#define DTC_DTCST_STOP      (0)   /* DTC module stop */
#define DTC_DTCST_START     (1)   /* DTC module start */

/* DTC Control Register (DTCCR) */
/* DTC Transfer Information Read Skip Enable */
#define DTC_RRS_NOTSKIP     (0)   /* Transfer information read is not skipped. */
#define DTC_RRS_SKIP        (1)   /* Transfer information read is skipped when vector numbers match. */

/* DTC Address Mode Register (DTCADMOD) */
/* Short-Address Mode */
#define DTC_SHORT_FULL      (0)   /* Full-address mode */
#define DTC_SHORT_SHORT     (1)   /* Short-address mode */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/


/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
#define CTSU_DRIVER_SELF    (0)
#define CTSU_DRIVER_MUTUAL  (1)

#define PHYSICAL_TS_ERR     (0)

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CTSUSetMeasurementOperation( uint8_t mode, uint8_t trigger);
void CTSUSetTransmitPinControl( uint8_t mode );
void CTSUSetControlBlockInitial( uint8_t mode );
void CTSUSetPowerSupplyEnable( uint8_t mode );
void CTSUSetPowerSupplyOnly( uint8_t mode );
void CTSUSetLpfPinControl( uint8_t mode );
void CTSUSetLpfChargingControl( uint8_t mode );
void CTSUSetLowPowControl( uint8_t mode );
void CTSUSetIcoCurrentAttenuator( uint8_t mode );
void CTSUSetCountSource( uint8_t mode );
void CTSUSetMeasurementMode( uint8_t mode );
void CTSUSetSensorDrivePulseSpectrumDiffusion( uint8_t cycle, uint8_t mode, uint8_t edge );
void CTSUSetSensorStabilizationWaitTime( uint8_t time );
uint8_t CTSUSetMeasurementChannel( uint8_t ch );
uint8_t CTSUGetTransmitChannel( void );
void CTSUSetChannelEnableControl( uint16_t ch );
void CTSUSetChannelTransmitReceiveControl( uint16_t ch );
void CTSUSetDiffusionClockModeSelect( uint8_t mode, uint8_t clock );
uint8_t CTSUGetMeasurementStatusCounter( void );
uint8_t CTSUGetDataTransferStatus( void );
uint8_t CTSUGetCounterOverflow( void );
uint8_t CTSUGetMutualCapacitanceMeasurementStatus( void );
uint8_t CTSUGetTscapVoltageError( void );

void CTSUWriteCTSUCR0( uint8_t data );
uint8_t CTSUReadCTSUCR0( void );
void CTSUWriteCTSUCR1( uint8_t data );
uint8_t CTSUReadCTSUCR1( void );
void CTSUWriteCTSUSDPRS( uint8_t data );
uint8_t CTSUReadCTSUSDPRS( void );
void CTSUWriteCTSUSST( uint8_t data );
uint8_t CTSUReadCTSUSST( void );
void CTSUWriteCTSUMCH0( uint8_t data );
uint8_t CTSUReadCTSUMCH0( void );
void CTSUWriteCTSUMCH1( uint8_t data );
uint8_t CTSUReadCTSUMCH1( void );
void CTSUWriteCTSUCHAC0( uint8_t data );
uint8_t CTSUReadCTSUCHAC0( void );
void CTSUWriteCTSUCHAC1( uint8_t data );
uint8_t CTSUReadCTSUCHAC1( void );
void CTSUWriteCTSUCHTRC0( uint8_t data );
uint8_t CTSUReadCTSUCHTRC0( void );
void CTSUWriteCTSUCHTRC1( uint8_t data );
uint8_t CTSUReadCTSUCHTRC1( void );
void CTSUWriteCTSUDCLKC( uint8_t data );
uint8_t CTSUReadCTSUDCLKC( void );
void CTSUWriteCTSUST( uint8_t data );
uint8_t CTSUReadCTSUST( void );
void CTSUWriteCTSUERRS( uint16_t data );
uint16_t CTSUReadCTSUERRS( void );

/* Library */
#include "r_dtc_table.h"
void CTSUSetDtcStart( DTC_DATA_T *dtc_ctsu_wr, DTC_DATA_T *dtc_ctsu_rd, uint16_t *g_write, ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t mode );
void CTSUSetDtcInitial( DTC_DATA_T *dtc_ctsu_wr, DTC_DATA_T *dtc_ctsu_rd, uint16_t *g_write, ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t mode );
void CTSUSetSpectrumDiffusionControl( uint16_t *g_write, uint8_t *g_index, uint8_t cycle, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetSensorOffsetAdjustment( uint16_t *g_write, uint8_t *g_index, uint16_t offset, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetMeasurementCount( uint16_t *g_write, uint8_t *g_index, uint8_t count, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetReferenceICOCurrentAdjustment( uint16_t *g_write, uint8_t *g_index, uint8_t count, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetSensorDrivePulseDivisionControl( uint16_t *g_write, uint8_t *g_index, uint8_t division, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetICOGainAdjustment( uint16_t *g_write, uint8_t *g_index, uint8_t gain, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUGetSensorCounter( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index,uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUGetReferenceCounter( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSSC( uint16_t *g_write, uint8_t *g_index, uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSSC( uint16_t *g_write, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSO0( uint16_t *g_write, uint8_t *g_index, uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSO0( uint16_t *g_write, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSO1( uint16_t *g_write, uint8_t *g_index,uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSO1( uint16_t *g_write, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index,uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSURC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSURC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts);


#endif  //] __R_TOUCH_PHYSICAL_DRIVER_H__
