/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_physical_driver.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#ifndef __R_CTSU_PHYSICAL_DRIVER_H__    //[
#define __R_CTSU_PHYSICAL_DRIVER_H__

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
#include "r_ctsu_parameter_common.h"
#include "r_ctsu_common_control.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef __R_CTSU_PHYSICAL_DRIVER_C__
    #define CTSU_EXTERN
#else
    #define CTSU_EXTERN    extern
#endif

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
/* #define WORKBENCH_USB    (1) */

/* Select the clock condition */
#define TOUCH_SAMPLE_CLOCK_SOURCE    (4)
#define TOUCH_SAMPLE_HOCO_HZ         (32000000)
#define TOUCH_SAMPLE_XTAL_HZ         (16000000)
#define TOUCH_SAMPLE_SYSTEM_HZ       (32000000)

/* Clock Source */
#define TOUCH_CLOCK_SOURCE_LOCO     (0)         /* Low Speed On-Chip Oscillator  (LOCO)                  */
#define TOUCH_CLOCK_SOURCE_HOCO     (1)         /* High Speed On-Chip Oscillator (HOCO)                  */
#define TOUCH_CLOCK_SOURCE_MAIN     (2)         /* Main Clock Oscillator                                 */
#define TOUCH_CLOCK_SOURCE_SUB      (3)         /* Sub-Clock Oscillator                                  */
#define TOUCH_CLOCK_SOURCE_PLL      (4)         /* PLL Circuit                                           */

/* Clock Frequency */
#define TOUCH_SAMPLE_6MHZ           (6000000)   /* 6MHz                                                  */
#define TOUCH_SAMPLE_8MHZ           (8000000)   /* 8MHz                                                  */
#define TOUCH_SAMPLE_10MHZ          (10000000)  /* 10MHz                                                 */
#define TOUCH_SAMPLE_12MHZ          (12000000)  /* 12MHz                                                 */
#define TOUCH_SAMPLE_16MHZ          (16000000)  /* 16MHz                                                 */
#define TOUCH_SAMPLE_32MHZ          (32000000)  /* 32MHz                                                 */

/* USB Serial Use */
#if(TOUCH_SAMPLE_CLOCK_SOURCE == TOUCH_CLOCK_SOURCE_PLL)    /* PLL Select(Main Clock)                    */
  #if((TOUCH_SAMPLE_XTAL_HZ == TOUCH_SAMPLE_16MHZ) || (TOUCH_SAMPLE_XTAL_HZ == TOUCH_SAMPLE_8MHZ))
    #define USB_SERIAL_USE
  #else
    #undef USB_SERIAL_USE
  #endif
#elif(TOUCH_SAMPLE_CLOCK_SOURCE == TOUCH_CLOCK_SOURCE_HOCO) /* HOCO Select                               */
    #undef USB_SERIAL_USE
#else
    #undef USB_SERIAL_USE
#endif

/***** Touch measurement cycle ****************************************************************************************/
/* Touch Measurement cycle (ms) */
#define TOUCH_MEASUREMENT_CYCLE_MS       (20)

/* Touch Measurement cycle macro (ms) */
#define TOUCH_MEASUREMENT_20MS           (20)
#define TOUCH_MEASUREMENT_40MS           (40)

/* Compare Match Timer Control Register Clock Select PCLK/xxx */
#define CTSU_CMCOR_CKS         (128)

#if(TOUCH_MEASUREMENT_CYCLE_MS == TOUCH_MEASUREMENT_20MS)
    #define TOUCH_CMT_FREQUENCY_HZ      (50)       /* 20ms = 50Hz */
#elif(TOUCH_MEASUREMENT_CYCLE_MS == TOUCH_MEASUREMENT_40MS)
    #define TOUCH_CMT_FREQUENCY_HZ      (25)       /* 40ms = 25Hz */
#else
#endif

/* Compare Match Constant Register for Touch */
#define TOUCH_CMCOR_VALUE       (TOUCH_SAMPLE_SYSTEM_HZ/CTSU_CMCOR_CKS)/TOUCH_CMT_FREQUENCY_HZ

/***** A0900h CTSU control register0 ************************************************************************/
#define DF_CTSUCAP       (0)            /* 0 = software trigger                                             */
                                        /* 1 = external trigger                                             */
#define DF_CTSUIOC       (0)            /* 0 = non-measurement pin low level                                */
                                        /* 1 = non-measurement pin high level                               */

/***** A0901h CTSU channel register1 ************************************************************************/
#define DF_CTSUPON       (1)            /* 0 = CTSU hardware macro power off                                */
                                        /* 1 = CTSU hardware macro power on                                 */
#define DF_CTSUCSW       (1)            /* 0 = Capacitance switch turned off                                */
                                        /* 1 = Capacitance switch turned on                                 */
#define DF_CTSUATUNE0    (0)            /* 0 = Normal operating mode                                        */
                                        /* 1 = Low-voltage operating mode                                   */
#define DF_CTSUATUNE1    (0)            /* 0 = Normal output                                                */
                                        /* 1 = High-current output                                          */
#define DF_CTSUCLK       (0)            /* 0 = PCLK                                                         */
                                        /* 1 = PCLK/2                                                       */
                                        /* 2 = PCLK/4                                                       */
#define DF_CTSUMD        (1)            /* 0 = Self-capacitance single scan mode                            */
                                        /* 1 = Self-capacitance multi-scan mode                             */
                                        /* 2 = Setting prohibited                                           */
                                        /* 3 = Mutual capacitance full scan mode                            */
#define DF_CTSUCR1      ((DF_CTSUMD << 6) | (DF_CTSUCLK << 4) | (DF_CTSUATUNE1 << 3) | (DF_CTSUATUNE0 << 2)|  \
                         (DF_CTSUCSW << 1) | DF_CTSUPON)

/***** A0902h CTSU Sensor drive pulse spectrum diffusion set register ***************************************/
#define DF_CTSUPRRATIO   (3)            /* 3 = Recommended setting value                                    */
#define DF_CTSUPRMODE    (2)            /* 0 = 510 pulses                                                   */
                                        /* 1 = 126 pulses                                                   */
                                        /* 2 = 62 pulses (recommended setting value)                        */
                                        /* 3 = Setting prohibited                                           */
#define DF_CTSUSOFF      (0)            /* 0 = High-pass noise reduction function turned on                 */
                                        /* 1 = High-pass noise reduction function turned off                */
#define DF_CTSUSDPRS    (DF_CTSUSOFF << 6) | (DF_CTSUPRMODE << 4) | DF_CTSUPRRATIO

/***** A0903h CTSU Sensor wait time register ****************************************************************/
#define DF_CTSUSST       (16)           /* The value of these bits should be fixed to 00010000b             */

/***** A0904h CTSU Measurement channel register0 ************************************************************/
#define DF_CTSUMCH0      (0x00)         /* 0x00 = TS1 ---> 0x0B = TS11                                      */

/***** A0905h CTSU Measurement channel register1 ************************************************************/
#define DF_CTSUMCH1      (0x00)         /* 0x00 = TS1 ---> 0x0B = TS11                                      */

/***** A0906h CTSU Channel enable control register0 *********************************************************/
#define DF_CTSUCHAC0    ((DF_ENABLE_TS00 << 0) | (DF_ENABLE_TS01 << 1) | (DF_ENABLE_TS02 << 2) | \
                         (DF_ENABLE_TS03 << 3) | (DF_ENABLE_TS04 << 4) | (DF_ENABLE_TS05 << 5) | \
                         (DF_ENABLE_TS06 << 6) | (DF_ENABLE_TS07 << 7))
                                        /* 0 = disenable                                                    */
                                        /* 1 = enable                                                       */
                                        /* ex) 0x03 ---> TS0-TS1 enable   0xFF ---> TS0-TS7 enable          */

/***** A0907h CTSU Channel enable control register1 *********************************************************/
#define DF_CTSUCHAC1    ((DF_ENABLE_TS08 << 0) | (DF_ENABLE_TS09 << 1) | (DF_ENABLE_TS10 << 2) | \
                         (DF_ENABLE_TS11 << 3) | (DF_ENABLE_TS12 << 4) | (DF_ENABLE_TS13 << 5) | \
                         (DF_ENABLE_TS14 << 6) | (DF_ENABLE_TS15 << 7))
                                        /* 0 = disenable                                                    */
                                        /* 1 = enable                                                       */
                                        /* ex) 0x03 ---> TS8-TS9 enable   0x0F ---> TS8-TS11 enable         */

/***** A090*h CTSU Channel enable control register2 *********************************************************/
#define DF_CTSUCHAC2    ((DF_ENABLE_TS16 << 0) | (DF_ENABLE_TS17 << 1) | (DF_ENABLE_TS18 << 2) | \
                         (DF_ENABLE_TS19 << 3) | (DF_ENABLE_TS20 << 4) | (DF_ENABLE_TS21 << 5) | \
                         (DF_ENABLE_TS22 << 6) | (DF_ENABLE_TS23 << 7))

/***** A090*h CTSU Channel enable control register3 *********************************************************/
#define DF_CTSUCHAC3    ((DF_ENABLE_TS24 << 0) | (DF_ENABLE_TS25 << 1) | (DF_ENABLE_TS26 << 2) | \
                         (DF_ENABLE_TS27 << 3) | (DF_ENABLE_TS28 << 4) | (DF_ENABLE_TS29 << 5) | \
                         (DF_ENABLE_TS30 << 6) | (DF_ENABLE_TS31 << 7))

/***** A090*h CTSU Channel enable control register4 *********************************************************/
#define DF_CTSUCHAC4    ((DF_ENABLE_TS32 << 0) | (DF_ENABLE_TS33 << 1) | (DF_ENABLE_TS34 << 2) | \
                         (DF_ENABLE_TS35 << 3))

/***** A090Bh CTSU Channel send and receive control register0 ************************************************/
#define DF_CTSUCHTRC0    (0x00)      /* self-capacitance not used                                            */

/***** A090Ch CTSU Channel send and receive control register1 ************************************************/
#define DF_CTSUCHTRC1    (0x00)      /* self-capacitance not used                                            */

/***** A0910h CTSU Diffusion clock  control register *********************************************************/
#define DF_CTSUSSMOD     (0)              /* These bits should be set to 00b.                                */
#define DF_CTSUSSCNT     (3)              /* These bits should be set to 11b.                                */
#define DF_CTSUDCLKC    ((DF_CTSUSSCNT << 4) | DF_CTSUSSMOD)

/***** A0912h CTSU Spectrum diffusion control register *******************************************************/
/* CTSU Spectrum Diffusion Sampling Cycle Control
   b3-b0 -> 0-15 (or 0x00-0x0F)
   The sampling cycle of the edge diffusion function can be set to divided by 1 to divided by 16. */
#define DF_TS00_SSDIV    (0x07)  //
#define DF_TS01_SSDIV    (0x07)  //
#define DF_TS02_SSDIV    (0x07)  //
#define DF_TS03_SSDIV    (0x07)  //
#define DF_TS04_SSDIV    (0x07)  //
#define DF_TS05_SSDIV    (0x07)  //
#define DF_TS06_SSDIV    (0x07)  //
#define DF_TS07_SSDIV    (0x07)  //
#define DF_TS08_SSDIV    (0x07)  //
#define DF_TS09_SSDIV    (0x07)  //
#define DF_TS10_SSDIV    (0x07)  //
#define DF_TS11_SSDIV    (0x07)  //
#define DF_TS12_SSDIV    (0x00)  //
#define DF_TS13_SSDIV    (0x00)  //
#define DF_TS14_SSDIV    (0x00)  //
#define DF_TS15_SSDIV    (0x00)  //
#define DF_TS16_SSDIV    (0x00)  //
#define DF_TS17_SSDIV    (0x00)  //
#define DF_TS18_SSDIV    (0x00)  //
#define DF_TS19_SSDIV    (0x00)  //
#define DF_TS20_SSDIV    (0x00)  //
#define DF_TS21_SSDIV    (0x00)  //
#define DF_TS22_SSDIV    (0x00)  //
#define DF_TS23_SSDIV    (0x00)  //
#define DF_TS24_SSDIV    (0x00)  //
#define DF_TS25_SSDIV    (0x00)  //
#define DF_TS26_SSDIV    (0x00)  //
#define DF_TS27_SSDIV    (0x00)  //
#define DF_TS28_SSDIV    (0x00)  //
#define DF_TS29_SSDIV    (0x00)  //
#define DF_TS30_SSDIV    (0x00)  //
#define DF_TS31_SSDIV    (0x00)  //
#define DF_TS32_SSDIV    (0x00)  //
#define DF_TS33_SSDIV    (0x00)  //
#define DF_TS34_SSDIV    (0x00)  //
#define DF_TS35_SSDIV    (0x00)  //

#define DF_TS00_CTSUSSC    (DF_TS00_SSDIV << 8)
#define DF_TS01_CTSUSSC    (DF_TS01_SSDIV << 8)
#define DF_TS02_CTSUSSC    (DF_TS02_SSDIV << 8)
#define DF_TS03_CTSUSSC    (DF_TS03_SSDIV << 8)
#define DF_TS04_CTSUSSC    (DF_TS04_SSDIV << 8)
#define DF_TS05_CTSUSSC    (DF_TS05_SSDIV << 8)
#define DF_TS06_CTSUSSC    (DF_TS06_SSDIV << 8)
#define DF_TS07_CTSUSSC    (DF_TS07_SSDIV << 8)
#define DF_TS08_CTSUSSC    (DF_TS08_SSDIV << 8)
#define DF_TS09_CTSUSSC    (DF_TS09_SSDIV << 8)
#define DF_TS10_CTSUSSC    (DF_TS10_SSDIV << 8)
#define DF_TS11_CTSUSSC    (DF_TS11_SSDIV << 8)
#define DF_TS12_CTSUSSC    (DF_TS12_SSDIV << 8)
#define DF_TS13_CTSUSSC    (DF_TS13_SSDIV << 8)
#define DF_TS14_CTSUSSC    (DF_TS14_SSDIV << 8)
#define DF_TS15_CTSUSSC    (DF_TS15_SSDIV << 8)
#define DF_TS16_CTSUSSC    (DF_TS16_SSDIV << 8)
#define DF_TS17_CTSUSSC    (DF_TS17_SSDIV << 8)
#define DF_TS18_CTSUSSC    (DF_TS18_SSDIV << 8)
#define DF_TS19_CTSUSSC    (DF_TS19_SSDIV << 8)
#define DF_TS20_CTSUSSC    (DF_TS20_SSDIV << 8)
#define DF_TS21_CTSUSSC    (DF_TS21_SSDIV << 8)
#define DF_TS22_CTSUSSC    (DF_TS22_SSDIV << 8)
#define DF_TS23_CTSUSSC    (DF_TS23_SSDIV << 8)
#define DF_TS24_CTSUSSC    (DF_TS24_SSDIV << 8)
#define DF_TS25_CTSUSSC    (DF_TS25_SSDIV << 8)
#define DF_TS26_CTSUSSC    (DF_TS26_SSDIV << 8)
#define DF_TS27_CTSUSSC    (DF_TS27_SSDIV << 8)
#define DF_TS28_CTSUSSC    (DF_TS28_SSDIV << 8)
#define DF_TS29_CTSUSSC    (DF_TS29_SSDIV << 8)
#define DF_TS30_CTSUSSC    (DF_TS30_SSDIV << 8)
#define DF_TS31_CTSUSSC    (DF_TS31_SSDIV << 8)
#define DF_TS32_CTSUSSC    (DF_TS32_SSDIV << 8)
#define DF_TS33_CTSUSSC    (DF_TS33_SSDIV << 8)
#define DF_TS34_CTSUSSC    (DF_TS34_SSDIV << 8)
#define DF_TS35_CTSUSSC    (DF_TS35_SSDIV << 8)

/***** A0914h CTSU Sensor offset register0 *******************************************************************/
/* CTSU Sensor Offset Adjustment
   b9-b0 -> 0-1023 (or 0x000-0x3FF)
   Adjustment bits used to offset the parasitic capacitance while the electrode is not touched. 
   The current offset value generated from the parasitic capacitance ranges from 0 to 153.45uA. */
#define DF_TS00_SO    (0x000)  //
#define DF_TS01_SO    (0x000)  //
#define DF_TS02_SO    (0x000)  //
#define DF_TS03_SO    (0x000)  //
#define DF_TS04_SO    (0x000)  //
#define DF_TS05_SO    (0x000)  //
#define DF_TS06_SO    (0x000)  //
#define DF_TS07_SO    (0x000)  //
#define DF_TS08_SO    (0x000)  //
#define DF_TS09_SO    (0x000)  //
#define DF_TS10_SO    (0x000)  //
#define DF_TS11_SO    (0x000)  //
#define DF_TS12_SO    (0x000)  //
#define DF_TS13_SO    (0x000)  //
#define DF_TS14_SO    (0x000)  //
#define DF_TS15_SO    (0x000)  //
#define DF_TS16_SO    (0x000)  //
#define DF_TS17_SO    (0x000)  //
#define DF_TS18_SO    (0x000)  //
#define DF_TS19_SO    (0x000)  //
#define DF_TS20_SO    (0x000)  //
#define DF_TS21_SO    (0x000)  //
#define DF_TS22_SO    (0x000)  //
#define DF_TS23_SO    (0x000)  //
#define DF_TS24_SO    (0x000)  //
#define DF_TS25_SO    (0x000)  //
#define DF_TS26_SO    (0x000)  //
#define DF_TS27_SO    (0x000)  //
#define DF_TS28_SO    (0x000)  //
#define DF_TS29_SO    (0x000)  //
#define DF_TS30_SO    (0x000)  //
#define DF_TS31_SO    (0x000)  //
#define DF_TS32_SO    (0x000)  //
#define DF_TS33_SO    (0x000)  //
#define DF_TS34_SO    (0x000)  //
#define DF_TS35_SO    (0x000)  //

/* CTSU Measurement Count Setting */
#define DF_TS00_SNUM    (0)  //
#define DF_TS01_SNUM    (0)  //
#define DF_TS02_SNUM    (0)  //
#define DF_TS03_SNUM    (0)  //
#define DF_TS04_SNUM    (0)  //
#define DF_TS05_SNUM    (0)  //
#define DF_TS06_SNUM    (0)  //
#define DF_TS07_SNUM    (0)  //
#define DF_TS08_SNUM    (0)  //
#define DF_TS09_SNUM    (0)  //
#define DF_TS10_SNUM    (0)  //
#define DF_TS11_SNUM    (0)  //
#define DF_TS12_SNUM    (0)  //
#define DF_TS13_SNUM    (0)  //
#define DF_TS14_SNUM    (0)  //
#define DF_TS15_SNUM    (0)  //
#define DF_TS16_SNUM    (0)  //
#define DF_TS17_SNUM    (0)  //
#define DF_TS18_SNUM    (0)  //
#define DF_TS19_SNUM    (0)  //
#define DF_TS20_SNUM    (0)  //
#define DF_TS21_SNUM    (0)  //
#define DF_TS22_SNUM    (0)  //
#define DF_TS23_SNUM    (0)  //
#define DF_TS24_SNUM    (0)  //
#define DF_TS25_SNUM    (0)  //
#define DF_TS26_SNUM    (0)  //
#define DF_TS27_SNUM    (0)  //
#define DF_TS28_SNUM    (0)  //
#define DF_TS29_SNUM    (0)  //
#define DF_TS30_SNUM    (0)  //
#define DF_TS31_SNUM    (0)  //
#define DF_TS32_SNUM    (0)  //
#define DF_TS33_SNUM    (0)  //
#define DF_TS34_SNUM    (0)  //
#define DF_TS35_SNUM    (0)  //

/* CTSU Sensor Offset Register 0 initial value  */
#define DF_TS00_CTSUSO0    ((DF_TS00_SNUM << 10) | DF_TS00_SO)
#define DF_TS01_CTSUSO0    ((DF_TS01_SNUM << 10) | DF_TS01_SO)
#define DF_TS02_CTSUSO0    ((DF_TS02_SNUM << 10) | DF_TS02_SO)
#define DF_TS03_CTSUSO0    ((DF_TS03_SNUM << 10) | DF_TS03_SO)
#define DF_TS04_CTSUSO0    ((DF_TS04_SNUM << 10) | DF_TS04_SO)
#define DF_TS05_CTSUSO0    ((DF_TS05_SNUM << 10) | DF_TS05_SO)
#define DF_TS06_CTSUSO0    ((DF_TS06_SNUM << 10) | DF_TS06_SO)
#define DF_TS07_CTSUSO0    ((DF_TS07_SNUM << 10) | DF_TS07_SO)
#define DF_TS08_CTSUSO0    ((DF_TS08_SNUM << 10) | DF_TS08_SO)
#define DF_TS09_CTSUSO0    ((DF_TS09_SNUM << 10) | DF_TS09_SO)
#define DF_TS10_CTSUSO0    ((DF_TS10_SNUM << 10) | DF_TS10_SO)
#define DF_TS11_CTSUSO0    ((DF_TS11_SNUM << 10) | DF_TS11_SO)
#define DF_TS12_CTSUSO0    ((DF_TS12_SNUM << 10) | DF_TS12_SO)
#define DF_TS13_CTSUSO0    ((DF_TS13_SNUM << 10) | DF_TS13_SO)
#define DF_TS14_CTSUSO0    ((DF_TS14_SNUM << 10) | DF_TS14_SO)
#define DF_TS15_CTSUSO0    ((DF_TS15_SNUM << 10) | DF_TS15_SO)
#define DF_TS16_CTSUSO0    ((DF_TS16_SNUM << 10) | DF_TS16_SO)
#define DF_TS17_CTSUSO0    ((DF_TS17_SNUM << 10) | DF_TS17_SO)
#define DF_TS18_CTSUSO0    ((DF_TS18_SNUM << 10) | DF_TS18_SO)
#define DF_TS19_CTSUSO0    ((DF_TS19_SNUM << 10) | DF_TS19_SO)
#define DF_TS20_CTSUSO0    ((DF_TS20_SNUM << 10) | DF_TS20_SO)
#define DF_TS21_CTSUSO0    ((DF_TS21_SNUM << 10) | DF_TS21_SO)
#define DF_TS22_CTSUSO0    ((DF_TS22_SNUM << 10) | DF_TS22_SO)
#define DF_TS23_CTSUSO0    ((DF_TS23_SNUM << 10) | DF_TS23_SO)
#define DF_TS24_CTSUSO0    ((DF_TS24_SNUM << 10) | DF_TS24_SO)
#define DF_TS25_CTSUSO0    ((DF_TS25_SNUM << 10) | DF_TS25_SO)
#define DF_TS26_CTSUSO0    ((DF_TS26_SNUM << 10) | DF_TS26_SO)
#define DF_TS27_CTSUSO0    ((DF_TS27_SNUM << 10) | DF_TS27_SO)
#define DF_TS28_CTSUSO0    ((DF_TS28_SNUM << 10) | DF_TS28_SO)
#define DF_TS29_CTSUSO0    ((DF_TS29_SNUM << 10) | DF_TS29_SO)
#define DF_TS30_CTSUSO0    ((DF_TS30_SNUM << 10) | DF_TS30_SO)
#define DF_TS31_CTSUSO0    ((DF_TS31_SNUM << 10) | DF_TS31_SO)
#define DF_TS32_CTSUSO0    ((DF_TS32_SNUM << 10) | DF_TS32_SO)
#define DF_TS33_CTSUSO0    ((DF_TS33_SNUM << 10) | DF_TS33_SO)
#define DF_TS34_CTSUSO0    ((DF_TS34_SNUM << 10) | DF_TS34_SO)
#define DF_TS35_CTSUSO0    ((DF_TS35_SNUM << 10) | DF_TS35_SO)

/***** A0916h CTSU Sensor offset register1 ********************************************************************/
/* CTSU Reference ICO Current Adjustment
   b7-b0 -> 0-255 (or 0x00-0xFF)
   These bits adjust the current of the reference ICO. 
   The ICO current adjustment value ranges from 0.075 to 19.2uA. */
#define DF_TS00_RICOA    (0x5F)  //
#define DF_TS01_RICOA    (0x5F)  //
#define DF_TS02_RICOA    (0x5F)  //
#define DF_TS03_RICOA    (0x5F)  //
#define DF_TS04_RICOA    (0x5F)  //
#define DF_TS05_RICOA    (0x5F)  //
#define DF_TS06_RICOA    (0x5F)  //
#define DF_TS07_RICOA    (0x5F)  //
#define DF_TS08_RICOA    (0x5F)  //
#define DF_TS09_RICOA    (0x5F)  //
#define DF_TS10_RICOA    (0x5F)  //
#define DF_TS11_RICOA    (0x5F)  //
#define DF_TS12_RICOA    (0x00)  //
#define DF_TS13_RICOA    (0x00)  //
#define DF_TS14_RICOA    (0x00)  //
#define DF_TS15_RICOA    (0x00)  //
#define DF_TS16_RICOA    (0x00)  //
#define DF_TS17_RICOA    (0x00)  //
#define DF_TS18_RICOA    (0x00)  //
#define DF_TS19_RICOA    (0x00)  //
#define DF_TS20_RICOA    (0x00)  //
#define DF_TS21_RICOA    (0x00)  //
#define DF_TS22_RICOA    (0x00)  //
#define DF_TS23_RICOA    (0x00)  //
#define DF_TS24_RICOA    (0x00)  //
#define DF_TS25_RICOA    (0x00)  //
#define DF_TS26_RICOA    (0x00)  //
#define DF_TS27_RICOA    (0x00)  //
#define DF_TS28_RICOA    (0x00)  //
#define DF_TS29_RICOA    (0x00)  //
#define DF_TS30_RICOA    (0x00)  //
#define DF_TS31_RICOA    (0x00)  //
#define DF_TS32_RICOA    (0x00)  //
#define DF_TS33_RICOA    (0x00)  //
#define DF_TS34_RICOA    (0x00)  //
#define DF_TS35_RICOA    (0x00)  //

/* CTSU Sensor Drive Pulse Division Control
    (Min:0  ---> 2 dividing frequency)
    (Max:31 ---> 64 dividing frequency)            */
#define DF_TS00_SDPA    (31)  //
#define DF_TS01_SDPA    (31)  //
#define DF_TS02_SDPA    (31)  //
#define DF_TS03_SDPA    (31)  //
#define DF_TS04_SDPA    (31)  //
#define DF_TS05_SDPA    (31)  //
#define DF_TS06_SDPA    (31)  //
#define DF_TS07_SDPA    (31)  //
#define DF_TS08_SDPA    (31)  //
#define DF_TS09_SDPA    (31)  //
#define DF_TS10_SDPA    (31)  //
#define DF_TS11_SDPA    (31)  //
#define DF_TS12_SDPA    (15)  //
#define DF_TS13_SDPA    (15)  //
#define DF_TS14_SDPA    (15)  //
#define DF_TS15_SDPA    (15)  //
#define DF_TS16_SDPA    (15)  //
#define DF_TS17_SDPA    (15)  //
#define DF_TS18_SDPA    (15)  //
#define DF_TS19_SDPA    (15)  //
#define DF_TS20_SDPA    (15)  //
#define DF_TS21_SDPA    (15)  //
#define DF_TS22_SDPA    (15)  //
#define DF_TS23_SDPA    (15)  //
#define DF_TS24_SDPA    (15)  //
#define DF_TS25_SDPA    (15)  //
#define DF_TS26_SDPA    (15)  //
#define DF_TS27_SDPA    (15)  //
#define DF_TS28_SDPA    (15)  //
#define DF_TS29_SDPA    (15)  //
#define DF_TS30_SDPA    (15)  //
#define DF_TS31_SDPA    (15)  //
#define DF_TS32_SDPA    (15)  //
#define DF_TS33_SDPA    (15)  //
#define DF_TS34_SDPA    (15)  //
#define DF_TS35_SDPA    (15)  //

/* CTSU ICO Gain Adjustment
   0: 100% gain
   1: 66% gain
   2: 50% gain
   3: 40% gain        */
#define DF_TS00_ICOG    (1)  //
#define DF_TS01_ICOG    (1)  //
#define DF_TS02_ICOG    (1)  //
#define DF_TS03_ICOG    (1)  //
#define DF_TS04_ICOG    (1)  //
#define DF_TS05_ICOG    (1)  //
#define DF_TS06_ICOG    (1)  //
#define DF_TS07_ICOG    (1)  //
#define DF_TS08_ICOG    (1)  //
#define DF_TS09_ICOG    (1)  //
#define DF_TS10_ICOG    (1)  //
#define DF_TS11_ICOG    (1)  //
#define DF_TS12_ICOG    (0)  //
#define DF_TS13_ICOG    (0)  //
#define DF_TS14_ICOG    (0)  //
#define DF_TS15_ICOG    (0)  //
#define DF_TS16_ICOG    (0)  //
#define DF_TS17_ICOG    (0)  //
#define DF_TS18_ICOG    (0)  //
#define DF_TS19_ICOG    (0)  //
#define DF_TS20_ICOG    (0)  //
#define DF_TS21_ICOG    (0)  //
#define DF_TS22_ICOG    (0)  //
#define DF_TS23_ICOG    (0)  //
#define DF_TS24_ICOG    (0)  //
#define DF_TS25_ICOG    (0)  //
#define DF_TS26_ICOG    (0)  //
#define DF_TS27_ICOG    (0)  //
#define DF_TS28_ICOG    (0)  //
#define DF_TS29_ICOG    (0)  //
#define DF_TS30_ICOG    (0)  //
#define DF_TS31_ICOG    (0)  //
#define DF_TS32_ICOG    (0)  //
#define DF_TS33_ICOG    (0)  //
#define DF_TS34_ICOG    (0)  //
#define DF_TS35_ICOG    (0)  //

/* CTSU Sensor Offset Register 1 initial value Do not change */
#define DF_TS00_CTSUSO1    (DF_TS00_ICOG << 13) | (DF_TS00_SDPA << 8) | DF_TS00_RICOA
#define DF_TS01_CTSUSO1    (DF_TS01_ICOG << 13) | (DF_TS01_SDPA << 8) | DF_TS01_RICOA
#define DF_TS02_CTSUSO1    (DF_TS02_ICOG << 13) | (DF_TS02_SDPA << 8) | DF_TS02_RICOA
#define DF_TS03_CTSUSO1    (DF_TS03_ICOG << 13) | (DF_TS03_SDPA << 8) | DF_TS03_RICOA
#define DF_TS04_CTSUSO1    (DF_TS04_ICOG << 13) | (DF_TS04_SDPA << 8) | DF_TS04_RICOA
#define DF_TS05_CTSUSO1    (DF_TS05_ICOG << 13) | (DF_TS05_SDPA << 8) | DF_TS05_RICOA
#define DF_TS06_CTSUSO1    (DF_TS06_ICOG << 13) | (DF_TS06_SDPA << 8) | DF_TS06_RICOA
#define DF_TS07_CTSUSO1    (DF_TS07_ICOG << 13) | (DF_TS07_SDPA << 8) | DF_TS07_RICOA
#define DF_TS08_CTSUSO1    (DF_TS08_ICOG << 13) | (DF_TS08_SDPA << 8) | DF_TS08_RICOA
#define DF_TS09_CTSUSO1    (DF_TS09_ICOG << 13) | (DF_TS09_SDPA << 8) | DF_TS09_RICOA
#define DF_TS10_CTSUSO1    (DF_TS10_ICOG << 13) | (DF_TS10_SDPA << 8) | DF_TS10_RICOA
#define DF_TS11_CTSUSO1    (DF_TS11_ICOG << 13) | (DF_TS11_SDPA << 8) | DF_TS11_RICOA
#define DF_TS12_CTSUSO1    (DF_TS12_ICOG << 13) | (DF_TS12_SDPA << 8) | DF_TS12_RICOA
#define DF_TS13_CTSUSO1    (DF_TS13_ICOG << 13) | (DF_TS13_SDPA << 8) | DF_TS13_RICOA
#define DF_TS14_CTSUSO1    (DF_TS14_ICOG << 13) | (DF_TS14_SDPA << 8) | DF_TS14_RICOA
#define DF_TS15_CTSUSO1    (DF_TS15_ICOG << 13) | (DF_TS15_SDPA << 8) | DF_TS15_RICOA
#define DF_TS16_CTSUSO1    (DF_TS16_ICOG << 13) | (DF_TS16_SDPA << 8) | DF_TS16_RICOA
#define DF_TS17_CTSUSO1    (DF_TS17_ICOG << 13) | (DF_TS17_SDPA << 8) | DF_TS17_RICOA
#define DF_TS18_CTSUSO1    (DF_TS18_ICOG << 13) | (DF_TS18_SDPA << 8) | DF_TS18_RICOA
#define DF_TS19_CTSUSO1    (DF_TS19_ICOG << 13) | (DF_TS19_SDPA << 8) | DF_TS19_RICOA
#define DF_TS20_CTSUSO1    (DF_TS20_ICOG << 13) | (DF_TS20_SDPA << 8) | DF_TS20_RICOA
#define DF_TS21_CTSUSO1    (DF_TS21_ICOG << 13) | (DF_TS21_SDPA << 8) | DF_TS21_RICOA
#define DF_TS22_CTSUSO1    (DF_TS22_ICOG << 13) | (DF_TS22_SDPA << 8) | DF_TS22_RICOA
#define DF_TS23_CTSUSO1    (DF_TS23_ICOG << 13) | (DF_TS23_SDPA << 8) | DF_TS23_RICOA
#define DF_TS24_CTSUSO1    (DF_TS24_ICOG << 13) | (DF_TS24_SDPA << 8) | DF_TS24_RICOA
#define DF_TS25_CTSUSO1    (DF_TS25_ICOG << 13) | (DF_TS25_SDPA << 8) | DF_TS25_RICOA
#define DF_TS26_CTSUSO1    (DF_TS26_ICOG << 13) | (DF_TS26_SDPA << 8) | DF_TS26_RICOA
#define DF_TS27_CTSUSO1    (DF_TS27_ICOG << 13) | (DF_TS27_SDPA << 8) | DF_TS27_RICOA
#define DF_TS28_CTSUSO1    (DF_TS28_ICOG << 13) | (DF_TS28_SDPA << 8) | DF_TS28_RICOA
#define DF_TS29_CTSUSO1    (DF_TS29_ICOG << 13) | (DF_TS29_SDPA << 8) | DF_TS29_RICOA
#define DF_TS30_CTSUSO1    (DF_TS30_ICOG << 13) | (DF_TS30_SDPA << 8) | DF_TS30_RICOA
#define DF_TS31_CTSUSO1    (DF_TS31_ICOG << 13) | (DF_TS31_SDPA << 8) | DF_TS31_RICOA
#define DF_TS32_CTSUSO1    (DF_TS32_ICOG << 13) | (DF_TS32_SDPA << 8) | DF_TS32_RICOA
#define DF_TS33_CTSUSO1    (DF_TS33_ICOG << 13) | (DF_TS33_SDPA << 8) | DF_TS33_RICOA
#define DF_TS34_CTSUSO1    (DF_TS34_ICOG << 13) | (DF_TS34_SDPA << 8) | DF_TS34_RICOA
#define DF_TS35_CTSUSO1    (DF_TS35_ICOG << 13) | (DF_TS35_SDPA << 8) | DF_TS35_RICOA

/* Measurement Mode */
#define MD_SELF_SINGLE      (0)
#define MD_SELF_MULTI       (1)
#define MD_MUTUAL_SIMPLE    (2)
#define MD_MUTUAL_FULL      (3)

/* DTC for CTSU */
#define CTSU_DTC_WR_CNT     (0x0303)               /* DTC Write count / 3word                          */
#define CTSU_DTC_RD_CNT     (0x0202)               /* DTC Read count / 2word                           */

/* DTC Mode Register A (MRA) */
/* Transfer Source Address Addressing Mode */
#define DTC_SM_FIXED        (0)                    /* Address in the SAR register is fixed.            */
#define DTC_SM_FIXEDb       (1)                    /* Address in the SAR register is fixed.            */
#define DTC_SM_INC          (2)                    /* SAR value is incremented after data transfer.    */
#define DTC_SM_DEC          (3)                    /* SAR value is decremented after data transfer.    */
/* DTC Data Transfer Size */
#define DTC_SZ_BYTE         (0)                    /* Byte (8-bit) transfer                            */
#define DTC_SZ_WORD         (1)                    /* Word (16-bit) transfer                           */
#define DTC_SZ_LONG         (2)                    /* Longword (32-bit) transfer                       */
/* DTC Transfer Mode Select */
#define DTC_MD_NORMAL       (0)                    /* Normal transfer mode                             */
#define DTC_MD_REPEAT       (1)                    /* Repeat transfer mode                             */
#define DTC_MD_BLOCK        (2)                    /* Block transfer mode                              */

/* DTC Mode Register B (MRB) */
/* Transfer Destination Address Addressing Mode */
#define DTC_DM_FIXED        (0)                    /* Address in the DAR register is fixed.            */
#define DTC_DM_FIXEDb       (1)                    /* Address in the DAR register is fixed.            */
#define DTC_DM_INC          (2)                    /* DAR value is incremented after data transfer.    */
#define DTC_DM_DEC          (3)                    /* DAR value is decremented after data transfer.    */
/* DTC Transfer Mode Select */
#define DTC_DTS_DAR         (0)                    /* Transfer destination side is repeat area or block area. */
#define DTC_DTS_SAR         (1)                    /* Transfer source side is repeat area or block area.      */
/* DTC Interrupt Select */
#define DTC_DISEL_COMPLETED    (0)                 /* An interrupt request to the CPU is generated 
                                                    when specified data transfer is completed.       */
#define DTC_DISEL_EACH         (1)                 /* An interrupt request to the CPU is generated each time
                                                    DTC data transfer is performed.                  */
/* DTC Chain Transfer Select */
#define DTC_CHNS_CONTINUE      (0)                 /* Chain transfer is performed continuously. */
#define DTC_CHNS_CONTER        (1)                 /* Chain transfer is performed only when the transfer 
                                                    counter is changed from 1 to 0 or 1 to CRAH.     */
/* DTC Chain Transfer Enable */
#define DTC_CHNE_DISABLE       (0)                 /* Chain transfer is disabled.                      */
#define DTC_CHNE_ENABLE        (1)                 /* Chain transfer is enabled.                       */

/* DTC Module Start Register (DTCST) */
/* DTC Module Start */
#define DTC_DTCST_STOP         (0)                 /* DTC module stop                                  */
#define DTC_DTCST_START        (1)                 /* DTC module start                                 */

/* DTC Control Register (DTCCR) */
/* DTC Transfer Information Read Skip Enable */
#define DTC_RRS_NOTSKIP        (0)                 /* Transfer information read is not skipped.        */
#define DTC_RRS_SKIP           (1)                 /* Transfer information read is skipped when vector numbers match. */

/* DTC Address Mode Register (DTCADMOD) */
/* Short-Address Mode */
#define DTC_SHORT_FULL         (0)                 /* Full-address mode                                */
#define DTC_SHORT_SHORT        (1)                 /* Short-address mode                               */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/


/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
#define CTSU_DRIVER_SELF      (0)
#define CTSU_DRIVER_MUTUAL    (1)

#define PHYSICAL_TS_ERR       (0)

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
void CTSUSetMeasurementOperation( uint8_t mode, uint8_t trigger);
void CTSUSetTransmitPinControl( uint8_t mode );
void CTSUSetControlBlockInitial( uint8_t mode );
void CTSUSetPowerSupplyEnable( uint8_t mode );
void CTSUSetPowerSupplyOnly( uint8_t mode );
void CTSUSetLpfPinControl( uint8_t mode );
void CTSUSetLpfChargingControl( uint8_t mode );
void CTSUSetLowPowControl( uint8_t mode );
void CTSUSetIcoCurrentAttenuator( uint8_t mode );
void CTSUSetCountSource( uint8_t mode );
void CTSUSetMeasurementMode( uint8_t mode );
void CTSUSetSensorDrivePulseSpectrumDiffusion( uint8_t cycle, uint8_t mode, uint8_t edge );
void CTSUSetSensorStabilizationWaitTime( uint8_t time );
uint8_t CTSUSetMeasurementChannel( uint8_t ch );
uint8_t CTSUGetTransmitChannel( void );
void CTSUSetChannelEnableControl( uint16_t ch );
void CTSUSetChannelTransmitReceiveControl( uint16_t ch );
void CTSUSetDiffusionClockModeSelect( uint8_t mode, uint8_t clock );
uint8_t CTSUGetMeasurementStatusCounter( void );
uint8_t CTSUGetDataTransferStatus( void );
uint8_t CTSUGetCounterOverflow( void );
uint8_t CTSUGetMutualCapacitanceMeasurementStatus( void );
uint8_t CTSUGetTscapVoltageError( void );

void CTSUWriteCTSUCR0( uint8_t data );
uint8_t CTSUReadCTSUCR0( void );
void CTSUWriteCTSUCR1( uint8_t data );
uint8_t CTSUReadCTSUCR1( void );
void CTSUWriteCTSUSDPRS( uint8_t data );
uint8_t CTSUReadCTSUSDPRS( void );
void CTSUWriteCTSUSST( uint8_t data );
uint8_t CTSUReadCTSUSST( void );
void CTSUWriteCTSUMCH0( uint8_t data );
uint8_t CTSUReadCTSUMCH0( void );
void CTSUWriteCTSUMCH1( uint8_t data );
uint8_t CTSUReadCTSUMCH1( void );
void CTSUWriteCTSUCHAC0( uint8_t data );
uint8_t CTSUReadCTSUCHAC0( void );
void CTSUWriteCTSUCHAC1( uint8_t data );
uint8_t CTSUReadCTSUCHAC1( void );
void CTSUWriteCTSUCHTRC0( uint8_t data );
uint8_t CTSUReadCTSUCHTRC0( void );
void CTSUWriteCTSUCHTRC1( uint8_t data );
uint8_t CTSUReadCTSUCHTRC1( void );
void CTSUWriteCTSUDCLKC( uint8_t data );
uint8_t CTSUReadCTSUDCLKC( void );
void CTSUWriteCTSUST( uint8_t data );
uint8_t CTSUReadCTSUST( void );
void CTSUWriteCTSUERRS( uint16_t data );
uint16_t CTSUReadCTSUERRS( void );

/* Library */
#include "r_dtc_table.h"
void CTSUSetDtcStart( DTC_DATA_T *dtc_ctsu_wr, DTC_DATA_T *dtc_ctsu_rd, uint16_t *g_write, ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t mode );
void CTSUSetDtcInitial( DTC_DATA_T *dtc_ctsu_wr, DTC_DATA_T *dtc_ctsu_rd, uint16_t *g_write, ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t mode );
void CTSUSetSpectrumDiffusionControl( uint16_t *g_write, uint8_t *g_index, uint8_t cycle, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetSensorOffsetAdjustment( uint16_t *g_write, uint8_t *g_index, uint16_t offset, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetMeasurementCount( uint16_t *g_write, uint8_t *g_index, uint8_t count, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetReferenceICOCurrentAdjustment( uint16_t *g_write, uint8_t *g_index, uint8_t count, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetSensorDrivePulseDivisionControl( uint16_t *g_write, uint8_t *g_index, uint8_t division, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUSetICOGainAdjustment( uint16_t *g_write, uint8_t *g_index, uint8_t gain, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUGetSensorCounter( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index,uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUGetReferenceCounter( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSSC( uint16_t *g_write, uint8_t *g_index, uint16_t data, uint8_t ts ,uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSSC( uint16_t *g_write, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSO0( uint16_t *g_write, uint8_t *g_index, uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSO0( uint16_t *g_write, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSO1( uint16_t *g_write, uint8_t *g_index,uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSO1( uint16_t *g_write, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSUSC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index,uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSUSC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts );
void CTSUWriteCTSURC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint16_t data, uint8_t ts, uint8_t mode, uint8_t max_ts );
uint16_t CTSUReadCTSURC( ctsu_in_data_t *g_cntr, ctsu_in_data_t_mu *g_cntr_mu, uint8_t *g_index, uint8_t ts, uint8_t mode, uint8_t max_ts);


#endif //] __R_TOUCH_PHYSICAL_DRIVER_H__
