/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_key_control.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

#ifndef __R_CTSU_KEY_CONTROL_H__    //[
#define __R_CTSU_KEY_CONTROL_H__

/***********************************************************************************************************************
Includes
***********************************************************************************************************************/
#include "r_ctsu_common_control.h"
#include "r_ctsu_parameter_common.h"

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef __R_CTSU_KEY_CONTROL_C__
    #define CTSU_KEY_EXTERN
#else
    #define CTSU_KEY_EXTERN    extern
#endif

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                  Self parameter definition                 ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#ifndef MUTUAL_FUNC_USE

/* Key function used */
#define DF_TS00_KEY_USE    (0)
#define DF_TS01_KEY_USE    (0)
#define DF_TS02_KEY_USE    (0)
#define DF_TS03_KEY_USE    (0)
#define DF_TS04_KEY_USE    (0)
#define DF_TS05_KEY_USE    (0)
#define DF_TS06_KEY_USE    (0)
#define DF_TS07_KEY_USE    (0)
#define DF_TS08_KEY_USE    (0)
#define DF_TS09_KEY_USE    (1)
#define DF_TS10_KEY_USE    (1)
#define DF_TS11_KEY_USE    (1)
#define DF_TS12_KEY_USE    (0)
#define DF_TS13_KEY_USE    (0)
#define DF_TS14_KEY_USE    (0)
#define DF_TS15_KEY_USE    (0)
#define DF_TS16_KEY_USE    (0)
#define DF_TS17_KEY_USE    (0)
#define DF_TS18_KEY_USE    (0)
#define DF_TS19_KEY_USE    (0)
#define DF_TS20_KEY_USE    (0)
#define DF_TS21_KEY_USE    (0)
#define DF_TS22_KEY_USE    (0)
#define DF_TS23_KEY_USE    (0)
#define DF_TS24_KEY_USE    (0)
#define DF_TS25_KEY_USE    (0)
#define DF_TS26_KEY_USE    (0)
#define DF_TS27_KEY_USE    (0)
#define DF_TS28_KEY_USE    (0)
#define DF_TS29_KEY_USE    (0)
#define DF_TS30_KEY_USE    (0)
#define DF_TS31_KEY_USE    (0)
#define DF_TS32_KEY_USE    (0)
#define DF_TS33_KEY_USE    (0)
#define DF_TS34_KEY_USE    (0)
#define DF_TS35_KEY_USE    (0)

#define KEY_USE_INFO_LOW    ((DF_TS00_KEY_USE      ) + (DF_TS01_KEY_USE <<  1) + (DF_TS02_KEY_USE <<  2) + \
                             (DF_TS03_KEY_USE <<  3) + (DF_TS04_KEY_USE <<  4) + (DF_TS05_KEY_USE <<  5) + \
                             (DF_TS06_KEY_USE <<  6) + (DF_TS07_KEY_USE <<  7) + (DF_TS08_KEY_USE <<  8) + \
                             (DF_TS09_KEY_USE <<  9) + (DF_TS10_KEY_USE << 10) + (DF_TS11_KEY_USE << 11) + \
                             (DF_TS12_KEY_USE << 12) + (DF_TS13_KEY_USE << 13) + (DF_TS14_KEY_USE << 14) + \
                             (DF_TS15_KEY_USE << 15))

#define KEY_USE_INFO_MID    ((DF_TS16_KEY_USE      ) + (DF_TS17_KEY_USE <<  1) + (DF_TS18_KEY_USE <<  2) + \
                             (DF_TS19_KEY_USE <<  3) + (DF_TS20_KEY_USE <<  4) + (DF_TS21_KEY_USE <<  5) + \
                             (DF_TS22_KEY_USE <<  6) + (DF_TS23_KEY_USE <<  7) + (DF_TS24_KEY_USE <<  8) + \
                             (DF_TS25_KEY_USE <<  9) + (DF_TS26_KEY_USE << 10) + (DF_TS27_KEY_USE << 11) + \
                             (DF_TS28_KEY_USE << 12) + (DF_TS29_KEY_USE << 13) + (DF_TS30_KEY_USE << 14) + \
                             (DF_TS31_KEY_USE << 15))

#define KEY_USE_INFO_HIGH   ((DF_TS32_KEY_USE      ) + (DF_TS33_KEY_USE <<  1) + (DF_TS34_KEY_USE <<  2) + \
                             (DF_TS35_KEY_USE << 3))

#if( KEY_USE_INFO_HIGH > 0 )
    #define MAX_KEY_ID        (3)
#elif( KEY_USE_INFO_MID > 0 )
    #define MAX_KEY_ID        (2)
#else
    #define MAX_KEY_ID        (1)
#endif

#define KEY_NUM    (DF_TS00_KEY_USE + DF_TS01_KEY_USE + DF_TS02_KEY_USE + DF_TS03_KEY_USE + \
                    DF_TS04_KEY_USE + DF_TS05_KEY_USE + DF_TS06_KEY_USE + DF_TS07_KEY_USE + \
                    DF_TS08_KEY_USE + DF_TS09_KEY_USE + DF_TS10_KEY_USE + DF_TS11_KEY_USE + \
                    DF_TS12_KEY_USE + DF_TS13_KEY_USE + DF_TS14_KEY_USE + DF_TS15_KEY_USE + \
                    DF_TS16_KEY_USE + DF_TS17_KEY_USE + DF_TS18_KEY_USE + DF_TS19_KEY_USE + \
                    DF_TS20_KEY_USE + DF_TS21_KEY_USE + DF_TS22_KEY_USE + DF_TS23_KEY_USE + \
                    DF_TS24_KEY_USE + DF_TS25_KEY_USE + DF_TS26_KEY_USE + DF_TS27_KEY_USE + \
                    DF_TS28_KEY_USE + DF_TS29_KEY_USE + DF_TS30_KEY_USE + DF_TS31_KEY_USE + \
                    DF_TS32_KEY_USE + DF_TS33_KEY_USE + DF_TS34_KEY_USE + DF_TS35_KEY_USE)

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                Mutual parameter definition                 ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#else

/* Key function used */
#if DF_TS00_FUNCTION == 1
    #define DF_TS00_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS00_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS00_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS00_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS00_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS00_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS00_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS00_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS01_FUNCTION == 1
    #define DF_TS01_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS01_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS01_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS01_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS01_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS01_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS01_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS01_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS02_FUNCTION == 1
    #define DF_TS02_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS02_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS02_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS02_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS02_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS02_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS02_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS02_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS03_FUNCTION == 1
    #define DF_TS03_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS03_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS03_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS03_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS03_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS03_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS03_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS03_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS04_FUNCTION == 1
    #define DF_TS04_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS04_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS04_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS04_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS04_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS04_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS04_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS04_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS05_FUNCTION == 1
    #define DF_TS05_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS05_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS05_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS05_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS05_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS05_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS05_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS05_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS06_FUNCTION == 1
    #define DF_TS06_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS06_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS06_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS06_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS06_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS06_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS06_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS06_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS07_FUNCTION == 1
    #define DF_TS07_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS07_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS07_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS07_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS07_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS07_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS07_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS07_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS08_FUNCTION == 1
    #define DF_TS08_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS08_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS08_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS08_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS08_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS08_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS08_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS08_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS09_FUNCTION == 1
    #define DF_TS09_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS09_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS09_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS09_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS09_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS09_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS09_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS09_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS10_FUNCTION == 1
    #define DF_TS10_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS10_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS10_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS10_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS10_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS10_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS10_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS10_07_KEY_USE        (1)
    #endif
#endif
#if DF_TS11_FUNCTION == 1
    #define DF_TS11_00_KEY_USE        (1)
    #if ( RECEIVE_NUM > 1 )
        #define DF_TS11_01_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 2 )
        #define DF_TS11_02_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 3 )
        #define DF_TS11_03_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 4 )
        #define DF_TS11_04_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 5 )
        #define DF_TS11_05_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 6 )
        #define DF_TS11_06_KEY_USE        (1)
    #endif
    #if ( RECEIVE_NUM > 7 )
        #define DF_TS11_07_KEY_USE        (1)
    #endif
#endif

#if( MEASURE_NUM > 32 )
    #define MAX_KEY_ID        (3)
#elif( MEASURE_NUM > 16 )
    #define MAX_KEY_ID        (2)
#else
    #define MAX_KEY_ID        (1)
#endif

#endif

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                Common parameter definition                 ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#define CALIB_TIME        (4)

#define DRIFT_OK          (0)
#define DRIFT_ERROR       (1)
#define DRIFT_OFF         (2)

#define KEY_FUNC_OK       (0)
#define KEY_FUNC_NG       (1)

#define KEY_LOW           (16)
#define KEY_MID           (32)
#define KEY_HIGH          (36)

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef union
{
    struct
    {
        uint16_t    drift       :1;        /* Drift correction                                                        */
        uint16_t    msa         :1;        /* Maximum successive on counter                                           */
        uint16_t    acd0        :1;        /* Accumulated counter                                                     */
        uint16_t    acd1        :1;        /* Accumulated coutner                                                     */
        uint16_t    mtc         :1;        /* Multi touch canceller                                                   */
        uint16_t    reserved    :11;
    } function;
    uint16_t    value;
} touch_sensor_function_t;

/***********************************************************************************************************************
Global variables
***********************************************************************************************************************/
CTSU_KEY_EXTERN touch_sensor_function_t    g_sensor_function;

#ifdef KEY_USE
    CTSU_KEY_EXTERN uint8_t     g_calib_data_num;                     /* Calibration key number                       */
    CTSU_KEY_EXTERN uint8_t     g_calib_time;                         /* Calibration data number                      */
    CTSU_KEY_EXTERN uint8_t     g_data_tim;                           /* Calibration data storage times               */
    CTSU_KEY_EXTERN uint8_t     g_touch_cmp_val;                      /* Continuation on number of times              */
    CTSU_KEY_EXTERN uint8_t     g_non_touch_cmp_val;                  /* Continuation off number of times             */
    CTSU_KEY_EXTERN uint16_t    g_msa;                                /* The continuation on reset number of times    */
    CTSU_KEY_EXTERN uint8_t     mtc_start_ch;                         /* Multi touch cancelling start channel         */
    CTSU_KEY_EXTERN uint8_t     mtc_end_ch;                           /* Multi touch cancelling end channel           */
    //CTSU_KEY_EXTERN uint8_t     mtc_onoff;                          /* Multi touch cancel function ON/OFF           */
    CTSU_KEY_EXTERN uint32_t    Athr;                                 /* Multi cancelling CH and Asum> ATHR           */
    CTSU_KEY_EXTERN uint32_t    asum;                                 /* Multi cancelling CH and Asum> ATHR           */
    //CTSU_KEY_EXTERN uint8_t     dc_onoff;                           /* Drift correction function ON/OFF             */
    CTSU_KEY_EXTERN uint16_t    g_dci;                                /* Drift revision count                         */
    CTSU_KEY_EXTERN uint16_t    used_key_func[MAX_KEY_ID];

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                    Self global variables                   ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#ifndef MUTUAL_FUNC_USE
    CTSU_KEY_EXTERN uint16_t    g_calib[ KEY_NUM ][ CALIB_TIME ];     /* Calibration data storage buffer              */
    CTSU_KEY_EXTERN uint16_t    g_nref[KEY_NUM];                      /* Reference value storage buffer               */
    CTSU_KEY_EXTERN uint16_t    g_dcount[KEY_NUM];                    /* g_dcount[] = g_nref[] - g_scount[]           */
    CTSU_KEY_EXTERN uint16_t    g_cthr[KEY_NUM];                      /* Touch judgment threshold storage buffer      */
    CTSU_KEY_EXTERN uint16_t    g_nthr[KEY_NUM];                      /* User setting touch judgment threshold storage buffer */
    CTSU_KEY_EXTERN uint16_t    g_nhys[KEY_NUM];                      /* Hysteresis value storage buffer              */
    CTSU_KEY_EXTERN uint16_t    g_touch_cnt[KEY_NUM];                 /* Touch judgment counter                       */
    CTSU_KEY_EXTERN uint16_t    g_non_touch_cnt[KEY_NUM];             /* Non touch judgment counter                   */
    CTSU_KEY_EXTERN uint16_t    g_virtual_touch_info[MAX_KEY_ID];     /* Virtual touch/non touch Information          */
    CTSU_KEY_EXTERN uint16_t    g_real_touch_info[MAX_KEY_ID];        /* Real touch/non touch information             */
    CTSU_KEY_EXTERN uint16_t    g_touch_result[MAX_KEY_ID];           /* Touch/non touch result Information              */
    CTSU_KEY_EXTERN uint16_t    BDATA[MAX_KEY_ID];
    CTSU_KEY_EXTERN uint16_t    g_drift_permission[MAX_KEY_ID];       /* Drift correction permission                  */
    CTSU_KEY_EXTERN uint32_t    g_dc_ref[KEY_NUM];                    /* Drift correction average calculation         */
    CTSU_KEY_EXTERN uint16_t    g_dc_cnt[KEY_NUM];                    /* Drift correction counter                     */

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                   Mutual global variables                  ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#else
    CTSU_KEY_EXTERN uint16_t    g_calib[ MEASURE_NUM ][ CALIB_TIME ];           /* Calibration data storage buffer          */
    CTSU_KEY_EXTERN uint16_t    g_nref[SEND_NUM][RECEIVE_NUM];                  /* Reference value storage buffer           */
    CTSU_KEY_EXTERN uint16_t    g_dcount[SEND_NUM][RECEIVE_NUM];                /* g_dcount[][] = g_nref[][] - g_scount[][] */
    CTSU_KEY_EXTERN uint16_t    g_cthr[SEND_NUM][RECEIVE_NUM];                  /* Touch judgment threshold storage buffer  */
    CTSU_KEY_EXTERN uint16_t    g_nthr[SEND_NUM][RECEIVE_NUM];                  /* User setting touch judgment threshold storage buffer */
    CTSU_KEY_EXTERN uint16_t    g_nhys[SEND_NUM][RECEIVE_NUM];                  /* Hysteresis value storage buffer          */
    CTSU_KEY_EXTERN uint16_t    g_touch_cnt[SEND_NUM][RECEIVE_NUM];             /* Touch judgment counter                   */
    CTSU_KEY_EXTERN uint16_t    g_non_touch_cnt[SEND_NUM][RECEIVE_NUM];         /* Non touch judgment counter               */
    CTSU_KEY_EXTERN uint16_t    g_virtual_touch_info[SEND_NUM][RECEIVE_NUM];    /* Virtual touch/non touch Information      */
    CTSU_KEY_EXTERN uint16_t    g_real_touch_info[SEND_NUM][RECEIVE_NUM];       /* Real touch/non touch information         */
    CTSU_KEY_EXTERN uint16_t    g_touch_result[SEND_NUM][RECEIVE_NUM];          /* Touch/non touch result Information       */
    CTSU_KEY_EXTERN uint16_t    BDATA[SEND_NUM][RECEIVE_NUM];
    CTSU_KEY_EXTERN uint16_t    g_drift_permission[SEND_NUM][RECEIVE_NUM];      /* Drift correction permission              */
    CTSU_KEY_EXTERN uint32_t    g_dc_ref[SEND_NUM][RECEIVE_NUM];                /* Drift correction average calculation     */
    CTSU_KEY_EXTERN uint16_t    g_dc_cnt[SEND_NUM][RECEIVE_NUM];                /* Drift correction counter                 */
#endif //] MUTUAL_FUNC_USE

#endif // KEY_USE

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/
#ifndef MUTUAL_FUNC_USE
    void KeyProcess( void );
    void KeyDecode( uint16_t key_value, uint8_t ts_num );
    void CTSUMakeCthr( uint16_t key_val );
    void CTSUMultiTouchCancel( void );
    void CTSUOnOffJudgement( uint16_t key_val, uint8_t key_id, uint8_t offset );
    uint8_t CTSUDriftCorrection( uint16_t key_val_sub, uint8_t key_id, uint8_t offset );
    uint8_t MultiCancelDriftCheck( uint8_t ts_num );
    void KeyCalibrationProcess( void );
    void KeyCalibration( uint8_t loop_ts );
    uint8_t KeyFunctionCheck( uint8_t loop );
#else
    void KeyProcess( void );
    void KeyDecode( uint16_t key_value, uint8_t column, uint8_t row );
    void CTSUMakeCthr( uint16_t key_val, uint8_t column_sub, uint8_t row_sub );
    void CTSUMultiTouchCancel( void );
    void CTSUOnOffJudgement( uint16_t key_val, uint8_t column_sub, uint8_t row_sub );
    uint8_t CTSUDriftCorrection( uint16_t key_val, uint8_t column_sub, uint8_t row_sub );
    uint8_t MultiCancelDriftCheck( uint8_t multi_ch );
    void KeyCalibration( void );
    //uint8_t KeyFunctionCheck( uint8_t loop );
#endif //] MUTUAL_FUNC_USE

#endif //] __R_TOUCH_CONTROL_H__
