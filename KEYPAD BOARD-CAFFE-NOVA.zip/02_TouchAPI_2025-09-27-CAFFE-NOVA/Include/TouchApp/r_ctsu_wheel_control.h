/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_wheel_control.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#include "r_ctsu_parameter_common.h"

#ifndef __R_CTSU_WHEEL_CONTROL_H__    //[
#define __R_CTSU_WHEEL_CONTROL_H__
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef __R_CTSU_WHEEL_CONTROL_C__
    #define CTSU_WHEEL_EXTERN
#else
    #define CTSU_WHEEL_EXTERN    extern
#endif

/* Wheel common values */
#define DF_WHEEL_NUMBER        (1)            /* Nummber of wheel                          */
#define DF_WHEEL_SENSOR_MAX    (8)            /* Number of wheel composition maximum TS    */
#define DF_WHEEL_NO_SENSOR     (255)          /* Not used sensor                           */

/* Wheel0 Configuration */
#define DF_WHEEL0_TS00    (3)
#define DF_WHEEL0_TS01    (0)
#define DF_WHEEL0_TS02    (1)
#define DF_WHEEL0_TS03    (2)
#define DF_WHEEL0_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL0_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL0_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL0_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL0_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL0_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL0_SENSOR_NUMBER    (4)            /* Number of touch sensor                   */
#define DF_WHEEL0_THRESHOLD        (450)         /* ON/OFF Judge THR                         */
#define DF_WHEEL0_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel1 Configuration */
#define DF_WHEEL1_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL1_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL1_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL1_THRESHOLD        (800)         /* ON/OFF Judge THR                         */
#define DF_WHEEL1_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel2 Configuration */
#define DF_WHEEL2_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL2_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL2_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL2_THRESHOLD        (800)         /* ON/OFF Judge THR                         */
#define DF_WHEEL2_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel3 Configuration */
#define DF_WHEEL3_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL3_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL3_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL3_THRESHOLD        (800)          /* ON/OFF Judge THR                         */
#define DF_WHEEL3_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel4 Configuration */
#define DF_WHEEL4_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL4_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL4_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL4_THRESHOLD        (800)          /* ON/OFF Judge THR                         */
#define DF_WHEEL4_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel5 Configuration */
#define DF_WHEEL5_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL5_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL5_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL5_THRESHOLD        (800)          /* ON/OFF Judge THR                         */
#define DF_WHEEL5_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel6 Configuration */
#define DF_WHEEL6_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL6_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL6_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL6_THRESHOLD        (800)          /* ON/OFF Judge THR                         */
#define DF_WHEEL6_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/* Wheel7 Configuration */
#define DF_WHEEL7_TS00    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS01    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS02    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS03    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS04    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS05    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS06    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS07    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS08    DF_WHEEL_NO_SENSOR
#define DF_WHEEL7_TS09    DF_WHEEL_NO_SENSOR

#define DF_WHEEL7_SENSOR_NUMBER    (0)            /* Number of touch sensor                   */
#define DF_WHEEL7_THRESHOLD        (800)          /* ON/OFF Judge THR                         */
#define DF_WHEEL7_RESOLUTION       (1)            /* Wheel Max resolution in the operation    */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

#ifdef WHEEL_USE //[
/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/
CTSU_WHEEL_EXTERN slider_wheel_info_t    g_wheelInfo[DF_WHEEL_NUMBER];
CTSU_WHEEL_EXTERN uint16_t               g_wheel_data[DF_WHEEL_SENSOR_MAX];
CTSU_WHEEL_EXTERN uint16_t               g_wheel_dsum[DF_WHEEL_NUMBER];
CTSU_WHEEL_EXTERN volatile uint16_t      g_wheel_pos[DF_WHEEL_NUMBER];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files);
***********************************************************************************************************************/
void WheelProcess( void );
uint16_t WheelDecode( uint8_t wheel_id );
void WheelCalibrationProcess( void );

#endif //] WHEEL_USE
#endif //] __R_CTSU_WHEEL_CONTROL_H__

