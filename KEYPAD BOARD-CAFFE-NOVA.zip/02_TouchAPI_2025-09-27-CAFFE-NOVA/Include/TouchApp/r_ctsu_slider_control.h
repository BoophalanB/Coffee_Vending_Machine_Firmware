/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_slider_control.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/
#include "r_ctsu_parameter_common.h"

#ifndef __R_CTSU_SLIDER_CONTROL_H__    //[
#define __R_CTSU_SLIDER_CONTROL_H__
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef __R_CTSU_SLIDER_CONTROL_C__
    #define CTSU_SLIDER_EXTERN
#else
    #define CTSU_SLIDER_EXTERN    extern
#endif

/* Slider common values */
#define DF_SLIDER_NUMBER        (1)              /* Nummber of slider                          */
#define DF_SLIDER_SENSOR_MAX    (10)             /* Number of slider composition maximum TS    */
#define DF_SLIDER_NO_SENSOR     (255)            /* Not used sensor                            */

/* Slider0 Configuration */
#define DF_SLIDER0_TS00    (8)
#define DF_SLIDER0_TS01    (7)
#define DF_SLIDER0_TS02    (6)
#define DF_SLIDER0_TS03    (5)
#define DF_SLIDER0_TS04    (4)
#define DF_SLIDER0_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER0_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER0_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER0_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER0_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER0_SENSOR_NUMBER    (5)            /* Number of touch sensor                    */
#define DF_SLIDER0_THRESHOLD        (450)          /* ON/OFF Judge THR                          */
#define DF_SLIDER0_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider1 Configuration */
#define DF_SLIDER1_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER1_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER1_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER1_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER1_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider2 Configuration */
#define DF_SLIDER2_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER2_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER2_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER2_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER2_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider3 Configuration */
#define DF_SLIDER3_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER3_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER3_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER3_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER3_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider4 Configuration */
#define DF_SLIDER4_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER4_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER4_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER4_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER4_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider5 Configuration */
#define DF_SLIDER5_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER5_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER5_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER5_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER5_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider6 Configuration */
#define DF_SLIDER6_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER6_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER6_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER6_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER6_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/* Slider7 Configuration */
#define DF_SLIDER7_TS00    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS01    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS02    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS03    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS04    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS05    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS06    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS07    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS08    DF_SLIDER_NO_SENSOR
#define DF_SLIDER7_TS09    DF_SLIDER_NO_SENSOR

#define DF_SLIDER7_SENSOR_NUMBER    (0)            /* Number of touch sensor                    */
#define DF_SLIDER7_THRESHOLD        (1000)         /* ON/OFF Judge THR                          */
#define DF_SLIDER7_RESOLUTION       (1)            /* Slider Max resolution in the operation    */

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/

#ifdef SLIDER_USE //[
/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/
CTSU_SLIDER_EXTERN slider_wheel_info_t    g_sliderInfo[DF_SLIDER_NUMBER];
CTSU_SLIDER_EXTERN uint16_t               g_slider_data[DF_SLIDER_SENSOR_MAX];
CTSU_SLIDER_EXTERN uint16_t               g_slider_dsum[DF_SLIDER_NUMBER];
CTSU_SLIDER_EXTERN volatile uint16_t      g_slider_pos[DF_SLIDER_NUMBER];

/***********************************************************************************************************************
Exported global functions (to be accessed by other files);
***********************************************************************************************************************/
void SliderProcess( void );
uint16_t SliderDecode( uint8_t slider_id );
void SliderCalibrationProcess( void );

#endif //] SLIDER_USE
#endif //] __R_CTSU_SLIDER_CONTROL_H__
