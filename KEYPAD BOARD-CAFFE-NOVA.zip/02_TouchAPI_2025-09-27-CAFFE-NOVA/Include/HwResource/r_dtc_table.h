/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/
#include "r_cg_macrodriver.h"
/***********************************************************************************************************************
* File Name    : r_dtc_table.h
* Version      : -
* Device(s)    : R5F51138AxFP
* Tool-Chain   : CCRX
* Description  : This file DTC data definition.
* Creation Date: 2013/11/18
***********************************************************************************************************************/
#ifndef __R_DTC_TABLE_H__
#define __R_DTC_TABLE_H__

/***********************************************************************************************************************
Macro definitions (Register bit)
***********************************************************************************************************************/
#ifdef __R_DTC_TABLE_C__
    #define DTC_TABLE_EXTERN
#else
    #define DTC_TABLE_EXTERN        extern
#endif

/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
#pragma bit_order left
#pragma unpack

/* DTC Vector table */ 
typedef struct
{
    uint16_t WORD;
    union
    {
        uint8_t BYTE;
        struct
        {
            uint8_t    CHNE     :1;
            uint8_t    CHNS     :1;
            uint8_t    DISEL    :1;
            uint8_t    DTS      :1;
            uint8_t    DM       :2;
            uint8_t             :2;
        }
        BIT;
    }
    MRB;                        /* Mode Register B */
    union
    {
        uint8_t BYTE;
        struct
        {
            uint8_t    MD    :2;
            uint8_t    SZ    :2;
            uint8_t    SM    :2;
            uint8_t          :2;
        }
        BIT;
    }
    MRA;                        /* Mode Register A */
    uint32_t    SAR;            /* Source Address */
    uint32_t    DAR;            /* Destination Address */
    uint16_t    CRB;            /* Count Register A */
    uint16_t    CRA;            /* Count Register B */
} DTC_DATA_T;

/***********************************************************************************************************************
Global functions
***********************************************************************************************************************/

#pragma bit_order
#pragma packoption
#endif