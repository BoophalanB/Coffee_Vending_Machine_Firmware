/***********************************************************************************************************************
* DISCLAIMER
* This software is supplied by Renesas Electronics Corporation and is only
* intended for use with Renesas products. No other uses are authorized. This
* software is owned by Renesas Electronics Corporation and is protected under
* all applicable laws, including copyright laws.
* THIS SOFTWARE IS PROVIDED "AS IS" AND RENESAS MAKES NO WARRANTIES REGARDING
* THIS SOFTWARE, WHETHER EXPRESS, IMPLIED OR STATUTORY, INCLUDING BUT NOT
* LIMITED TO WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE
* AND NON-INFRINGEMENT. ALL SUCH WARRANTIES ARE EXPRESSLY DISCLAIMED.
* TO THE MAXIMUM EXTENT PERMITTED NOT PROHIBITED BY LAW, NEITHER RENESAS
* ELECTRONICS CORPORATION NOR ANY OF ITS AFFILIATED COMPANIES SHALL BE LIABLE
* FOR ANY DIRECT, INDIRECT, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES FOR
* ANY REASON RELATED TO THIS SOFTWARE, EVEN IF RENESAS OR ITS AFFILIATES HAVE
* BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES.
* Renesas reserves the right, without notice, to make changes to this software
* and to discontinue the availability of this software. By using this software,
* you agree to the additional terms and conditions found by accessing the
* following link:
* http://www.renesas.com/disclaimer
* Copyright (C) 2013-2014 Renesas Electronics Corporation All rights reserved.
***********************************************************************************************************************/

/***********************************************************************************************************************
* File Name    : r_ctsu_user_API.h
* Version      : 1.00
* Description  : 
***********************************************************************************************************************/

/***********************************************************************************************************************
* History      : DD.MM.YYYY Version    Description
*              : xx.xx.2014   1.00     First Release
***********************************************************************************************************************/

#ifndef __TOUCH_USER_API_H__    //[
#define __TOUCH_USER_API_H__
/***********************************************************************************************************************
Macro definitions
***********************************************************************************************************************/
#ifdef __TOUCH_USER_API_C__
    #define TOUCH_API_EXTERN
#else
    #define TOUCH_API_EXTERN    extern
#endif

#define GET_OK                  0x00
#define GET_NG                  0x01
#define SENS_CNT_OVER_NG        0x02
#define REF_CNT_OVER_NG         0x03
#define SENS_REF_CNT_OVER_NG    0x04
#define TSCAP_ERR_NG            0x05
#define SELF_TUNING_NG          0x06

#define DATA_GET_ERROR          0x0000

/***********************************************************************************************************************
Typedef definitions
***********************************************************************************************************************/
typedef enum
{
    CTSU_STOP_RQ        = 0x00,
    CTSU_START_RQ       = 0x01
} CTSU_MODE_E;

typedef enum
{
    DC_ALL_STOP         = 0x00,
    DC_ALL_ACT          = 0x01,
    DC_CH_ENABLE        = 0x02
} DRIFT_ENABLE_E;

typedef enum
{
    AT_STOP             = 0x00,
    AT_START            = 0x01,
    AT_INITIAL_START    = 0x02,
    AT_PAUSE            = 0x03,
} AUTO_TUNING_ONOFF;

/***********************************************************************************************************************
Exported global variables
***********************************************************************************************************************/

/***********************************************************************************************************************
Exported global functions (to be accessed by other files);
***********************************************************************************************************************/
uint8_t CtsuSetMeasureMode( CTSU_MODE_E mode );
uint8_t CtsuGetDataCheck( void );
uint8_t CtsuSetDriftEnableCh( DRIFT_ENABLE_E sw );
uint8_t CtsuSetAutoTuningOnOff( AUTO_TUNING_ONOFF info );
void    CtsuSetTrackingTiming( uint16_t time );

/***********************************************************************************************************************
******************************                                                            ******************************
******************************                    Self global variables                   ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#ifndef MUTUAL_FUNC_USE
    uint16_t CtsuGetSensorData( uint8_t loop_ts );
    uint16_t CtsuGetReferenceData( uint8_t loop_ts );
/***********************************************************************************************************************
******************************                                                            ******************************
******************************                   Mutual global variables                  ******************************
******************************                                                            ******************************
***********************************************************************************************************************/
#else
    uint16_t CtsuGetSensorData( uint8_t row, uint8_t column );
    uint16_t CtsuGetReferenceData( uint8_t index_num );
#endif //] MUTUAL_FUNC_USE

#endif //] __TOUCH_USER_API_H__

