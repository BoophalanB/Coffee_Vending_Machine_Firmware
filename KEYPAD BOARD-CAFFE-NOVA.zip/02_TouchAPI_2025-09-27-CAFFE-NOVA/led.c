#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"


void led_sequence_on();

void led_sequence_on()
{   
	if(led_flag)
	{
		switch(led)
		{
			case 1:
			if(!led_delay)
			{
				KEY_LED_1_ON;
				KEY_LED_2_ON;
				led_delay=3;
				led++;
			}
			        break;
			case 2:
			if(!led_delay)
			{
				KEY_LED_3_ON;
				KEY_LED_4_ON;
				led_delay=3;
				led++;
			}
				break;
			case 3:
			if(!led_delay)
			{
				KEY_LED_5_ON;
				KEY_LED_6_ON;
				led_delay=3;
				led++;
			}
				break;
			case 4:
			if(!led_delay)
			{
				KEY_LED_7_ON;
				KEY_LED_8_ON;
				led_delay=3;
				led++;
			}
				break;
			case 5:
			if(!led_delay)
			{
				KEY_LED_9_ON;
				KEY_LED_10_ON;
				led_delay=3;
				led++;
			}
			break;
			case 6:
			if(!led_delay)
			{
				KEY_LED_6_ON;
				led_delay=3;
				led++;
			}
			break;
			case 7:
			if(!led_delay)
			{
				ALL_KEY_LED_OFF;
				led_delay=3 ;
				led=1;
			}
			break;	
		}
	}
	if(led_blink_flag)
	{
		switch(led)
		{
			case 1:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY1_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			      else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
			case 2:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY2_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			      else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
			case 3:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY3_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			      else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
			case 4:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY4_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
		              else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
			case 5:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY5_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			       else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
			case 6:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY6_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			      else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
			case 7:
			      if((!led_delay)&&(!nxt_seq))
				{
					KEY7_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			       else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
		}
	}
	if((comm_err_flag)||(re_err_flag)||(ht_err_flag))
	{
		switch(led)
		{
			case 1:
			if((!led_delay)&&(!nxt_seq))
				{
					ALL_KEY_LED_ON;
					led_delay=5;
					nxt_seq=1;
				}
			else if((!led_delay)&&(nxt_seq))
				{
					ALL_KEY_LED_OFF;
					led_delay=5;
					nxt_seq=0;
				}
			break;
		}
	}
	
}