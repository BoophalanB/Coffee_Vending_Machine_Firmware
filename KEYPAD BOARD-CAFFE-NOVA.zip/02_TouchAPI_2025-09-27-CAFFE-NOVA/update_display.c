#include "r_cg_macrodriver.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"



void home_screen();
void next_iddisplay();
void error_update_display(unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char);
void show_update_display();
void waiting(unsigned char count);
void update_data(void);

extern void display_message1(unsigned char count, unsigned char data1);
extern void display_data(unsigned char lcd_addr, unsigned char data1);

void error_update_display(unsigned char error_id1, unsigned char error_id2, unsigned char error_id3, unsigned char error_id4, unsigned char err1_flag, unsigned char err2_flag, unsigned char err3_flag, unsigned char err4_flag)
{
	if(err1_flag)
	{
		for(var1=0; var1<20; var1++)
		{
			display_message1(var1,err_mesg[error_id1][var1]);
		}
		err1_flag=CLEAR;
	}
	if(err2_flag)
	{
		for(var2=20; var2<40; var2++)
		{
			display_message1(var2,err_mesg[error_id2][var2-20]);
		}
		err2_flag=CLEAR;
	}
	if(err3_flag)
	{
		for(var3=40; var3<60; var3++)
		{
			display_message1(var3,err_mesg[error_id3][var3-40]);
		}	
		err3_flag=CLEAR;
	}
	if(err4_flag)
	{
		for(var4=60; var4<80; var4++)
		{
			display_message1(var4,err_mesg[error_id4][var4-60]);
		}	
		err4_flag=CLEAR;
	}
}


void home_screen()//HOME SCREEN
{  
	if((!dis_delay)&&(!home_sc_id))
	{
		if((!boiler_drain_flag)&&(!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!machine_restart_flag)&&(!menuu))
		error_update_display(54,1,2,0,1,1,1,1);//FLICKER WELCOME
		else if(boiler_drain_flag)
		error_update_display(54,1,42,0,1,1,1,1);//BOILER DRAINING
		else if((!boiler_drain_flag)&&(machine_restart_flag))
		error_update_display(54,1,55,56,1,1,1,1);//BOILER DRAIN COMPLETED RESTART MACHINE
		else if(tea_clean_flag)
		error_update_display(54,1,39,0,1,1,1,1);//TEA CLEAN
		else if(coff_clean_flag)
		error_update_display(54,1,40,0,1,1,1,1);//COFFEE CLEAN
		else if(milk_clean_flag)
		error_update_display(54,1,41,0,1,1,1,1);//MILK CLEAN
		dis_delay =8;
		home_sc_id=1;
	}
	else if((!dis_delay)&&(home_sc_id))
	{
		if((!boiler_drain_flag)&&(!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!machine_restart_flag)&&(!menuu))
		error_update_display(54,0,2,0,1,1,1,1);//EMPTY SPACE
		else if((boiler_drain_flag)||(tea_clean_flag)||(coff_clean_flag)||(milk_clean_flag))
		error_update_display(54,0,0,0,1,1,1,1);//EMPTY SPACE
		dis_delay =8;
		home_sc_id=0;
	}
}

void next_iddisplay()
{
	if(val_password_flag)
	{
		disp_id2=0;
		error_update_display(0,0,32,0,1,1,1,1);//VALID PASSWORD
		dis_delay =15;
		val_password_flag=0;
		nxt_id_flag=1;
	}
	if(inval_password_flag)
	{
		disp_id2=0;
		error_update_display(0,0,33,0,1,1,1,1);//INVALID PASSWORD
		home_sc_flag=1;
		dis_delay =15;
		inval_password_flag=0;
	}
	if((value_browser_point==15)&&(!dis_delay)&&(nxt_id_flag))
	{
		value_browser_point=0;
		nxt_id_flag=0;
		error_update_display(0,0,0,0,1,1,1,1);//CLEAR 
		brew=2;
		disp_id1 = BREW;
		key_press_flag=1;
		final_key=10;
	}
	if((value_browser_point==25)&&(!dis_delay)&&(nxt_id_flag))
	{
		value_browser_point=0;
		nxt_id_flag=0;
		error_update_display(0,0,0,0,1,1,1,0);//CLEAR
		sett=2;
		disp_id1 = SETTINGG;
		key_press_flag=1;
		final_key=10;
	}
}

void show_update_display()
{
	if(line1_flag)
	{
		home_sc_flag=0;
		for(var1=0; var1<20; var1++)
		{
			display_message1(var1,lcd_code[disp_id1-1][var1]);
		}
		line1_flag=CLEAR;
	}
	if(line2_flag)
	{
		home_sc_flag=0;
		for(var2=20; var2<40; var2++)
		{
			display_message1(var2,lcd_code[disp_id2-1][var2-20]);
		}
		line2_flag=CLEAR;
	}
	if(line3_flag)
	{
		home_sc_flag=0;
		for(var3=40; var3<60; var3++)
		{
			display_message1(var3,lcd_code[disp_id3-1][var3-40]);
		}
		line3_flag=CLEAR;
		next_dis_id= nxt_id_pattern[disp_id3-1][0];
	}
	if(line4_flag)
	{
		home_sc_flag=0;
		for(var4=60; var4<80; var4++)
		{
			display_message1(var4,lcd_code[disp_id4-1][var4-60]);
		}	
		line4_flag=CLEAR;
	}
}

void update_data(void)
{
	if(update_data_flag)
	{
	        if(disp_id2)
		disp_pattern = (long)menu_pattern[disp_id2-1];	
		else
		disp_pattern = (long)menu_pattern[disp_id3-1];
		if(disp_pattern)
		{
			tmp_var1=0;
			if(disp_id2)
			tmp_var2 =0xD3;
			else
			tmp_var2 =0xA7;
			temp_flag = 0;
			temp_disp_pattern = disp_pattern;	
			for(tmp_var3 = 0; tmp_var3 < 20 ; tmp_var3++)
			{
				if(tmp_var3 NOT_EQUAL_TO 0)
				{
					temp_disp_pattern >>= 1;
					if(temp_disp_pattern EQUAL_TO 0)
					{
						break;
					}
				}
				if((temp_disp_pattern & 1) == 1)
				{       
					temp_area.ch_area[3] = disp_area[tmp_var1];                                                                       
					if(temp_flag) 			
					{ 
						temp_area.ch_area[3] >>= 4; 
					}
					temp_area.ch_area[3] &= 0x0f;	 
					temp_area.ch_area[3] += 0x30;	
					display_data(tmp_var2,temp_area.ch_area[3]);
					if(temp_flag) 
					{
						tmp_var1++;      	 
					}
					temp_flag = !temp_flag;		
				}
				tmp_var2--;						          	
			
			}
		}
		disp_pattern = 0;
		tmp_var2 = 0;
		update_data_flag=0;
	}
} 



void waiting(unsigned char count)
{
	half_sec_delay_1 = count;
	while(half_sec_delay_1)
	{
		if(half_sec_delay_1==0)
		break;
	}
}



