#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"


void key_scan_logic();

void key_scan_logic()
{
	f_key_data =0;
       //**********************KEY10*****************/	
	if(key_data==1024)
	{
		f_key_data = 10;
	}
	//**********************KEY9*****************/
	else if(key_data==512)
	{
		f_key_data = 8;
	}
	//**********************KEY8*****************/	
	else if(key_data==256)
	{
		f_key_data = 6;
	}
	//********************KEY7********************//
	else if(key_data==128)
	{
		f_key_data = 4;
	}
	//**********************KEY6*****************/	
	else if(key_data==64)
	{
		f_key_data = 2;
	}
	//**********************KEY5*****************/	
	else if(key_data==32)
	{
		f_key_data = 1;
	}
	//**********************KEY4*****************/	
	else if(key_data==16)
	{
		f_key_data = 3;
	}
	//**********************KEY3*****************/	
	else if(key_data==8)
	{
		f_key_data = 5;
	}
	//**********************KEY2*****************/	
	else if(key_data==4)
	{
		f_key_data = 7;
	}
	//**********************KEY1*****************//
	else if(key_data==2)
	{
		f_key_data = 9;
	}
	//*******************************************/
	if(pre_key_data_check!=f_key_data)
	{
		pre_key_data_check=f_key_data;	
	}

}

