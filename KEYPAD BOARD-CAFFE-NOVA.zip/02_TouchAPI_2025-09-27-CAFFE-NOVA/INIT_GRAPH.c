#include "r_cg_macrodriver.h"
#include "MACROS.H"
#include "XVARIABLES.H"



void init_lcd(void);
void delay2(unsigned int);
void delay1(unsigned char);
void four_bit_init(unsigned char);
void lcd_write(unsigned char, unsigned char);
void clear_display(void);


void init_lcd(void)
{
	delay2(0xFF);
	delay2(0xFF);         //DELAY FOR AFTER POWER SUPPLY
	four_bit_init(0x03);  //8 BIT MODE 
	delay2(0xFF);
	four_bit_init(0x03);  //8 BIT MODE
	delay2(0x0A);		
	four_bit_init(0x02);  //4 BIT MODE
	delay2(0x0A);	
	lcd_write(INST,0x28); //FUNCTION SET FOR 4 BIT 2 LINE 5*8 DOT
	delay2(0x0A);		
	lcd_write(INST,0x08); //DISPLAY OFF CURSOR OFF
	delay2(0x0A);		
	lcd_write(INST,0x01); //CLEAR DISPLAY
	delay2(0x0A);
	lcd_write(INST,0x06); //ENTRY MODE SET FOR INCREMENT /NO SHIFT
	delay2(0x0A);		
	lcd_write(INST,0x0f); //AFTER DISPLAY ON CURSOR ON BLINK ON
	delay2(0x0A);		
	
}

void lcd_write(unsigned char x, unsigned char y)
{
	unsigned char temp1,temp2,temp3,i;
	if(x==1)
	{
		RS = 1;//DATA(MESSAGE)
	}
	else
	{
		RS = 0;//COMMAND(INSTRUCTION)
	}
	temp3 = 0;
	temp3 = (y)|0x0f;
	temp1 = temp3&0xf0;
	temp1=temp1>>4;
	temp2 = LCD_PORT;
	temp2 = temp2&0xf0;
	LCD_PORT = temp1|temp2;
	ENABLE = HIGH;	

	for(i=0;i<50;i++);		//asm("NOP");
	
	ENABLE = LOW;
	temp3 = 0;
	temp3 = (y&0x0f)|0xf0;	
	temp1 = temp3&0x0f;
	temp2 = LCD_PORT;
	temp2 = temp2&0xf0;
	LCD_PORT = temp1|temp2;
	ENABLE = HIGH;						
	
	for(i=0;i<50;i++);		//asm("NOP");

	ENABLE = LOW;
}

void four_bit_init(unsigned char temp)
{

	unsigned char temp1,temp2,temp3,i;

	RS = 0;
	temp3 = 0;
	temp3 = temp;            
	temp1 = temp3&0x0f;	
	temp2 = LCD_PORT;
	temp2 = temp2&0xf0;
	LCD_PORT = temp1|temp2;
	ENABLE = HIGH;	
	
   	for(i=0;i<50;i++);		//asm("NOP");
	
	
	
	ENABLE = LOW;
}

void clear_display()
{
	lcd_write(INST,0x01);    //clear disp 28 page
	delay2(0x04);		// 4 msec
}


void delay2(unsigned int D)
{
	unsigned char A;
	while(D)
	{		
		A = 0xff;
		while(A)
		{
			A--;
		}
		D--;
		
	}
}

void delay1(unsigned char D)
{
	unsigned char A;
	while(D)
	{		
		A = 0x01;		// 01
		while(A)
		{			
			A--;
		}
		D--;
	}
}