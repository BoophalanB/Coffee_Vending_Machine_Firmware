#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"

void HEX_TO_BCD(unsigned int num);
//unsigned char dec_to_hex(unsigned char num);

void HEX_TO_BCD(unsigned int num)
{
	unsigned char value[10]={0,0,0,0,0,0,0,0,0,0};
	unsigned char i = 0;
	
	while(num > 0)
	{
		value[i] = num %  10;
		num /= 10;
		i = i + 1;
	}	
	disp_area[0]=value[0]|(value[1]<<4);
	disp_area[1]=value[2]|(value[3]<<4);
	disp_area[2]=value[4]|(value[5]<<4);
	disp_area[3]=value[6]|(value[7]<<4);
	disp_area[4]=value[8]|(value[9]<<4);
	
}

//unsigned char dec_to_hex(unsigned char num)
//{	
//	unsigned char value[2]={0,0};
//	unsigned char i = 0;
//	unsigned char disp_area=0,rtc_disp=0;
//	while(num > 0)
//	{
		
//		value[i] = num % 10;
//		num /= 10;
//		i = i + 1;
//	}		
//	rtc_disp=disp_area=value[0]|(value[1]<<4);
//	return rtc_disp;
//}