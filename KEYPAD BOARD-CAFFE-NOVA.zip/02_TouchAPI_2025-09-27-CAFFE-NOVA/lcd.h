
const unsigned char err_mesg[][20]=
{
	/*0123456789ABCDEF1234*/
	/*84218421842184218421*/
	 "                    ",	/* 00 */
	 "       WELCOME      ",	/* 01 */
	 " SELECT YOUR DRINKS ",	/* 02 */
	 "    LIGHT COFFEE    ",        /* 03 */
	 "        TEA         ",        /* 04 */
	 "   STRONG COFFEE    ",        /* 05 */
	 "    BLACK COFFEE    ",        /* 06 */
	 "    BLACK TEA       ",        /* 07 */
	 "        MILK        ",        /* 08 */
	 "    HOT WATER       ",        /* 09 */
	 "       STEAM        ",        /* 10 */
	 "         OK         ",        /* 11 */
	 "      BOOTING...    ",        /* 12 */
         "   KEYPAD VERSION   ",        /* 13 */
	 "  MAINBOARD VERSION ",        /* 14 */
	 "     REFILLING...   ",        /* 15 */
	 "   REFILLING DONE   ",        /* 16 */
	 "       HEATING...   ",        /* 17 */
	 "     HEATING DONE   ",        /* 18 */
	 "    MACHINE READY   ",        /* 19 */
	 "   PLEASE WAIT...   ",        /* 20 */
	 "   INITIALIZING     ",        /* 21 */
	 "   LOADING...       ",        /* 22 */
	 "   DEFAULT VALUES   ",        /* 23 */
	 " HW:1.0      SW:1.0 ",        /* 24 */ //MB V 1.0
	 " HW:1.0      SW:1.0 ",        /* 25 */ //KP V 1.0
	 "    DISPENSING...   ",        /* 26 */
	 "       STOP!!!      ",        /* 27 */
	 "    THANK YOU       ",        /* 28 */
	 "    TEA BREWING     ",        /* 29 */
	 "   COFFEE BREWING   ",        /* 30 */
	 " TEA COFFEE BREWING ",        /* 31 */
	 "   VALID PASSWORD!! ",        /* 32 */
	 " INVALID PASSWORD!! ",        /* 33 */
	 "       MENU         ",        /* 34 */
	 "    COMMUNICATION   ",        /* 35 */
	 "       ERROR!!      ",        /* 36 */
	 "      REFILLING     ",        /* 37 */
	 "       HEATING      ",        /* 38 */
	 "   TEA CLEANING!!!  ",        /* 39 */
	 " COFFEE CLEANING!!! ",        /* 40 */
	 "  MILK CLEANING!!!  ",        /* 41 */
	 " BOILER DRAINING!!! ",        /* 42 */
	 "  ST COFFEE COUNT   ",        /* 43 */
	 "  LT COFFEE COUNT   ",        /* 44 */
	 "    LT TEA COUNT    ",        /* 45 */
	 "  BLACK TEA COUNT   ",        /* 46 */
	 "  BLACK COFF COUNT  ",        /* 47 */
	 "     MILK COUNT     ",        /* 48 */
	 "  HOT WATER COUNT   ",        /* 49 */
	 "  ALL DRINK COUNT   ",        /* 50 */
	 "  COUNT RESETING..  ",        /* 51 */
	 "  COFFEE BREW COUNT ",        /* 52 */
	 "   TEA BREW COUNT   ",        /* 53 */
	 " *** CAFFE NOVA *** ",        /* 54 */
	 " BR DRAIN COMPLETED ",        /* 55 */
	 " RESTART THE MACHINE",        /* 56 */
	
}; 

const unsigned char lcd_code[][20]=                                   
 {          
/*****************MENU**********************/
        /*0123456789ABCDEF1234*/
       /*84218421842184218421*/
	"     TOTAL COUNT    ",	     /* 01 */
	"     DAILY COUNT    ",	     /* 02 */
        "   ALL DRINK COUNT  ",      /* 03 */
	"     MILK CLEAN     ",	     /* 04 */
	"  COFFEE DEC CLEAN  ",	     /* 05 */
	"    TEA DEC CLEAN   ",	     /* 06 */
	"    BOILER DRAIN    ",	     /* 07 */

/*******Brewing & Brew Setting**************/

        "    Password:       ",	     /* 08 */
        "   TEA DEC PREPARE  ",	     /* 09 */
        " COFFEE DEC PREPARE ",	     /* 10 */
        "      Tea Dec: . Ltr",	     /* 11 */
        "   Coffee Dec: . Ltr",	     /* 12 */
        "Tea Dec 1.5L TM:  . ",	     /* 13 */
        "Cof Dec 1.5L TM:  . ",	     /* 14 */
        " Tea Dec 3Lr TM:  . ",	     /* 15 */
        " Cof Dec 3Lr TM:  . ",	     /* 16 */	
	
/***********Tea Setting*********************/

	" Light Tea Milk:  . ",	     /* 17 */
	" Light Tea Dec :  . ",	     /* 18 */
	"  Black Tea HW :  . ",	     /* 19 */
	"  Black Tea Dec:  . ",	     /* 20 */
	"    Tea Dec Rev:  . ",	     /* 21 */
	
/**********Coffee Setting*******************/

	" St Coffee Milk:  . ",	     /* 22 */
	" St Coffee Dec :  . ",	     /* 23 */
	" Lt Coffee Milk:  . ",	     /* 24 */
	" Lt Coffee Dec :  . ",	     /* 25 */
	" Black Coff HW :  . ",	     /* 26 */
	" Black Coff Dec:  . ",	     /* 27 */
	"   Coff Dec Rev:  . ",	     /* 28 */
	
/************Milk Setting*******************/

        "  Milk On time :  . ",	     /* 29 */
	"  Milk Ext time:  . ",	     /* 30 */
	"  Milk Rev time:  . ",	     /* 31 */

/**************Hw Setting*******************/

        "     HW On time:  . ",	     /* 32 */
	
/************Other Setting*******************/	
        "Heater Err time:  . ",	     /* 33 */
        " Boiler dr time:  . ",	     /* 34 */
	
	"      BREWING       ",      /* 35 */
	"  BREWING SETTINGS  ",      /* 36 */
	"  DRINKS SETTINGS   ",      /* 37 */
	"    TEA SETTINGS    ",      /* 38 */
	"  COFFEE SETTINGS   ",      /* 39 */
	"   MILK SETTINGS    ",      /* 40 */
	" HOT WATER SETTINGS ",      /* 41 */
	"   OTHER SETTINGS   ",      /* 42 */
	"     SETTINGS       ",      /* 43 */
	
	"        BACK        ",	     /* 44 */ //BREW SET BACK
	"        EXIT        ",	     /* 45 */ //MENU EXIT
	
/************Count Setting*******************/	
	" DAILY COUNT RESET  ",	     /* 46 */
	"                    ",	     /* 47 *///COUNT VALUES
	" TOTAL COUNT RESET  ",	     /* 48 */
	"  BREW COUNT RESET  ",	     /* 49 */
	" COFFEE BREW COUNT  ",	     /* 50 */
	"   TEA BREW COUNT   ",	     /* 51 */
	
	"        EXIT        ",	     /* 52 */ //BREW EXIT
	"        EXIT        ",	     /* 53 */ //SET EXIT
	"        EXIT        ",	     /* 54 */ //BREW SET EXIT
	"        EXIT        ",	     /* 55 */ //DRINK SET EXIT
	"        EXIT        ",	     /* 56 */ //TEA SET EXIT
	"        EXIT        ",	     /* 57 */ //COFF SET EXIT
	"        EXIT        ",	     /* 58 */ //MK SET EXIT
	"        EXIT        ",	     /* 59 */ //HW SET EXIT
	"        EXIT        ",	     /* 60 */ //OT SET EXIT
	"        BACK        ",	     /* 61 */ //DRINK SET BACK
	"        BACK        ",	     /* 62 */ //TEA SET BACK
	"        BACK        ",	     /* 63 */ //COFF SET BACK
	"        BACK        ",	     /* 64 */ //MILK SET BACK
	"        BACK        ",	     /* 65 */ //HW SET BACK
	"        BACK        ",	     /* 66 */ //OT SET BACK
};

const unsigned int menu_pattern[] = 
  {
	{0x00000},		/*0x01*///1
	{0x00000},		/*0x02*///2
	{0x00000},		/*0x03*///3
	{0x00000},		/*0x04*///4
	{0x00000},		/*0x05*///5
	{0x00000},        	/*0x06*///6
	{0x00000},        	/*0x07*///7
	{0x00070},		/*0x08*///8//PASSWORD PATTERN
	{0x00000},		/*0x09*///9
	{0x00000},		/*0x0A*///10
	{0x00028},		/*0x0B*///11//TEA BREW LTR PATTERN 
	{0x00028},		/*0x0C*///12//COFF BREW LTR PATTERN
	{0x0000D},		/*0x0D*///13//TEA 1L TM PATTERN
	{0x0000D},        	/*0x0E*///14//COFF 1L TM PATTERN
	{0x0000D},        	/*0x0F*///15//TEA 3L TM PATTERN
	{0x0000D},        	/*0x10*///16//COFF 3L TM PATTERN
	{0x0000D},		/*0x11*///17//LT MK PATTERN
	{0x0000D},		/*0x12*///18//LT DEC PATTERN
	{0x0000D},        	/*0x13*///19//BT HW PATTERN
	{0x0000D},        	/*0x14*///20//BT DEC PATTERN
	{0x0000D},        	/*0x15*///21//TEA DEC REV PATTERN
	{0x0000D},		/*0x16*///22//SC MK PATTERN
	{0x0000D},		/*0x17*///23//SC DEC PATTERN
	{0x0000D},        	/*0x18*///24//LC MK PATTERN
	{0x0000D},        	/*0x19*///25//LC DEC PATTERN
	{0x0000D},        	/*0x1A*///26//BC HW PATTERN 
	{0x0000D},        	/*0x1B*///27//BC DEC PATTERN
	{0x0000D},        	/*0x1C*///28//COF REV PATTERN
	{0x0000D},        	/*0x1D*///29//MK ON TM PATTERN
	{0x0000D},        	/*0x1E*///30//MK EXT TM PATTERN
	{0x0000D},        	/*0x1F*///31//MK REV TM PATTERN
	{0x0000D},        	/*0x20*///32//HW ON TM PATTERN
	{0x0000D},        	/*0x21*///33//HTR ERR TM PATTERN
	{0x0000D},        	/*0x22*///34//BR DRAIN TM PATTERN
	{0x00000},        	/*0x23*///35
	{0x00000},        	/*0x24*///36
	{0x00000},        	/*0x25*///37
	{0x00000},        	/*0x26*///38
	{0x00000},        	/*0x27*///39
	{0x00000},        	/*0x28*///40
	{0x00000},        	/*0x29*///41
	{0x00000},        	/*0x2A*///42
	{0x00000},        	/*0x2B*///43
	{0x00000},        	/*0x2C*///44
	{0x00000},        	/*0x2D*///45
	{0x00000},        	/*0x2E*///46
	{0x03FC0},        	/*0x2F*///47//PATTERN FOR COUNT VALUES
	{0x00000},        	/*0x30*///48
	{0x00000},        	/*0x31*///49
	{0x00000},        	/*0x32*///50
	{0x00000},        	/*0x33*///51
	{0x00000},        	/*0x34*///52
	{0x00000},        	/*0x35*///53
	{0x00000},        	/*0x36*///54
	{0x00000},        	/*0x36*///55
	{0x00000},        	/*0x36*///56
	{0x00000},        	/*0x36*///57
	{0x00000},        	/*0x36*///58
	{0x00000},        	/*0x36*///59
	{0x00000},        	/*0x36*///60
	{0x00000},        	/*0x36*///61
	{0x00000},        	/*0x36*///62
	{0x00000},        	/*0x36*///63
	{0x00000},        	/*0x36*///64
	{0x00000},        	/*0x36*///65
	{0x00000},        	/*0x37*///66
  };

  
  
 const unsigned char nxt_id_pattern[][1]=
  {
	{0x02},            /*01*/ //DAILY COUNT        
	{0x03},            /*02*/ //ALL DRINK COUNT
	{0x33},            /*03*/ //TEA BREW COUNT
	{0x05},            /*04*/ //COFF CLEAN
	{0x06},            /*05*/ //TEA CLEAN
	{0x2E},            /*06*/ //DAILY COUNT RESET
	{0X30},            /*07*/ //TOTAL COUNT RESET
	{0X08},            /*08*/ //PASSWORD
	{0x0A},            /*09*/ //COFFEE DEC PREPARE
	{0x34},            /*10*/ //BREW EXIT
	{0x0D},            /*11*/ //TEA DEC 1 LTR TM
	{0x0E},            /*12*/ //COFF DEC 1 LTR TM
	{0x0F},            /*13*/ //TEA DEC 3 LTR TM
	{0x10},            /*14*/ //COFF DEC 3 LTR TM 
	{0x0C},            /*15*/ //COFF DEC PRE LTR 
	{0x2C},            /*16*/ //BREW SET BACK
	{0X12},            /*17*/ //LT DEC ON TM
	{0X13},            /*18*/ //BT HW ON TM
	{0X14},            /*19*/ //BT DEC ON TM
	{0X15},            /*20*/ //TEA DEC REV TM
	{0X3E},            /*21*/ //BACK 2
	{0X17},            /*22*/ //SC DEC ON TM
	{0X18},            /*23*/ //LC MILK ON TM
	{0X19},            /*24*/ //LC DEC ON TM
	{0X1A},            /*25*/ //BC HW ON TM
	{0X1B},            /*26*/ //BC DEC ON TM
	{0X1C},            /*27*/ //COFF DEC REV TM
	{0X3F},            /*28*/ //BACK 3
	{0X1E},            /*29*/ //MILK EXT TM
	{0X1F},            /*30*/ //MILK REV TM
	{0X40},            /*31*/ //BACK 4
	{0X41},            /*32*/ //BACK 5
	{0X22},            /*33*/ //BOILER DRN TM
	{0X07},            /*34*/ //BOILER DRAIN
	{0X23},            /*35*/ //BREW
	{0X25},            /*36*/ //DRINK SET
	{0X2A},            /*37*/ //OT SET
	{0X27},            /*38*/ //COFF SET
	{0X28},            /*39*/ //MILK SET
	{0X29},            /*40*/ //HW SET
	{0X3D},            /*41*/ //DRINK SET BACK 1
	{0X35},            /*42*/ //SET EXIT 2
	{0X2B},            /*43*/ //SETTINGG
	{0X36},            /*44*/ //EXIT 3
	{0X01},            /*45*/ //TOTAL COUNT
	{0X2D},            /*46*/ //MENU EXIT 
	{0X2F},            /*47*/ //COUNT PATTERN
	{0X31},            /*48*/ //BREW COUNT RESET
	{0X42},            /*49*/ //BACK 6
	{0X04},            /*50*/ //MILK CLEAN
	{0X32},            /*51*/ //COFF BREW COUNT 
	{0X09},            /*52*/ //TEA BREW
	{0X24},            /*53*/ //BREW SET
	{0X0B},            /*54*/ //TEA BREW LTR
	{0X26},            /*55*/ //TEA SET
	{0X11},            /*56*/ //LT MK TM
	{0X16},            /*57*/ //SC MK TM
	{0X1D},            /*58*/ //MK ON TM
	{0X20},            /*59*/ //HW ON TM
	{0X21},            /*60*/ //HTR ERR TM
	{0X37},            /*61*/ //DRINK SET EXIT 4
	{0X38},            /*62*/ //TEA SET EXIT 5
	{0X39},            /*63*/ //COFF SET EXIT 6
	{0X3A},            /*64*/ //MK SET EXIT 7
	{0X3B},            /*65*/ //HW SET EXIT 8
	{0X3C},            /*66*/ //OT SET EXIT 9
  };