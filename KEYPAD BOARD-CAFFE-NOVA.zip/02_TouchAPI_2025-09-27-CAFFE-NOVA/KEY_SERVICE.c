#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"

void key_service(void);


extern void error_update_display(unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char);
extern void validate_password();
extern void HEX_TO_BCD(unsigned int num);
extern void increment();
extern void decrement();
extern void gui_msg_send_fun();
extern void password();
extern void brewing_sett();
extern void tea_sett();
extern void coff_sett();
extern void milk_sett();
extern void hw_sett();
extern void ot_sett();
extern void ok_fun();

void key_service()
{   
	if (key_press_flag)
	{       
		switch (final_key)
		{
			case 1://STRONG COFFEE
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!increment_decrement_flag)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3))
				       {
					 gui_msg_send_fun(2,0x02,0x01); //SC
				       }
				       else if((drink_process_flag)&&(process_id==1))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
				       else if(password_flag)
				       {
					     val_flag=1;
					     if((value_browser_point)&&(value_browser_point<=6))
					     value_browser_point=(value_browser_point*10)+1;
					     else
					     value_browser_point = 1; 
					     update_data_flag=1;
		                             HEX_TO_BCD(value_browser_point);
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(43,0,0,0,1,1,1,1);//SC COUNT  
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;	          
					  value_browser_point = setting[ST_COFF_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[ST_COFF_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 2://LIGHT COFFEE
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!increment_decrement_flag)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3)&&(!boiler_drain_flag))
				       {
					 gui_msg_send_fun(3,0x02,0x01); //LC
				       }
				       else if((drink_process_flag)&&(process_id==2))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
				       else if(password_flag)
				       {
	 				     val_flag=1;
					     if((value_browser_point)&&(value_browser_point<=6))
					     value_browser_point=(value_browser_point*10)+2;
					     else
					     value_browser_point = 2; 
					     update_data_flag=1;
		                             HEX_TO_BCD(value_browser_point);
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(44,0,0,0,1,1,1,1);//LC COUNT 
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;   
					  value_browser_point = setting[LT_COFF_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[LT_COFF_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 3://LIGHT TEA
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3))
				       {
					 gui_msg_send_fun(4,0x02,0x01); //LT
				       }
				       else if((drink_process_flag)&&(process_id==3))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
				       else if(password_flag)
				       {
					     val_flag=1;
					     if((value_browser_point)&&(value_browser_point<=6))
					     value_browser_point=(value_browser_point*10)+3;
					     else 
					     value_browser_point = 3; 
					     update_data_flag=1;
		                             HEX_TO_BCD(value_browser_point);
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(45,0,0,0,1,1,1,1);//LT COUNT
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;   
					  value_browser_point = setting[LT_TEA_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[LT_TEA_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 4://BLACK TEA
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!disp_id1)&&(!next_dis_id))
				       {
					 gui_msg_send_fun(5,0x02,0x01); //BT
				       }
				       else if((drink_process_flag)&&(process_id==4))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
				       else if(password_flag)
				       {
					     val_flag=1;
					     if((value_browser_point)&&(value_browser_point<=6))
					     value_browser_point=(value_browser_point*10)+4;
					     else
					     value_browser_point = 4; 
					     update_data_flag=1;
		                             HEX_TO_BCD(value_browser_point);
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(46,0,0,0,1,1,1,1);//BT COUNT
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;
					  value_browser_point = setting[BK_TEA_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[BK_TEA_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 5://BLACK COFFEE
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!disp_id1)&&(!next_dis_id)&&(!boiler_drain_flag))
				       {
					 gui_msg_send_fun(6,0x02,0x01); //BC 
				       }
				       else if((drink_process_flag)&&(process_id==5))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
				       else if(password_flag)
				       {
					     val_flag=1;
					     if((value_browser_point)&&(value_browser_point<=6))
					     value_browser_point=(value_browser_point*10)+5;
					     else
					     value_browser_point = 5; 
					     update_data_flag=1;
		                             HEX_TO_BCD(value_browser_point);
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(47,0,0,0,1,1,1,1);//BC COUNT
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;
					  value_browser_point = setting[BK_COFF_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[BK_COFF_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 6://MILK
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3))
				       {
					 gui_msg_send_fun(7,0x02,0x01); //M
				       }
				       else if((drink_process_flag)&&(process_id==6))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
				       else if(password_flag)
				       {
					     val_flag=1;
					     if((value_browser_point)&&(value_browser_point<=6))
					     value_browser_point=(value_browser_point*10)+6;
					     else
					     value_browser_point = 6; 
					     update_data_flag=1;
		                             HEX_TO_BCD(value_browser_point);
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(48,0,0,0,1,1,1,1);//MKCOUNT
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;
					  value_browser_point = setting[MILK_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[MILK_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 7://HOT WATER
			       if((!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			       {
				       if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3))
				       {
					 gui_msg_send_fun(8,0x02,0x01); //HW
				       }
				       else if((drink_process_flag)&&(process_id==7))
				       {
					  gui_msg_send_fun(25,0x02,0x02); //STOP     
				       }
			       }
			       if(((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))||((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT)))
			       {
				      error_update_display(49,0,0,0,1,1,1,1);//HW COUNT
				      if((disp_id3 == DAILY_COUNT)||(pre_disp_id == DAILY_COUNT))
				      {
					  pre_disp_id=DAILY_COUNT;
					  value_browser_point = setting[HW_DLY_COUNT];
				      }
				      else if((disp_id3 == TOTAL_COUNT)||(pre_disp_id == TOTAL_COUNT))
				      {
					  pre_disp_id=TOTAL_COUNT;
					  value_browser_point = setting[HW_COUNT];
				      }
				      disp_id3 = COUNT_VALUES;
				      line3_flag=1;
				      update_data_flag=1;
	                              HEX_TO_BCD(value_browser_point);   
			       }
			break;
			case 8://OK
			      if((short_press_flag)&&(val_flag)&&(long_press_flag))
			      {
				  val_flag=0;
				  validate_password();
			      }      
			      else if((long_press_flag)&&(!disp_id2)&&(!disp_id3)&&(!drink_process_flag)&&(!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			      {
			          error_update_display(0,0,0,0,1,1,1,0);//CLEAR 
		             	  brew=1;
				  password();
			      }   
			      else if((short_press_flag)&&((long_press_flag)||(menuu)))
			      {
				   ok_fun();   
			      }
			      else
			      short_press_flag=0;
			break;
			case 9://STEAM
			      if((!drink_process_flag)&&(short_press_flag)&&(!long_press_flag)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3)&&(!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			      {
				  gui_msg_send_fun(9,0x02,0x01);//STEAM   
				  drink_process_flag=1;
				  process_id=8;
			      }
			       else if((drink_process_flag)&&(process_id==8))
			      {
				   short_press_flag=0;
				   drink_process_flag=0;
				   gui_msg_send_fun(9,0x02,0x02);//STOP   
			      }	        
			break;
			case 10://MENU
			      if((short_press_flag)&&(!drink_process_flag)&&(!disp_id2)&&(!sett)&&(!brew))
			      {
				  home_sc_flag=0;
				  error_update_display(34,0,0,0,1,1,1,0); //MENU
				  menuu=1;
				  if(!pre_disp_id)
				  {
	                             if(!next_dis_id)
	                                disp_id3 = TOTAL_COUNT;
				     else if(next_dis_id)
				        disp_id3 = next_dis_id;
			             line3_flag=1;
				  }
				  else if(pre_disp_id)
				  {
				     if(pre_disp_id == DAILY_COUNT)
				        disp_id3 = DAILY_COUNT;
				     else if(pre_disp_id == TOTAL_COUNT) 
				        disp_id3 = TOTAL_COUNT;
				     else if(pre_disp_id == ALL_DRINK_COUNT)
				        disp_id3 = ALL_DRINK_COUNT;
				     else if(pre_disp_id == TEA_BREW_COUNT)
				        disp_id3 = TEA_BREW_COUNT;
				     else if(pre_disp_id == COFF_BREW_COUNT) 
				        disp_id3 = COFF_BREW_COUNT;
				    line3_flag=1;
				    pre_disp_id =0;
				  }
			      }	      
			      if((long_press_flag)&&(!next_dis_id)&&(!disp_id1)&&(!disp_id2)&&(!disp_id3)&&(!drink_process_flag)&&(!tea_clean_flag)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
			      {
				   error_update_display(0,0,0,0,1,1,1,0);//CLEAR 
				   sett=1;
			           password();   
			      }	  
			      if((sett==2)&&(disp_id1 == SETTINGG))
			      {
				 disp_id1 = SETTINGG;
                                 line1_flag=1;
				 if(!next_dis_id)
                                  disp_id3 = BREW_SETT;
				 else if(next_dis_id)
				  disp_id3 = next_dis_id;
		                 line3_flag=1;
			      }
			      if((sett==2)&&(disp_id1 == BREW_SETT))
			      {
				   if(next_dis_id)
				    disp_id3 = next_dis_id;
		                   line3_flag=1;
				   brewing_sett(); 
			      }
			      if((sett==2)&&(disp_id1 == DRINK_SETT))
			      {
				   disp_id1 = DRINK_SETT;
                                   line1_flag=1;
				   disp_id3 = next_dis_id;
		                   line3_flag=1;
			      }
			      if((sett==2)&&(disp_id1 == OT_SETT))
			      {
				   if(!next_dis_id)
                                    disp_id3 = HEATER_ER_TM;
				   else if(next_dis_id)
				    disp_id3 = next_dis_id;
		                   line3_flag=1;
				   ot_sett(); 
			      }
			      if((sett==2)&&(disp_id1 == TEA_SETT))
			      {
				   if(!next_dis_id)
                                    disp_id3 = LT_MILK_ON_TM;
				   else if(next_dis_id)
				    disp_id3 = next_dis_id;
		                   line3_flag=1;
				   tea_sett(); 
			      }
			      if((sett==2)&&(disp_id1 == COFF_SETT))
			      {
				   if(!next_dis_id)
                                    disp_id3 = SC_MILK_ON_TM;
				   else if(next_dis_id)
				    disp_id3 = next_dis_id;
		                   line3_flag=1;
				   coff_sett(); 
			      }
			      if((sett==2)&&(disp_id1 == MILK_SETT))
			      {
				   if(!next_dis_id)
                                    disp_id3 = MILK_SETT;
				   else if(next_dis_id)
				    disp_id3 = next_dis_id;
		                   line3_flag=1;
				   milk_sett(); 
			      }
			      if((sett==2)&&(disp_id1 == HW_SETT))
			      {
				   if(!next_dis_id)
                                    disp_id3 = HW_ON_TM;
				   else if(next_dis_id)
				    disp_id3 = next_dis_id;
		                   line3_flag=1;
				   hw_sett(); 
			      }
			      if((brew==2)&&(disp_id1 == BREW))
			      {
				 disp_id1 = BREW;
                                 line1_flag=1;
				 if(!next_dis_id)
                                  disp_id3 = TEA_DEC_PREPARE;
				 else if(next_dis_id)
				  disp_id3 = next_dis_id;
		                 line3_flag=1; 
			      }   
			break;	 
		}
	key_press_flag=0;
	final_key=CLEAR;	
	}
}