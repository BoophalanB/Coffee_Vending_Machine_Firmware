#include "r_cg_macrodriver.h"
#include "r_cg_sci.h"
#include "MACROS.H"
#include "XVARIABLES.H"
#include "xlcd.h"

void brewing_sett();
void tea_sett();
void coff_sett();
void milk_sett();
void hw_sett();
void ot_sett();
void ok_fun();


extern void error_update_display(unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char, unsigned char);
extern void validate_password();
extern void HEX_TO_BCD(unsigned int num);
extern void increment();
extern void decrement();
extern void gui_msg_send_fun();
extern void settings();
extern void send_sett();



void brewing_sett()
{
	disp_id1 = BREW_SETT;
	line1_flag=1;
	if(disp_id3 == TEA_DEC_PRE_LTR)
	{
	      disp_id3 = TEA_DEC_PRE_LTR;	      
	      value_browser_point = setting[TEA_DEC_LTR];
	}
	if(disp_id3 == TEA_DEC_1L_TM)
	{
	      setting[TEA_DEC_LTR] = value_browser_point;
	      disp_id3 = TEA_DEC_1L_TM;
	      value_browser_point = setting[TEA_DEC_1LTR_TM];
	}
	if(disp_id3 == TEA_DEC_3L_TM)
	{
	      setting[TEA_DEC_1LTR_TM] = value_browser_point;
	      disp_id3 = TEA_DEC_3L_TM;
	      value_browser_point = setting[TEA_DEC_3LTR_TM];
	}
	if(disp_id3 == COF_DEC_PRE_LTR)
	{
	      setting[TEA_DEC_3LTR_TM] = value_browser_point;
	      disp_id3 = COF_DEC_PRE_LTR;
	      value_browser_point = setting[COFFEE_DEC_LTR];
	}
	if(disp_id3 == COF_DEC_1LTR_TM)
	{
	      setting[COFFEE_DEC_LTR] = value_browser_point;
	      disp_id3 = COF_DEC_1LTR_TM;
	      value_browser_point = setting[COFF_DEC_1LTR_TM];
	}
	if(disp_id3 == COF_DEC_3LTR_TM)
	{
	      setting[COFF_DEC_1LTR_TM] = value_browser_point;
	      disp_id3 = COF_DEC_3LTR_TM;
	      value_browser_point = setting[COFF_DEC_3LTR_TM];
	}
	if(disp_id3 == BACK)
	{
	      setting[COFF_DEC_3LTR_TM] = value_browser_point;
	      brew_sett_flag=1;
	      send_sett();
	      disp_id3 = BACK;
	}
	if(disp_id3 == EXIT3)
	{
		disp_id3 = EXIT3;
	}
	update_data_flag=1;
	HEX_TO_BCD(value_browser_point);
	increment_decrement_flag=1;
	line3_flag=1;
}
void tea_sett()
{
	disp_id1 = TEA_SETT;
	line1_flag=1;
	if(disp_id3 == LT_MILK_ON_TM)
	{
	      disp_id3 = LT_MILK_ON_TM;
	      value_browser_point = setting[LT_MK_ON_TIME];
	}
	if(disp_id3 == LT_DEC_ON_TM)
	{	
	      setting[LT_MK_ON_TIME] = value_browser_point;
	      disp_id3 = LT_DEC_ON_TM;
	      value_browser_point = setting[LT_DEC_ON_TIME];
	}
	if(disp_id3 == BT_HW_ON_TM)
	{
	      setting[LT_DEC_ON_TIME] = value_browser_point;
	      disp_id3 = BT_HW_ON_TM;
	      value_browser_point = setting[BT_WAT_ON_TIME];
	}
	if(disp_id3 == BT_DEC_ON_TM)
	{
	      setting[BT_WAT_ON_TIME] = value_browser_point;
	      disp_id3 = BT_DEC_ON_TM;
	      value_browser_point = setting[BT_DEC_ON_TIME];
	}
	if(disp_id3 == TEA_DEC_REV_TM)
	{
	      setting[BT_DEC_ON_TIME] = value_browser_point;
	      disp_id3 = TEA_DEC_REV_TM;
	      value_browser_point = setting[TEA_DEC_REV];
	}
	if(disp_id3 == BACK2)
	{
	      setting[TEA_DEC_REV] = value_browser_point;
	      tea_sett_flag=1;
	      send_sett();
	      disp_id3 = BACK2;  
	}
	if(disp_id3 == EXIT5)
	{
		disp_id3 = EXIT5;
	}
	update_data_flag=1;
	HEX_TO_BCD(value_browser_point);
	increment_decrement_flag=1;
	line3_flag=1;
}

void coff_sett()
{
	disp_id1 = COFF_SETT;
	line1_flag=1;
	if(disp_id3 == SC_MILK_ON_TM)
	{
	      disp_id3 = SC_MILK_ON_TM;
	      value_browser_point = setting[SC_MK_ON_TIME];
	}
	if(disp_id3 == SC_DEC_ON_TM)
	{
	      setting[SC_MK_ON_TIME] = value_browser_point;
	      disp_id3 = SC_DEC_ON_TM;
	      value_browser_point = setting[SC_DEC_ON_TIME];
	}
	if(disp_id3 == LC_MILK_ON_TM)
	{
	      setting[SC_DEC_ON_TIME] = value_browser_point;
	      disp_id3 = LC_MILK_ON_TM;
	      value_browser_point = setting[LC_MK_ON_TIME];
	}
	if(disp_id3 == LC_DEC_ON_TM)
	{
	      setting[LC_MK_ON_TIME] = value_browser_point;
	      disp_id3 = LC_DEC_ON_TM;
	      value_browser_point = setting[LC_DEC_ON_TIME];
	}
	if(disp_id3 == BC_HW_ON_TM)
	{
	      setting[LC_DEC_ON_TIME] = value_browser_point;
	      disp_id3 = BC_HW_ON_TM;
	      value_browser_point = setting[BC_WAT_ON_TIME];
	}
	if(disp_id3 == BC_DEC_ON_TM)
	{
	      setting[BC_WAT_ON_TIME] = value_browser_point;
	      disp_id3 = BC_DEC_ON_TM;
	      value_browser_point = setting[BC_DEC_ON_TIME];
	}
	if(disp_id3 == COFF_DEC_REV_TM)
	{
	      setting[BC_DEC_ON_TIME] = value_browser_point;
	      disp_id3 = COFF_DEC_REV_TM;
	      value_browser_point = setting[COFFEE_DEC_REV];
	}
	if(disp_id3 == BACK3)
	{
	      setting[COFFEE_DEC_REV] = value_browser_point;
	      coff_sett_flag=1;
	      send_sett();
	      disp_id3 = BACK3;    
	}
	if(disp_id3 == EXIT6)
	{
		disp_id3 = EXIT6;
	}
	update_data_flag=1;
	HEX_TO_BCD(value_browser_point);
	increment_decrement_flag=1;
	line3_flag=1;
}

void milk_sett()
{
	disp_id1 = MILK_SETT;
        line1_flag=1;
	if(disp_id3 == MILK_ON_TM)
	{
	      disp_id3 = MILK_ON_TM;
	      value_browser_point = setting[MK_ON_TIME];
	}
	if(disp_id3 == MILK_EXT_TM)
	{
	      setting[MK_ON_TIME] = value_browser_point;
	      disp_id3 = MILK_EXT_TM;
	      value_browser_point = setting[MK_EX_TIME];
	}
	if(disp_id3 == MILK_REV_TM)
	{
	      setting[MK_EX_TIME] = value_browser_point;
	      disp_id3 = MILK_REV_TM;
	      value_browser_point = setting[MK_REV_TIME];
	}
	if(disp_id3 == BACK4)
	{
	      setting[MK_REV_TIME] = value_browser_point;
	      mk_sett_flag=1;
	      send_sett();
	      disp_id3 = BACK4;  
	}
	if(disp_id3 == EXIT7)
	{
		disp_id3 = EXIT7;
	}
	update_data_flag=1;
	HEX_TO_BCD(value_browser_point);
	increment_decrement_flag=1;
	line3_flag=1;
}

void hw_sett()
{
	disp_id1 = HW_SETT;
        line1_flag=1;
	if(disp_id3 == HW_ON_TM)
	{
	      disp_id3 = HW_ON_TM;
	      value_browser_point = setting[HW_ON_TIME];
	}
	if(disp_id3 == BACK5)
	{
	      setting[HW_ON_TIME]= value_browser_point;
	      hw_sett_flag=1;
	      send_sett();
	      disp_id3 = BACK5;   
	}
	if(disp_id3 == EXIT8)
	{
		disp_id3 = EXIT8;
	}
	update_data_flag=1;
	HEX_TO_BCD(value_browser_point);
	increment_decrement_flag=1;
	line3_flag=1;
}

void ot_sett()
{
	disp_id1 = OT_SETT;
	line1_flag=1;
	if(disp_id3 == HEATER_ER_TM)
	{
	      disp_id3 = HEATER_ER_TM;
	      value_browser_point = setting[HTR_ERR_TM];
	}
	if(disp_id3 == BOILER_DR_TM)
	{
	      setting[HTR_ERR_TM] = value_browser_point;
	      disp_id3 = BOILER_DR_TM;
	      value_browser_point = setting[BLR_DRN_TM];
	}
	if(disp_id3 == BOILER_DRAIN)
	{
	      setting[BLR_DRN_TM] = value_browser_point;
	      ot_sett_flag=1;
	      send_sett();
	      disp_id3 = BOILER_DRAIN;
	}
	if(disp_id3 == TOTAL_CNT_RESET)
	{
	      disp_id3 = TOTAL_CNT_RESET;
	}
	if(disp_id3 == BREW_CNT_RESET)
	{
	      disp_id3 = BREW_CNT_RESET;
	}
	if(disp_id3 == BACK6)
	{
	      increment_decrement_flag=0;
	      disp_id3 = BACK6;
	}
	if(disp_id3 == EXIT9)
	{
		disp_id3 = EXIT9;
	}
	update_data_flag=1;
	HEX_TO_BCD(value_browser_point);
	increment_decrement_flag=1;
	line3_flag=1;
}

void ok_fun()
{
	if((disp_id1 == BREW)&&((disp_id3==TEA_DEC_PREPARE)||(disp_id3==COF_DEC_PREPARE)))
	{
	     if(disp_id3==TEA_DEC_PREPARE)//TEA BREW
	       gui_msg_send_fun(10,0x03,0x01);
	     else if(disp_id3==COF_DEC_PREPARE)//COFF BREW
	       gui_msg_send_fun(11,0x03,0x02);
	    brew=0;
            long_press_flag=short_press_flag=0; 
	    disp_id3=disp_id1=0;
            next_dis_id=0;
	}
	if((menuu == 1)&&((disp_id3==TEA_DEC_CLN)||(disp_id3==COF_DEC_CLN)||(disp_id3==MILK_CLEAN))||(disp_id3==BOILER_DRAIN))
	{
             if((disp_id3==TEA_DEC_CLN)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
	     {
	       gui_msg_send_fun(13,0x05,0x01);
	       long_press_flag=0; 
               disp_id3=0;
	       next_dis_id=0;
	       menuu=0;
	     }
	     else if((disp_id3==COF_DEC_CLN)&&(!tea_clean_flag)&&(!milk_clean_flag)&&(!boiler_drain_flag))
	     {
	       gui_msg_send_fun(14,0x05,0x02);
	       long_press_flag=0; 
               disp_id3=0;
	       next_dis_id=0;
	       menuu=0;
	     }
	     else if((disp_id3==MILK_CLEAN)&&(!tea_clean_flag)&&(!coff_clean_flag)&&(!boiler_drain_flag))
	     {
	       gui_msg_send_fun(15,0x05,0x03);
	       long_press_flag=0; 
               disp_id3=0;
	       next_dis_id=0;
	       menuu=0;
	     }
	     else if((disp_id3==BOILER_DRAIN)&&(!coff_clean_flag)&&(!milk_clean_flag)&&(!tea_clean_flag))
	     {
	       gui_msg_send_fun(16,0x05,0x04);
	       short_press_flag=increment_decrement_flag=0;
	       sett=0;
	       value_browser_point = 00;
	       long_press_flag=0; 
               disp_id3=0;
	       next_dis_id=0;
	     }
	}
	else if((menuu == 1)&&((disp_id3 == ALL_DRINK_COUNT)||(disp_id3 == TEA_BREW_COUNT)||(disp_id3 == COFF_BREW_COUNT)))
	{
	     if(disp_id3 == ALL_DRINK_COUNT)
	     {
		pre_disp_id=ALL_DRINK_COUNT;
	        error_update_display(50,0,0,0,1,1,1,1);   
		value_browser_point = setting[ALL_DRINK_CNT];
	     }
	     else if(disp_id3 == TEA_BREW_COUNT)
	     {
	        pre_disp_id=TEA_BREW_COUNT;
	        error_update_display(53,0,0,0,1,1,1,1); 
		value_browser_point = setting[TEA_BREW_CNT];
	     }
	     else if(disp_id3 == COFF_BREW_COUNT)
	     {
		pre_disp_id=COFF_BREW_COUNT;
	        error_update_display(52,0,0,0,1,1,1,1);
		value_browser_point = setting[COFF_BREW_CNT];
	     }
	     disp_id3 = COUNT_VALUES;
	     line3_flag=1;
	     update_data_flag=1;  
             HEX_TO_BCD(value_browser_point);
	}
	if((disp_id3 == DLY_CNT_RESET)||(disp_id3 == TOTAL_CNT_RESET)||(disp_id3 == BREW_CNT_RESET))
	{
	      if(disp_id3 == DLY_CNT_RESET)
	        gui_msg_send_fun(17,0x08,0x01);
	      if(disp_id3 == TOTAL_CNT_RESET)
	        gui_msg_send_fun(18,0x08,0x02);
	      if(disp_id3 == BREW_CNT_RESET)
	        gui_msg_send_fun(19,0x08,0x03);
	      error_update_display(0,51,0,0,1,1,1,1);//COUNT RESETING
	      increment_decrement_flag=0;
	      long_press_flag=0; 
	      disp_id3=0;
	      next_dis_id=0;
	      key_block_flag=1;
	}
	else if(disp_id3==BREW_SETT)
	{
		  disp_id3 = TEA_DEC_PRE_LTR;
		  brewing_sett();
	} 
	if(disp_id3 == DRINK_SETT)
	{
	        disp_id1 = DRINK_SETT;
                line1_flag=1;
                disp_id3 = TEA_SETT;
		line3_flag=1;
        }
	else if(disp_id3==TEA_SETT)
	{         
		  disp_id3 = LT_MILK_ON_TM;
		  tea_sett();
	}
	else if(disp_id3==COFF_SETT)
	{
		  disp_id3 = SC_MILK_ON_TM;
		  coff_sett();
	}
	else if(disp_id3==MILK_SETT)
	{
		  disp_id3 = MILK_ON_TM;
		  milk_sett();
	}
	else if(disp_id3==HW_SETT)
	{
		  disp_id3 = HW_ON_TM;
		  hw_sett();
	}
	else if(disp_id3==OT_SETT)
	{
		  disp_id3 = HEATER_ER_TM;
		  ot_sett();
	} 
	else if((disp_id3==BACK)||(disp_id3==BACK1)||(disp_id3==BACK2)||(disp_id3==BACK3)||(disp_id3==BACK4)||(disp_id3==BACK5)||(disp_id3==BACK6))
	{     
		  if((disp_id3==BACK2)||(disp_id3==BACK3)||(disp_id3==BACK4)||(disp_id3==BACK5))
		  disp_id1 = DRINK_SETT;
		  else
		  disp_id1 = SETTINGG;              
                  if(disp_id3==BACK)
		   disp_id3 = BREW_SETT;
		  if(disp_id3==BACK1)
		   disp_id3 = DRINK_SETT;
		  if(disp_id3==BACK6)
		   disp_id3 = OT_SETT;
		  if(disp_id3==BACK2)
		   disp_id3 = TEA_SETT;
		  if(disp_id3==BACK3)
		   disp_id3 = COFF_SETT;
		  if(disp_id3==BACK4)
		   disp_id3 = MILK_SETT;
		  if(disp_id3==BACK5)
		   disp_id3 = HW_SETT;
		  line1_flag=1;
		  line3_flag=1;
	}
	else if((disp_id3==EXIT)||(disp_id3==EXIT1)||(disp_id3==EXIT2)||(disp_id3==EXIT3)||(disp_id3==EXIT4)||(disp_id3==EXIT5)||(disp_id3==EXIT6)||(disp_id3==EXIT7)||(disp_id3==EXIT8)||(disp_id3==EXIT9))
	{     
		  disp_id1 = disp_id2 = disp_id3 = pre_disp_id = 0;
		  menuu  = brew = sett=0;
		  long_press_flag=short_press_flag=increment_decrement_flag=0;
		  value_browser_point = 00;
		  next_dis_id=0;
		  error_update_display(0,0,0,0,1,1,1,1);//CLEAR 
		  home_sc_flag=1; 
	}
}