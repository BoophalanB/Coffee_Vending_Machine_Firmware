/*
 * Process.c
 *
 *  Created on: Jul 30, 2025
 *      Author: Dell
 */

#include "XVARIABLES.H"
#include "MACROS.H"

void drink_process();
void coffee_dispense();
void tea_dispense();
void milk_dispense();
void hot_water_dispense();
void stop_drink_dispense();
void rev_fun();
void err_fun();
void steam_flush();
extern void drinks_count_value();
extern void req_sett();

void drink_process()
{
    if((!rev_flag)||(drink_process_id==4)||(drink_process_id==5)||(drink_process_id==7)||(drink_process_id==8))
    {
      switch(drink_process_id)
       {
           case STRONG_COFF:
               coffee=1;
               rev_set_flag=1;
               coffee_dispense();
               break;
           case LIGHT_COFF:
               coffee=2;
               rev_set_flag=1;
               coffee_dispense();
               break;
           case LIGHT_TEA:
               tea=1;
               rev_set_flag=1;
               tea_dispense();
               break;
           case BLACK_TEA:
               tea=2;
               water_flag=1;
               tea_dispense();
               break;
           case BLACK_COFF:
               coffee=3;
               water_flag=1;
               coffee_dispense();
               break;
           case MILK :
               milk=1;
               rev_set_flag=1;
               milk_dispense();
               break;
           case HOTWATER:
               water=1;
               water_flag=1;
               hot_water_dispense();
               break;
           case STEAM:
               STEAM_ON;
               break;
       }
    }
}


void coffee_dispense()
{
  switch(coffee)
  {
      case 1://strong coffee
            if((!on_delay)&&(!on_delay1))
              {
                if(!complete_flag)
                {
                  COFF_DEC_FWD;
                  MILK_FWD;
                  on_delay=sc_dec_on_time*2;
                  on_delay1=sc_mk_on_time*2;
                  complete_flag=1;
                }
              }
            if((!on_delay)&&(complete_flag==1))
                {
                    COFF_DEC_OFF;
                }
            if((!on_delay1)&&(complete_flag==1))
                {
                    MILK_OFF;
                }
            if((!on_delay)&&(!on_delay1)&&(complete_flag==1))
                {
                    coffee = 0;
                    drink_process_id = 0;
                    complete_flag=0;
                    transmit_uart_data[COMPLETED] = COMPLETED;
                }
          break;
      case 2://light coffee
            if((!on_delay)&&(!on_delay1))
              {
                if(!complete_flag)
                {
                  COFF_DEC_FWD;
                  MILK_FWD;
                  on_delay=lc_dec_on_time*2;
                  on_delay1=lc_mk_on_time*2;
                  complete_flag=1;
                }
              }
            if((!on_delay)&&(complete_flag==1))
                {
                    COFF_DEC_OFF;
                }
            if((!on_delay1)&&(complete_flag==1))
                {
                    MILK_OFF;
                }
            if((!on_delay)&&(!on_delay1)&&(complete_flag==1))
                {
                    coffee = 0;
                    drink_process_id = 0;
                    complete_flag=0;
                    transmit_uart_data[COMPLETED] = COMPLETED;
                }
          break;
      case 3://black coffee
          if((!on_delay)&&(!on_delay1))
            {
              if(!complete_flag)
              {
                COFF_DEC_FWD;
                WATER_ON;
                REFILL_ON;
                on_delay=bc_dec_on_time*2;
                on_delay1=bc_wat_on_time*2;
                complete_flag=1;
              }
            }
            if((!on_delay)&&(complete_flag==1))
              {
                COFF_DEC_OFF;
              }
            if((!on_delay1)&&(complete_flag==1))
              {
                WATER_OFF;
                REFILL_OFF;
                water_flag=0;
              }
            if((!on_delay)&&(!on_delay1)&&(complete_flag==1))
              {
                coffee = 0;
                drink_process_id = 0;
                complete_flag=0;
                transmit_uart_data[COMPLETED] = COMPLETED;
              }
          break;
  }
}

void tea_dispense()
{
  switch(tea)
  {
      case 1://light tea
          if((!on_delay)&&(!on_delay1))
            {
              if(!complete_flag)
              {
                TEA_DEC_FWD;
                MILK_FWD;
                on_delay=lt_dec_on_time*2;
                on_delay1=lt_mk_on_time*2;
                complete_flag=1;
              }
            }
          if((!on_delay)&&(complete_flag==1))
            {
                TEA_DEC_OFF;
            }
          if((!on_delay1)&&(complete_flag==1))
            {
                MILK_OFF;
            }
          if((!on_delay)&&(!on_delay1)&&(complete_flag==1))
            {
                tea = 0;
                drink_process_id = 0;
                complete_flag=0;
                transmit_uart_data[COMPLETED] = COMPLETED;
            }
          break;
      case 2://black tea
          if((!on_delay)&&(!on_delay1))
            {
                if(!complete_flag)
                {
                  TEA_DEC_FWD;
                  WATER_ON;
                  REFILL_ON;
                  on_delay=bt_dec_on_time*2;
                  on_delay1=bt_wat_on_time*2;
                  complete_flag=1;
                }
            }
            if((!on_delay)&&(complete_flag==1))
              {
                  TEA_DEC_OFF;
              }
            if((!on_delay1)&&(complete_flag==1))
              {
                  WATER_OFF;
                  REFILL_OFF;
                  water_flag=0;
              }
            if((!on_delay)&&(!on_delay1)&&(complete_flag==1))
              {
                  tea = 0;
                  drink_process_id = 0;
                  complete_flag=0;
                  transmit_uart_data[COMPLETED] = COMPLETED;
              }
          break;
  }
}

void milk_dispense()
{
  switch(milk)
  {
      case 1://milk
          if(!on_delay)
          {
            if(!complete_flag)
            {
                milk=0;
                MILK_FWD;
                on_delay=(mk_on_time*2)+(milk_ex_time*2);
                complete_flag=1;
            }
            else if(complete_flag)
            {
                drink_process_id=0;
                complete_flag=0;
                MILK_OFF;
                transmit_uart_data[COMPLETED] = COMPLETED;
            }
          }
          break;
  }
}

void hot_water_dispense()
{
  switch(water)
  {
      case 1://hot water
          if(!on_delay)
          {
            if(!complete_flag)
            {
              WATER_ON;
              REFILL_ON;
              on_delay=hw_on_time*2;
              complete_flag=1;
            }
            else if(complete_flag)
            {
              drink_process_id = 0;
              water_flag=0;
              water=0;
              WATER_OFF;
              REFILL_OFF;
              complete_flag=0;
              transmit_uart_data[COMPLETED] = COMPLETED;
            }
          }
          break;
      case 2://black coffee , black tea
          break;
  }
}

void rev_fun()
{
    if((!clean)&&(!drain))
    {
        if((milk_rev_flag)&&((!drink_process_id)||(drink_process_id==4)||(drink_process_id==5)||(drink_process_id==7)||(drink_process_id==8)))
        {
            if(!on_delay2)
              {
                if(!rev_flag)
                {
                    MILK_REV;
                    on_delay2=milk_rev_time*2;
                    rev_flag=1;
                }
                else if(rev_flag)
                {
                    rev_flag=0;
                    milk_rev_flag=0;
                    MILK_OFF;
                }
              }
        }
        else if((drink_process_id)&&(rev_flag)&&(milk_rev_flag)&&(drink_process_id!=4)&&(drink_process_id!=5)&&(drink_process_id!=7)&&(drink_process_id!=8))
        {
            rev_flag=0;
            rev_set_flag=0;
            one_min_ctr2=0;
            on_delay2=0;
            milk_rev_flag=0;
            MILK_OFF;
        }
    }
}

void steam_flush()
{
    if(init_steam_flag)
    {
        if((!on_delay)&&(!complete_flag))
            {
                STEAM_ON;
                on_delay=40;//2 sec
                complete_flag=1;
            }
        else if((!on_delay)&&(complete_flag==1))
            {
                STEAM_OFF;
                on_delay=40;//2 sec
                complete_flag=2;
            }
        else if((!on_delay)&&(complete_flag==2))
            {
                STEAM_ON;
                on_delay=40;//2 sec
                complete_flag=3;
            }
        else if((!on_delay)&&(complete_flag==3))
            {
                STEAM_OFF;
                init_steam_flag=0;
                complete_flag=0;
                req_sett();
            }
    }
    else if(init_steam_flag1)
    {
        if((!on_delay)&&(!complete_flag))
           {
               STEAM_ON;
               on_delay=100;// 5 sec
               complete_flag=1;
           }
        else if((!on_delay)&&(complete_flag==1))
           {
               STEAM_OFF;
               init_steam_flag1=0;
               complete_flag=0;
           }
    }
    else if(st_flush_flag)
    {
        if((!on_delay)&&(!complete_flag))
           {
               STEAM_ON;
               on_delay=100;// 5 sec
               complete_flag=1;
           }
        else if((!on_delay)&&(complete_flag==1))
           {
               STEAM_OFF;
               st_flush_flag=0;
               complete_flag=0;
           }
    }

}

void err_fun()
{
    if((refill_err_flag)||(heater_err_flag))
    {
        ALL_DRINKS_OUTPUT_OFF;
        REFILL_OFF;
        HEATER_OFF;
        STEAM_OFF;
        drink_process_id=0;
        on_delay=on_delay1=0;
        coffee=0;
        tea=0;
        water=0;
        water_flag=0;
        milk=0;
        complete_flag=0;
    }
}

void stop_drink_dispense()
{
   ALL_DRINKS_OUTPUT_OFF;
   REFILL_OFF;
   drink_process_id=0;
   on_delay=on_delay1=0;
   coffee=0;
   tea=0;
   water=0;
   water_flag=0;
   milk=0;
   complete_flag=0;
}
