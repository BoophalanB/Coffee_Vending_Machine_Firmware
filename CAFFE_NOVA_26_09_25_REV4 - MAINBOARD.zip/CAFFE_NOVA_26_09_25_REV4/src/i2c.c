/*
 * i2c.c
 *
 *  Created on: Jul 26, 2025
 *      Author: Dell
 */

#include "MAIN_THREAD.h"
#include "XVARIABLES.H"
#include "MACROS.H"


#define SDA_HIGH  g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_11,IOPORT_LEVEL_HIGH)
#define SDA_LOW   g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_11,IOPORT_LEVEL_LOW)

#define SCL_HIGH  g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_10,IOPORT_LEVEL_HIGH)
#define SCL_LOW   g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_10,IOPORT_LEVEL_LOW)

#define SDA_INPUT  g_ioport.p_api->pinDirectionSet(IOPORT_PORT_02_PIN_11,IOPORT_DIRECTION_INPUT)
#define SDA_OUTPUT g_ioport.p_api->pinDirectionSet(IOPORT_PORT_02_PIN_11,IOPORT_DIRECTION_OUTPUT)

void start_i2c();
void stop_i2c();
void delay_i2c(unsigned int delay1);
void clock();
unsigned char write_i2c(unsigned char address, unsigned char no_of_bytes);
void data_trans(unsigned char address,unsigned char no_of_bits);
unsigned char read_i2c(unsigned char address, unsigned char no_of_bytes);
unsigned char receive_ack();
void send_ack(bool status);
void rec_data (void);

void start_i2c()
{
    SDA_HIGH;
    SCL_HIGH;
    delay_i2c(0X0F);
    SDA_LOW;
    delay_i2c(31);
     SCL_LOW;
    delay_i2c(7);
}

void delay_i2c(unsigned int delay1)
{
    delay_time = delay1 * 0x0F;
    while(delay_time)
        delay_time--;
}

void clock()
{
    SCL_HIGH;
    delay_i2c(7);
    SCL_LOW;
    delay_i2c(7);
}

void stop_i2c()
{
    SDA_LOW;
    delay_i2c(0X0F);
    SCL_HIGH;
    SDA_LOW;
    delay_i2c(0X0F);
    SDA_HIGH;
    delay_i2c(0X0F);
}

void send_ack(bool status)
{
    SCL_LOW;
    delay_i2c(0X0F);
    if(status == 1)//ACK
        SDA_LOW;
    else//NACK
        SDA_HIGH;
    delay_i2c(0X0F);
    SCL_HIGH;
    delay_i2c(0X0F);
    SCL_LOW;
    delay_i2c(0X0F);
    SDA_HIGH;
    delay_i2c(0X0F);
}

unsigned char receive_ack(void)
{
    SDA_INPUT;

    SDA_HIGH;

    delay_i2c(0X0F);
    delay = 0x3F*0X0F;
    while(delay)
    {
        delay--;
        g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&SDA_STATUS);
        if (SDA_STATUS == 0)//ACK
        {
            ack_received_flag = 1;
            break;
        }
        else //NACK
        {
            ack_received_flag = 0;
        }
    }
        SCL_HIGH;
        delay_i2c(7);
        SCL_LOW;
        delay_i2c(7);
        SDA_OUTPUT;
        return ack_received_flag;
}
unsigned char write_i2c(unsigned char address ,unsigned char no_of_bytes )//0XA4,1
{
  tmp_address[0] = (unsigned char)mem_location;
  tmp_address[1] = (unsigned char)mem_location>>8;
  start_i2c();
  data_trans(address,8);//0XA4
  if(!receive_ack())
  {
      stop_i2c();
      return(0);
  }
  data_trans(tmp_address[0],8);//10
  if(!receive_ack())
  {
      stop_i2c();
      return(0);
  }
  temp = 0;
  do
  {
      data_trans(*ram_address,8);
      if ( !receive_ack() )
      {
          stop_i2c();
          return(0);
      }
      temp++;
      ram_address++;
  }
  while (temp < no_of_bytes);
      stop_i2c();
  g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&SDA_STATUS);
  if(SDA_STATUS == 0)
  {
      SDA_HIGH;
      delay_i2c(0x5f);
  }
  return 1;
}



void data_trans(unsigned char address,unsigned char no_of_bits)
{
    unsigned char tr_data,tr_data1;

    while(no_of_bits)
    {
        tr_data = address;
        tr_data1 = tr_data;
        tr_data1 >>=7;
        SDA_WRITE = tr_data1;
        g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_11,SDA_WRITE);
        address <<= 1;
        delay_i2c(3);
        clock();
        no_of_bits--;
    }
}

unsigned char read_i2c(unsigned char address, unsigned char no_of_bytes)//0XA5,1
{
    tmp_address[0] = (unsigned char)mem_location;
    tmp_address[1] = (unsigned char)mem_location>>8;
    start_i2c();
    data_trans(address &0xFE ,8);//dummy write for addressing slave
    if (!receive_ack() )
    {
      stop_i2c();
      return(0);
    }
    data_trans(tmp_address[0],8);
    if (!receive_ack() )
    {
      stop_i2c();
      return(0);
    }
    stop_i2c();
    delay_i2c(0X3F);
    start_i2c();
    data_trans(address,8);
    if(!receive_ack() )
    {
      stop_i2c();
      return(0);
    }
    temp = 1;
    while(1)
        {
            clock_low_flag = 1;
            receive_bit_counter = 1;
            received_data = 0;
            SDA_INPUT;
            rec_data();
            SDA_OUTPUT;
            *ram_address = received_data;
            temp++;
            if (temp > no_of_bytes)
            {
                send_ack(0);
                stop_i2c();
                return(1);
            }
            else
            {
                send_ack(1);
                ram_address++;
            }
        }
}

void rec_data (void)
{
    while (1)
    {
        if (clock_low_flag == 1)
        {
            clock_low_flag = 0;
            SCL_HIGH;
            delay_i2c(15);
            sda_status_flag = 0;
            g_ioport.p_api->pinRead(IOPORT_PORT_02_PIN_11,&SDA_STATUS);
            if (SDA_STATUS == 1)
            {
                sda_status_flag = 1;
            }
            delay_i2c(15);
        }
        else
        {
            clock_low_flag = 1;
            SCL_LOW;
            data1 = received_data;
            data1 = data1 << 1;
            if(sda_status_flag)
            {
                data1 |= 0x01;
            }
            received_data = data1;
            receive_bit_counter++;
            if(receive_bit_counter > 8)
                break;
            delay_i2c(0x0f);
        }
    }
}
