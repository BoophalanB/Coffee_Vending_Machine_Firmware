/*
 * eeprom.c
 *
 *  Created on: Jul 26, 2025
 *      Author: Dell
 */

#include "XVARIABLES.H"
#include "MACROS.H"

void write_eeprom(unsigned char mem_address,unsigned char data);
unsigned char read_eeprom(unsigned char mem_address);

void eeprom_write_int(unsigned char adress, unsigned int value);
unsigned int eeprom_read_int(unsigned char adress);

void eeprom_write_long_int(unsigned char mem_address, unsigned long int data);
unsigned long int eeprom_read_long_int(unsigned char mem_address);

extern unsigned char write_i2c(unsigned char address, unsigned char no_of_bytes);
extern unsigned char read_i2c(unsigned char address, unsigned no_of_bytes);

void write_eeprom(unsigned char mem_address,unsigned char data)
{
    for(ep=0;ep<=20;ep++)
    {
        do
        {
            mem_location = mem_address;
            tmp_value = data;
            ram_address = &tmp_value;
            eeprom_write_ok = write_i2c(0XA4,1);//0XA4
            eeprom_ten_msec_delay = 5;
            while(eeprom_ten_msec_delay);
        }
        while(!eeprom_write_ok);
        for(b=0;b<30;b++)
        {
           tmp_value = 0;
           ram_address = &tmp_value;
           mem_location = mem_address;
           eeprom_read_ok = read_i2c(0XA5,1);//0XA5
           eeprom_ten_msec_delay = 3;
           while(eeprom_ten_msec_delay);
           if(eeprom_read_ok)
               break;
        }
        if(tmp_value == data)
        {
            ep = 21;
            break;
        }
    }
}

unsigned char read_eeprom(unsigned char mem_address)
{
    for(b=0;b<30;b++)
    {
       tmp_value = 0;
       ram_address = &tmp_value;
       mem_location = mem_address;
       eeprom_read_ok = read_i2c(0XA5,1);  //0XA5
       eeprom_ten_msec_delay = 3;
       while(eeprom_ten_msec_delay);
       if(eeprom_read_ok)
           break;
    }
    return tmp_value;
}


void eeprom_write_int(unsigned char mem_address, unsigned int data)
{
    unsigned int temp_count;

    temp_count = data;
    write_eeprom(mem_address,temp_count);
    temp_count = data>>8;
    mem_address++;
    write_eeprom(mem_address,temp_count);
    eeprom_ten_msec_delay = 3;
    while(eeprom_ten_msec_delay);
}

unsigned int eeprom_read_int(unsigned char mem_address)
{
    unsigned int temp_char;
    unsigned int temp_int;

    temp_char=read_eeprom(mem_address);
    mem_address++;
    temp_int=read_eeprom(mem_address);
    temp_int <<=8;
    temp_int |= temp_char;
    eeprom_ten_msec_delay = 3;
    while(eeprom_ten_msec_delay);

    return(temp_int);
}

void eeprom_write_long_int(unsigned char mem_address, unsigned long int data)
{
    unsigned char temp_count;

    temp_count = data >> 24;
    write_eeprom(mem_address,temp_count);
    mem_address ++;
    temp_count = data >> 16;
    write_eeprom(mem_address,temp_count);
    temp_count = data >> 8;
    mem_address ++;
    write_eeprom(mem_address,temp_count);
    temp_count = data;
    mem_address ++;
    write_eeprom(mem_address,temp_count);
}

unsigned long int eeprom_read_long_int(unsigned char mem_address)
{
    unsigned long int temp_long_int1, temp_long_int2, temp_long_int3, temp_long_int4;

       temp_long_int1 = read_eeprom(mem_address);
       temp_long_int1 <<= 24;
       temp_long_int2 = read_eeprom(mem_address + 1);
       temp_long_int2 <<= 16;
       temp_long_int3 = read_eeprom(mem_address + 2);
       temp_long_int3 <<= 8;
       temp_long_int4 = read_eeprom(mem_address + 3);
       return (temp_long_int1 | temp_long_int2 | temp_long_int3 | temp_long_int4);
}
