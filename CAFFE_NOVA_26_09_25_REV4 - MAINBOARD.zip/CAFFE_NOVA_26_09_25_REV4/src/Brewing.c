/*
 * Brewing.c
 *
 *  Created on: Aug 2, 2025
 *      Author: Dell
 */

#include "XVARIABLES.H"
#include "MACROS.H"

void brewing();
void brewing_process();

void brewing()
{
    switch(brew)
    {
        case 1:
            if(tea_dec_flag)
            {
                if(tea_dec_ltr == 0x0f)
                    tea_dec_on_time=(tea_dec_1ltr_tm*2);
                else
                    tea_dec_on_time=(tea_dec_3ltr_tm*2);
                brew=0;
                tea_dec_flag=0;
                tea_flag =1;
                tea_complete_flag =1;
            }
            break;
        case 2:
            if(coff_dec_flag)
            {
                if(coffee_dec_ltr == 0x0f)
                    coff_dec_on_time=(coff_dec_1ltr_tm*2);
                else
                    coff_dec_on_time=(coff_dec_3ltr_tm*2);
                brew=0;
                coff_dec_flag=0;
                coff_flag =1;
                coff_complete_flag =1;
            }
            break;
    }
}

void brewing_process()
{
      if(tea_complete_flag)
      {
          if(tea_flag)
            {
                TEA_BREW_ON;
                tea_flag=0;
            }
            else if((!tea_flag)&&(!tea_dec_on_time))
            {
                TEA_BREW_OFF;
                tea_complete_flag=brew_flag=0;
                transmit_uart_data[T_BREW] = T_BREW;
            }
      }
      if(coff_complete_flag)
        {
            if(coff_flag)
              {
                  COF_BREW_ON;
                  coff_flag=0;
              }
              else if((!coff_flag)&&(!coff_dec_on_time))
              {
                  COF_BREW_OFF;
                  coff_complete_flag=brew_flag=0;
                  transmit_uart_data[C_BREW] = C_BREW;
              }
        }
}
