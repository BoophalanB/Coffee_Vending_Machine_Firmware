/*
 * Heating.c
 *
 *  Created on: Jul 30, 2025
 *      Author: Dell
 */

#include "XVARIABLES.H"
#include "MACROS.H"


void heating();
extern void send_data_fun();

void heating()
{
    if(!init_steam_flag1)
    {
        static unsigned int prev_state;

        if((inital_heating_flag)&&(!boiler_drain)&&(!refill_err_flag)&&(water_level_min < 2500))
        {
          PS;
            curr_state = DOOR_SWITCH;
            if(curr_state != prev_state)
            {
               prev_state = curr_state;
               stable_ctr = 0;
            }
            else
            {
                stable_flag=1;
            }
            if(stable_ctr>=3)
            {
                if(curr_state==1)
                {
                    one_min_ctr1=0;
                    HEATER_OFF;
                    heating_done_flag=1;
                    if(one_time_h_done_flag)
                    {
                        one_time_steam_flag=0;
                        one_min_ctr4=0;
                        steam_flush_flag=0;
                        one_time_h_done_flag=0;
                        transmit_uart_data[HEATING_DONE] = HEATING_DONE;
                        send_data_fun();
                        transmit_uart_data[MACHINE_READY] = MACHINE_READY;
                        send_data_fun();
                    }
                }
                else if(curr_state==0)
                {
                    HEATER_ON;
                    if((one_time_steam_flag)&&(steam_flush_flag))
                    {
                        if((!on_delay)&&(!complete_flag))
                           {
                               STEAM_ON;
                               on_delay=100;// 5 sec
                               complete_flag=1;
                           }
                        else if((!on_delay)&&(complete_flag==1))
                           {
                               STEAM_OFF;
                               steam_flush_flag=0;
                               one_min_ctr4=0;
                               one_time_steam_flag=0;
                               complete_flag=0;
                           }
                    }
                    heating_done_flag=0;
                }
            }
        }
        else if((refill_err_flag)||((water_level_min > 3000)&&(water_level_max > 3000)))
        {
            one_min_ctr1=0;
            HEATER_OFF;
        }
    }
}
