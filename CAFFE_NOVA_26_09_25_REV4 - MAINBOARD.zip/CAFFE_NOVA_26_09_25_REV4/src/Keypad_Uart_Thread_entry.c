#include "Keypad_Uart_Thread.h"
#include "XVARIABLES.H"
#include "MACROS.H"
#include "stdlib.h"
#include "stdio.h"
#include "string.h"




char *data[]={
 "HANDSHAKE",
 "ACK",
 "MAIN_BOARD_VERSION1.0",
 "DEFAULT_VALUES",
 "DONE",
 "REFILLING",
 "REFILLING DONE",
 "HEATING",
 "HEATING DONE",
 "MACHINE READY",
 "COMPLETED",
 "C01",
 "C02",
 "C03",
 "C04",
 "C05",
 "C06",
 "C07",
 "C08",
 "STOP1",
 "C10",
 "C20",
 "C30",
 "HEART BEAT",
 "REFILLING ERR",
 "HEATING ERR",
 "STOP",
};




void receive_data();
void check_app_fun_id();
void app_fun_id_data_process();
void data_process();
void send_data_fun();
unsigned char check_sum(unsigned char tx_length);
unsigned char add_stuff_byte(unsigned char tx_length);
void req_sett();
void sett_conv(unsigned char , unsigned int );
void string_convert();
void settings();
void drinks_count_value();
extern void init_setting();
extern void refill();
extern void heating();
extern void stop_drink_dispense();
extern void brewing();
extern void brewing_process();
extern void write_eeprom(unsigned char mem_address,unsigned char data);
extern unsigned char read_eeprom(unsigned char mem_address);
extern void eeprom_write_int(unsigned char adress, unsigned int value);
extern unsigned int eeprom_read_int(unsigned char adress);
extern void eeprom_write_long_int(unsigned char mem_address, unsigned long int data);
extern unsigned long int eeprom_read_long_int(unsigned char mem_address);

/* KEYPAD_UART entry function */
void Keypad_Uart_Thread_entry(void)
{
    /* TODO: add your own code here */
    Keypad_Uart.p_api->open(Keypad_Uart.p_ctrl,Keypad_Uart.p_cfg);
    Keypad_Uart.p_api->read(Keypad_Uart.p_ctrl,uart_rec_buffer,1);
    while (1)
    {
        if(receive_flag)
         {
             receive_flag=0;
             receive_data();
         }
         app_fun_id_data_process();
         send_data_fun();
        tx_thread_sleep (1);
    }
}

void Keypad_Uart_Callback(uart_callback_args_t *p_args)
{
    switch(p_args->event)
    {
        case UART_EVENT_RX_COMPLETE:
             receive_uart_data[rx_data]=uart_rec_buffer[0];
             if(rx_data<500)
             rx_data++;
             memset(uart_rec_buffer,0,sizeof(uart_rec_buffer));
             Keypad_Uart.p_api->read(Keypad_Uart.p_ctrl,uart_rec_buffer,1);
             if(receive_uart_data[0]==0X2A)
             {
                 if(receive_uart_data[rx_data-1]==0X23)
                 {
                     length=rx_data;
                     rx_data=0;
                     receive_flag=1;
                 }
             }
             else
                rx_data=0;
            break;
        case UART_EVENT_TX_COMPLETE:
            break;
        case UART_EVENT_ERR_PARITY:
        case UART_EVENT_ERR_FRAMING:
        case UART_EVENT_BREAK_DETECT:
        case UART_EVENT_ERR_OVERFLOW:
        case UART_EVENT_ERR_RXBUF_OVERFLOW:
               rx_data=0;
               Keypad_Uart.p_api->close(Keypad_Uart.p_ctrl);
               tx_thread_sleep (2);
               Keypad_Uart.p_api->open(Keypad_Uart.p_ctrl,Keypad_Uart.p_cfg);
               Keypad_Uart.p_api->read(Keypad_Uart.p_ctrl,uart_rec_buffer,1);
            break;
        case UART_EVENT_RX_CHAR:
            break;
        case UART_EVENT_TX_DATA_EMPTY:
            break;
    }
}


void receive_data()
{
    unsigned char receive_check_sum;
    unsigned int i,j;

    //remove stuff bytes


    for(i=0,j=0;i<length;i++,j++)
    {
        if(receive_uart_data[i]==0X1C)
            backup_receive_data[j] = (~receive_uart_data[++i]);
        else if(receive_uart_data[i]==0X23)
        {
            backup_receive_data[j] = receive_uart_data[i];
            total_length=j+1;
        }
        else
            backup_receive_data[j] = receive_uart_data[i];
    }
    total_bytes=receive_uart_data[2]<<8; //left swift
    total_bytes=total_bytes|receive_uart_data[3];
    memset(receive_uart_data, 0, sizeof(receive_uart_data));
    if(total_bytes>500)
        receive_err_flag=1;

    //checksum


    if(!receive_err_flag)
    {
        for(i=2,j=0,receive_check_sum=0; i<total_length-2; i++,j++)
            receive_check_sum += (unsigned char)(j ^ backup_receive_data[i]);
        receive_check_sum += backup_receive_data[1];
        receive_check_sum = ~receive_check_sum;
        if(receive_check_sum == backup_receive_data[total_length-2])
        chk_sum_flag=0;
        else
            chk_sum_flag=1;
    }
    else
        memset(backup_receive_data, 0, sizeof(backup_receive_data));
    check_app_fun_id();

    //receive actual data


    if((!chk_sum_flag)&&(app_id_flag)&&(fun_id_flag)&&(!receive_err_flag))
    {
        if((app_id==0x06)&&(fun_id==0x01))
        {
            memset(string_data, 0, sizeof(string_data));
            for(i=6,j=0;i<total_length-2;i++,j++)
                 string_data[j] = backup_receive_data[i];
            string_convert();
        }
        else
        {
            for(i=6,j=0;i<total_length-2;i++,j++)
                uart_actual_data[j] = backup_receive_data[i];
        }
        memset(backup_receive_data, 0, sizeof(backup_receive_data));
        process_data_flag=1;
    }
}

void check_app_fun_id()
{
  unsigned char i,j,app_fun_id[20][20]={
                                    {0x01,0x01,0x02,0x03,0x04,0x05,0x06,0x07,0X08,0X09,0X0a},
                                    {0x02,0x01,0x02,0x03},
                                    {0x03,0x01,0x02,0x03,0x04},
                                    {0x04,0x01,0x02},
                                    {0x05,0x01,0x02,0x03,0x04},
                                    {0x06,0x01},
                                    {0x07,0x01},
                                    {0x08,0x01,0x02,0x03,0x04},

  };
  app_id = backup_receive_data[4];
  fun_id = backup_receive_data[5];
  if((app_id>0)&&(fun_id>0))
        {
          for(i=0;i<20;i++)
          {
              if(app_fun_id[i][0]==app_id)
              {
                  app_id_flag = 1;
                  for(j=0;j<20;j++)
                  {
                      if(app_fun_id[i][j]==fun_id)
                      {
                          fun_id_flag = 1;
                          break;
                      }
                      else
                          fun_id_flag = 0;
                  }
                  break;
              }
              else
                  app_id_flag = 0;
          }
        }
}

void app_fun_id_data_process()
{
    if(process_data_flag)
    {
        switch(app_id)
        {
            case 1:
                switch(fun_id)
                {
                    case 1:
                        if(strcmp((char *)uart_actual_data , "HANDSHAKE")==0)
                        {
                            transmit_uart_data[ACK] = ACK;
                            send_app_id = app_id;
                            send_fun_id = fun_id;
                            transmit_uart_data[M_VERSION] = M_VERSION;
                            retry_flag = 0;
                        }
                        break;
                    case 2:
                        if(strcmp((char *)uart_actual_data , "ACK")==0)
                        {
                            retry_flag = 0;
                        }
                        break;
                    case 3:
                            transmit_uart_data[ACK] = ACK;
                            send_app_id = app_id;
                            send_fun_id = fun_id;
                            retry_flag = 0;
                        break;
                    case 4:
                            init_setting();
                            if(settings_read_done_flag)
                            {
                                settings_read_done_flag =0;
                                transmit_uart_data[DONE] = DONE;
                                retry_flag = 0;
                            }
                        break;
                    case 5:
                         init_steam_flag=1;
                          //req_sett();
                        break;
                    case 6:
                        if(strcmp((char *)uart_actual_data , "ACK")==0)
                        {
                            if(settings_read_done_flag)
                            {
                                settings_read_done_flag =0;
                                transmit_uart_data[DONE] = DONE;
                                retry_flag = 0;
                            }
                        }
                        break;
                    case 7:
                        one_time_wl_done_flag=1;
                        //init_steam_flag=1;
                        refill();
                        initial_refill_flag=1;
                        retry_flag = 0;
                        break;
                    case 8:
                        one_time_h_done_flag=1;
                        heating();
                        inital_heating_flag=1;
                        one_time_steam_flag=1;
                        retry_flag = 0;
                        break;
                    case 9:
                        steam_flag=1;
                        break;
                    case 10:
                        //heart_beat_flag=1;
                        break;
                }
                break;
                case 2:
                    switch(fun_id)
                    {
                        case 1:
                                if(!boiler_drain)
                                {
                                    if(uart_actual_data[0] == 'C')
                                    {
                                        if(uart_actual_data[1] == '0')
                                        {
                                            if(uart_actual_data[2] == '1')
                                            {
                                             drink_process_id = STRONG_COFF;
                                             transmit_uart_data[S_COFF] = S_COFF;
                                             s_coff_flag=1;
                                             send_count=1;
                                            }
                                            else if(uart_actual_data[2] == '2')
                                            {
                                             drink_process_id = LIGHT_COFF;
                                             transmit_uart_data[L_COFF] = L_COFF;
                                             l_coff_flag=1;
                                             send_count=1;
                                            }
                                            else if(uart_actual_data[2] == '3')
                                            {
                                             drink_process_id = LIGHT_TEA;
                                             transmit_uart_data[L_TEA] = L_TEA;
                                             l_tea_flag=1;
                                             send_count=1;
                                            }
                                            else if(uart_actual_data[2] == '4')
                                            {
                                             drink_process_id = BLACK_TEA;
                                             transmit_uart_data[B_TEA] = B_TEA;
                                             bk_tea_flag=1;
                                             send_count=1;
                                            }
                                            else if(uart_actual_data[2] == '5')
                                            {
                                             drink_process_id = BLACK_COFF;
                                             transmit_uart_data[B_COFF] = B_COFF;
                                             bk_coff_flag=1;
                                             send_count=1;
                                            }
                                            else if(uart_actual_data[2] == '6')
                                            {
                                             drink_process_id = MILK;
                                             transmit_uart_data[MK] = MK;
                                             mk_flag=1;
                                             send_count=1;
                                            }
                                            else if(uart_actual_data[2] == '7')
                                            {
                                             if((!brew_flag)&&(refill_done_flag)&&(heating_done_flag))
                                             {
                                                 drink_process_id = HOTWATER;
                                                 transmit_uart_data[HW] = HW;
                                                 hw_flag=1;
                                                 send_count=1;
                                             }
                                             else
                                                 break;
                                            }
                                            else if(uart_actual_data[2] == '8')
                                            {
                                             if((!brew_flag)&&(refill_done_flag)&&(heating_done_flag))
                                             drink_process_id = STEAM;
                                             else
                                                 break;
                                            }
                                        }
                                    }
                                    send_app_id = 2;
                                    send_fun_id = 1;
                                }
                            break;
                        case 2:
                            if(uart_actual_data[2] == '8')
                            {
                                drink_process_id = 0;
                                STEAM_OFF;
                            }
                            else
                            {
                                stop_drink_dispense();
                                transmit_uart_data[ACK] = ACK;
                                send_app_id = 2;
                                send_fun_id = 2;
                            }
                            break;
                        case 3:
                            break;
                    }
                    break;
               case 3://BREWING
                   switch(fun_id)
                   {
                       case 1:
                           if(uart_actual_data[0] == 'C')
                               {
                                   if(uart_actual_data[1] == '1')
                                       {
                                           if(uart_actual_data[2] == '0')
                                               {
                                                brew = 1;
                                                tea_dec_flag=brew_flag=1;
                                                transmit_uart_data[ACK] = ACK;
                                                send_app_id = app_id;
                                                send_fun_id = fun_id;
                                                tea_brew_count_flag =1;
                                                send_count=1;
                                               }
                                       }
                               }
                           break;
                       case 2:
                           if(uart_actual_data[0] == 'C')
                              {
                                  if(uart_actual_data[1] == '2')
                                      {
                                          if(uart_actual_data[2] == '0')
                                              {
                                               brew = 2;
                                               coff_dec_flag =brew_flag=1;
                                               transmit_uart_data[ACK] = ACK;
                                               send_app_id = app_id;
                                               send_fun_id = fun_id;
                                               coff_brew_count_flag =1;
                                               send_count=1;
                                              }
                                      }
                              }
                           break;
                       case 3:
                           break;
                   }
                    break;
                    case 4:
                        break;
                    case 5://CLEANING && BOILER DRAINING
                        switch(fun_id)
                        {
                            case 1:
                                if(((!clean)||(clean==1))&&(!drain))
                                {
                                    if(uart_actual_data[0] == 'C')
                                      {
                                        if(uart_actual_data[1] == '5')
                                          {
                                            if(uart_actual_data[2] == '0')
                                              {
                                                if(uart_actual_data[3] == '1')
                                                  {
                                                   clean=1;
                                                   tea_clean=1;
                                                   t_clean_flag=1;
                                                   if(!next_clean)
                                                   transmit_uart_data[ACK] = ACK;
                                                   send_app_id = app_id;
                                                   send_fun_id = fun_id;
                                                  }
                                              }
                                          }
                                      }
                                }
                                break;
                            case 2:
                                if(((!clean)||(clean==2))&&(!drain))
                                {
                                    if(uart_actual_data[0] == 'C')
                                      {
                                        if(uart_actual_data[1] == '5')
                                          {
                                            if(uart_actual_data[2] == '0')
                                            {
                                                if(uart_actual_data[3] == '2')
                                                  {
                                                   clean=2;
                                                   coffee_clean=1;
                                                   c_clean_flag=1;
                                                   if(!next_clean)
                                                   transmit_uart_data[ACK] = ACK;
                                                   send_app_id = app_id;
                                                   send_fun_id = fun_id;
                                                  }
                                            }
                                          }
                                      }
                                }
                                break;
                            case 3:
                                if(((!clean)||(clean==3))&&(!drain))
                                {
                                    if(uart_actual_data[0] == 'C')
                                      {
                                        if(uart_actual_data[1] == '5')
                                          {
                                            if(uart_actual_data[2] == '0')
                                              {
                                                if(uart_actual_data[3] == '3')
                                                  {
                                                   clean=3;
                                                   milk_clean=1;
                                                   m_clean_flag=1;
                                                   if(!next_clean)
                                                   transmit_uart_data[ACK] = ACK;
                                                   send_app_id = app_id;
                                                   send_fun_id = fun_id;
                                                  }
                                              }
                                          }
                                      }
                                }
                                break;
                            case 4:
                            if(!clean)
                            {
                                if(uart_actual_data[0] == 'C')
                                  {
                                    if(uart_actual_data[1] == '5')
                                      {
                                        if(uart_actual_data[2] == '0')
                                          {
                                            if(uart_actual_data[3] == '4')
                                              {
                                               drain=1;
                                               boiler_drain=1;
                                               drain_flag=1;
                                               if(!next_bclean)
                                               transmit_uart_data[ACK] = ACK;
                                               send_app_id = app_id;
                                               send_fun_id = fun_id;
                                              }
                                          }
                                      }
                                  }
                            }
                                break;
                        }
                        break;
                        case 8://COUNT RESET
                            switch(fun_id)
                            {
                                case 1://DAILY COUNT RESET
                                    setting1[EEPROM_ST_COFF_DLY_COUNT] = setting1[EEPROM_LT_COFF_DLY_COUNT] =setting1[EEPROM_LT_TEA_DLY_COUNT]=setting1[EEPROM_BK_TEA_DLY_COUNT]=setting1[EEPROM_BK_COFF_DLY_COUNT]=setting1[EEPROM_MILK_DLY_COUNT]=setting1[EEPROM_HW_DLY_COUNT]=0;
                                    eeprom_write_long_int(EEPROM_ST_COFF_DLY_COUNT,setting1[EEPROM_ST_COFF_DLY_COUNT]);
                                    eeprom_write_long_int(EEPROM_LT_COFF_DLY_COUNT,setting1[EEPROM_LT_COFF_DLY_COUNT]);
                                    eeprom_write_long_int(EEPROM_LT_TEA_DLY_COUNT,setting1[EEPROM_LT_TEA_DLY_COUNT]);
                                    eeprom_write_long_int(EEPROM_BK_TEA_DLY_COUNT,setting1[EEPROM_BK_TEA_DLY_COUNT]);
                                    eeprom_write_long_int(EEPROM_BK_COFF_DLY_COUNT,setting1[EEPROM_BK_COFF_DLY_COUNT]);
                                    eeprom_write_long_int(EEPROM_MILK_DLY_COUNT,setting1[EEPROM_MILK_DLY_COUNT]);
                                    eeprom_write_long_int(EEPROM_HW_DLY_COUNT,setting1[EEPROM_HW_DLY_COUNT]);
                                    st_coff_dly_count = eeprom_read_long_int(EEPROM_ST_COFF_DLY_COUNT);
                                    lt_coff_dly_count = eeprom_read_long_int(EEPROM_LT_COFF_DLY_COUNT);
                                    lt_tea_dly_count  = eeprom_read_long_int(EEPROM_LT_TEA_DLY_COUNT);
                                    bk_tea_dly_count  = eeprom_read_long_int(EEPROM_BK_TEA_DLY_COUNT);
                                    bk_coff_dly_count = eeprom_read_long_int(EEPROM_BK_COFF_DLY_COUNT);
                                    milk_dly_count    = eeprom_read_long_int(EEPROM_MILK_DLY_COUNT);
                                    hw_dly_count      = eeprom_read_long_int(EEPROM_HW_DLY_COUNT);
                                    transmit_uart_data[ACK] = ACK;
                                    send_app_id = app_id;
                                    send_fun_id = fun_id;
                                    reset_dly_cnt_flag=1;
                                    send_count=1;
                                    break;
                                case 2://TOTAL COUNT RESET
                                    setting1[EEPROM_ST_COFF_COUNT] = setting1[EEPROM_LT_COFF_COUNT] =setting1[EEPROM_LT_TEA_COUNT]=setting1[EEPROM_BK_TEA_COUNT]=setting1[EEPROM_BK_COFF_COUNT]=setting1[EEPROM_MILK_COUNT]=setting1[EEPROM_HW_COUNT]=0;
                                    eeprom_write_long_int(EEPROM_ST_COFF_COUNT,setting1[EEPROM_ST_COFF_COUNT]);
                                    eeprom_write_long_int(EEPROM_LT_COFF_COUNT,setting1[EEPROM_LT_COFF_COUNT]);
                                    eeprom_write_long_int(EEPROM_LT_TEA_COUNT,setting1[EEPROM_LT_TEA_COUNT]);
                                    eeprom_write_long_int(EEPROM_BK_TEA_COUNT,setting1[EEPROM_BK_TEA_COUNT]);
                                    eeprom_write_long_int(EEPROM_BK_COFF_COUNT,setting1[EEPROM_BK_COFF_COUNT]);
                                    eeprom_write_long_int(EEPROM_MILK_COUNT,setting1[EEPROM_MILK_COUNT]);
                                    eeprom_write_long_int(EEPROM_HW_COUNT,setting1[EEPROM_HW_COUNT]);
                                    st_coff_count = eeprom_read_long_int(EEPROM_ST_COFF_COUNT);
                                    lt_coff_count = eeprom_read_long_int(EEPROM_LT_COFF_COUNT);
                                    lt_tea_count  = eeprom_read_long_int(EEPROM_LT_TEA_COUNT);
                                    bk_tea_count  = eeprom_read_long_int(EEPROM_BK_TEA_COUNT);
                                    bk_coff_count = eeprom_read_long_int(EEPROM_BK_COFF_COUNT);
                                    milk_count    = eeprom_read_long_int(EEPROM_MILK_COUNT);
                                    hw_count      = eeprom_read_long_int(EEPROM_HW_COUNT);
                                    transmit_uart_data[ACK] = ACK;
                                    send_app_id = app_id;
                                    send_fun_id = fun_id;
                                    reset_total_cnt_flag=1;
                                    send_count=1;
                                    break;
                                case 3://BREW COUNT RESET
                                    setting1[EEPROM_TEA_BREW_COUNT]=setting1[EEPROM_COFF_BREW_COUNT]=0;
                                    eeprom_write_long_int(EEPROM_TEA_BREW_COUNT,setting1[EEPROM_TEA_BREW_COUNT]);
                                    eeprom_write_long_int(EEPROM_COFF_BREW_COUNT,setting1[EEPROM_COFF_BREW_COUNT]);
                                    tea_brew_count = eeprom_read_long_int(EEPROM_TEA_BREW_COUNT);
                                    coff_brew_count= eeprom_read_long_int(EEPROM_COFF_BREW_COUNT);
                                    transmit_uart_data[ACK] = ACK;
                                    send_app_id = app_id;
                                    send_fun_id = fun_id;
                                    reset_brew_cnt_flag=1;
                                    send_count=1;
                                    break;

                                case 4:
                                    count_value_flag=1;
                                    send_count=1;
                                    break;
                            }
                        break;
        }
        memset(uart_actual_data, 0, sizeof(uart_actual_data));
        process_data_flag = 0;
    }
}

void data_process()
{
    if(!retry_flag)
    {
        if(transmit_uart_data[ACK] == ACK)//ACK
        {
            send_data_flag = 1;
            send_data = ACK;
            //ack_flag=1;
        }
        else if(transmit_uart_data[M_VERSION] == M_VERSION)//MAIN BOARD VERSION
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 2;
            send_data = M_VERSION;
        }
        else if(transmit_uart_data[DEFAULT_VALUES] == DEFAULT_VALUES)//DEFAULT VALUE
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 6;
            send_data = DEFAULT_VALUES;
        }
        else if(transmit_uart_data[DONE] == DONE)//INIT DONE
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 4;
            send_data = DONE;
        }
        else if(transmit_uart_data[REFILLING] == REFILLING)
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 7;
            send_data = REFILLING;
        }
        else if(transmit_uart_data[REFILLING_DONE] == REFILLING_DONE)
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 7;
            send_data = REFILLING_DONE;

        }
        else if(transmit_uart_data[HEATING_DONE] == HEATING_DONE)
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 8;
            send_data = HEATING_DONE;

        }
        else if(transmit_uart_data[MACHINE_READY] == MACHINE_READY)
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 9;
            send_data = MACHINE_READY;
            machine_ready_flag=1;
        }
        else if(transmit_uart_data[COMPLETED] ==  COMPLETED)
        {
            send_data_flag = 1;
            send_app_id = 2;
            send_fun_id = 3;
            send_data = COMPLETED;
        }
        else if(transmit_uart_data[S_COFF] ==  S_COFF)
        {
            send_data_flag = 1;
            send_data = S_COFF;
        }
        else if(transmit_uart_data[L_COFF] ==  L_COFF)
        {
            send_data_flag = 1;
            send_data = L_COFF;
        }
        else if(transmit_uart_data[L_TEA] ==  L_TEA)
        {
            send_data_flag = 1;
            send_data = L_TEA;
        }
        else if(transmit_uart_data[B_TEA] ==  B_TEA)
        {
            send_data_flag = 1;
            send_data = B_TEA;
        }
        else if(transmit_uart_data[B_COFF] ==  B_COFF)
        {
            send_data_flag = 1;
            send_data = B_COFF;
        }
        else if(transmit_uart_data[MK] ==  MK)
        {
            send_data_flag = 1;
            send_data = MK;
        }
        else if(transmit_uart_data[HW] ==  HW)
        {
            send_data_flag = 1;
            send_data = HW;
        }
        else if(transmit_uart_data[SM] ==  SM)
        {
            send_data_flag = 1;
            send_data = SM;
        }
        else if(transmit_uart_data[T_BREW] == T_BREW)
        {
            send_data_flag = 1;
            send_app_id = 3;
            send_fun_id = 4;
            send_data = T_BREW;
        }
        else if(transmit_uart_data[C_BREW] == C_BREW)
        {
            send_data_flag = 1;
            send_app_id = 3;
            send_fun_id = 4;
            send_data = C_BREW;
        }
        else if(transmit_uart_data[T_C_BREW] == T_C_BREW)
        {
            send_data_flag = 1;
            send_app_id = 3;
            send_fun_id = 4;
            send_data = T_C_BREW;
        }
        else if(transmit_uart_data[HEART_BEAT] == HEART_BEAT)
        {
            send_data_flag = 1;
            send_app_id = 1;
            send_fun_id = 10;
            send_data = HEART_BEAT;
        }
        else if(transmit_uart_data[REFILLING_ERR] == REFILLING_ERR)
        {
            send_data_flag = 1;
            send_app_id = 4;
            send_fun_id = 1;
            send_data = REFILLING_ERR;
        }
        else if(transmit_uart_data[HEATING_ERR] == HEATING_ERR)
        {
            send_data_flag = 1;
            send_app_id = 4;
            send_fun_id = 2;
            send_data = HEATING_ERR;
        }
        else if(transmit_uart_data[STOP] == STOP)
        {
            send_data_flag = 1;
            send_data = STOP;
        }
        else if(transmit_uart_data[STOP1] == STOP1)
        {
            send_data_flag = 1;
            send_data = STOP1;
        }
        transmit_uart_data[send_data] = 0;
    }
}

void send_data_fun()
{
    unsigned char chk_sum = 0;
    unsigned int tx_len, tx_length=0;

    data_process();

    if(((send_data_flag)||(retry_flag))&&(transmit_delay<=0))
    {
        if(!retry_flag)
        {
            tx_data = 0;
            memset(uart_tx_buffer, 0,sizeof(uart_tx_buffer));
            uart_tx_buffer[tx_data++] = 0x2A;
            uart_tx_buffer[tx_data++] = 0x80;
            uart_tx_buffer[tx_data++] = 0;
            uart_tx_buffer[tx_data++] = strlen(data[send_data]);
            uart_tx_buffer[tx_data++] = send_app_id;
            uart_tx_buffer[tx_data++] = send_fun_id;
            strcpy(&uart_tx_buffer[tx_data],data[send_data]);
            tx_length = (tx_data+ (strlen(data[send_data])));
            chk_sum = (unsigned char)check_sum((unsigned char)tx_length);
            uart_tx_buffer[tx_length++] = chk_sum;
            memcpy(temp_tx_buff,uart_tx_buffer,sizeof(uart_tx_buffer));
            tx_len = add_stuff_byte((unsigned char)tx_length);
            uart_tx_buffer[tx_len++] = 0X23;
            memcpy(uart_tx_backup_buffer,uart_tx_buffer,sizeof(uart_tx_buffer));
            bkup_tx_len = tx_len;
            Keypad_Uart.p_api->write(Keypad_Uart.p_ctrl,uart_tx_buffer,tx_len);
            send_data_flag = 0;
          //  if(!ack_flag)
            retry_flag=1;
            //ack_flag=0;
            transmit_delay = 250;
        }
        else
        {
            Keypad_Uart.p_api->write(Keypad_Uart.p_ctrl,uart_tx_backup_buffer,bkup_tx_len);
            if(++retry_cnt>4)
            {
                retry_cnt = 0;
                retry_flag = 0;
            }
            transmit_delay = 250;
        }
    }
}

unsigned char check_sum(unsigned char tx_length)
{
    unsigned char i,j,send_check_sum;
    for(i=2,j=0,send_check_sum=0; i<tx_length; i++,j++)
       send_check_sum += (j ^ uart_tx_buffer[i]);
       send_check_sum = ~(send_check_sum + uart_tx_buffer[1]);
       return send_check_sum;
}

unsigned char add_stuff_byte(unsigned char tx_length)
{
    unsigned char i,j;
    for(i=1,j=1;j<tx_length;i++,j++)
    {
        if((temp_tx_buff[i]==0X1C)||(temp_tx_buff[i]==0X2A)||(temp_tx_buff[i]==0X23))
        {
            uart_tx_buffer[j++] = 0X1C;
            uart_tx_buffer[j] = ~temp_tx_buff[i];
            tx_length++;
        }
        else
            uart_tx_buffer[j] = temp_tx_buff[i];
    }
    return j;
}


void req_sett()
{
    unsigned char chk_sum = 0;
    unsigned int tx_len, tx_length=0;


    tx_data =0;
    memset(uart_tx_buffer, 0,sizeof(uart_tx_buffer));
    uart_tx_buffer[tx_data++] = 0x2A;       //START
    uart_tx_buffer[tx_data++] = 0x80;       //HEADER
    uart_tx_buffer[tx_data++] = 0;          //RESERVED
    uart_tx_buffer[tx_data++] = 0;          //LENGTH
    uart_tx_buffer[tx_data++] = 0x01;       //APP ID
    uart_tx_buffer[tx_data++] = 0x05;       //FUN ID

    sett_conv(1,sc_dec_on_time);
    sett_conv(2,sc_mk_on_time);
    sett_conv(3,lc_dec_on_time);
    sett_conv(4,lc_mk_on_time);
    sett_conv(5,bc_dec_on_time);
    sett_conv(6,bc_wat_on_time);
    sett_conv(7,coffee_dec_rev);
    sett_conv(8,lt_dec_on_time);
    sett_conv(9,lt_mk_on_time);
    sett_conv(10,bt_dec_on_time);
    sett_conv(11,bt_wat_on_time);
    sett_conv(12,tea_dec_rev);
    sett_conv(13,mk_on_time);
    sett_conv(14,milk_ex_time);
    sett_conv(15,milk_rev_time);
    sett_conv(16,hw_on_time);
    sett_conv(17,tea_dec_ltr);
    sett_conv(18,tea_dec_1ltr_tm);
    sett_conv(19,tea_dec_3ltr_tm);
    sett_conv(20,coffee_dec_ltr);
    sett_conv(21,coff_dec_1ltr_tm);
    sett_conv(22,coff_dec_3ltr_tm);
    sett_conv(23,htr_err_tm);
    sett_conv(24,blr_drn_tm);
    sett_conv(25,st_coff_count);
    sett_conv(26,lt_coff_count);
    sett_conv(27,lt_tea_count);
    sett_conv(28,bk_tea_count);
    sett_conv(29,bk_coff_count);
    sett_conv(30,milk_count);
    sett_conv(31,hw_count);
    sett_conv(32,st_coff_dly_count);
    sett_conv(33,lt_coff_dly_count);
    sett_conv(34,lt_tea_dly_count);
    sett_conv(35,bk_tea_dly_count);
    sett_conv(36,bk_coff_dly_count);
    sett_conv(37,milk_dly_count);
    sett_conv(38,hw_dly_count);
    sett_conv(39,all_drink_count);
    sett_conv(40,tea_brew_count);
    sett_conv(41,coff_brew_count);


    tx_length = tx_data;
    uart_tx_buffer[3] = (unsigned char)tx_length-6;
    chk_sum = (unsigned char)check_sum((unsigned char)tx_length);
    uart_tx_buffer[tx_length++] = chk_sum;
    memcpy(temp_tx_buff,uart_tx_buffer,sizeof(uart_tx_buffer));
    tx_len = add_stuff_byte((unsigned char)tx_length);
    uart_tx_buffer[tx_len++] = 0x23;
    Keypad_Uart.p_api->write(Keypad_Uart.p_ctrl,uart_tx_buffer,tx_len);
}

void drinks_count_value()
{
    if((!transmit_delay)&&(send_count))
    {
    unsigned char chk_sum = 0;
    unsigned int tx_len, tx_length=0;

        tx_data =0;
        memset(uart_tx_buffer, 0,sizeof(uart_tx_buffer));
        uart_tx_buffer[tx_data++] = 0x2A;       //START
        uart_tx_buffer[tx_data++] = 0x80;       //HEADER
        uart_tx_buffer[tx_data++] = 0;          //RESERVED
        uart_tx_buffer[tx_data++] = 0;//LENGTH
        uart_tx_buffer[tx_data++] = 0x07;       //APP ID
        uart_tx_buffer[tx_data++] = 0x01;       //FUN ID

        if(s_coff_flag)
        {
            if(st_coff_dly_count>=99999)
                st_coff_dly_count=0;
            if(st_coff_count>=999999)
                st_coff_count=0;
            setting1[EEPROM_ST_COFF_DLY_COUNT] = ++st_coff_dly_count;
            setting1[EEPROM_ST_COFF_COUNT] = ++st_coff_count;
            eeprom_write_long_int(EEPROM_ST_COFF_DLY_COUNT,setting1[EEPROM_ST_COFF_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_ST_COFF_COUNT,setting1[EEPROM_ST_COFF_COUNT]);
            st_coff_dly_count= eeprom_read_long_int(EEPROM_ST_COFF_DLY_COUNT);
            st_coff_count= eeprom_read_long_int(EEPROM_ST_COFF_COUNT);
            sett_conv(25,st_coff_count);
            sett_conv(32,st_coff_dly_count);
            s_coff_flag=0;
        }
        if(l_coff_flag)
        {
            if(lt_coff_dly_count>=99999)
                lt_coff_dly_count=0;
            if(lt_coff_count>=999999)
                lt_coff_count=0;
            setting1[EEPROM_LT_COFF_DLY_COUNT]= ++lt_coff_dly_count;
            setting1[EEPROM_LT_COFF_COUNT]= ++lt_coff_count;
            eeprom_write_long_int(EEPROM_LT_COFF_DLY_COUNT,setting1[EEPROM_LT_COFF_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_LT_COFF_COUNT,setting1[EEPROM_LT_COFF_COUNT]);
            lt_coff_dly_count= eeprom_read_long_int(EEPROM_LT_COFF_DLY_COUNT);
            lt_coff_count= eeprom_read_long_int(EEPROM_LT_COFF_COUNT);
            sett_conv(26,lt_coff_count);
            sett_conv(33,lt_coff_dly_count);
            l_coff_flag=0;
        }
        if(l_tea_flag)
        {
            if(lt_tea_dly_count>=99999)
                lt_tea_dly_count=0;
            if(lt_tea_count>=999999)
                lt_tea_count=0;
            setting1[EEPROM_LT_TEA_DLY_COUNT]= ++lt_tea_dly_count;
            setting1[EEPROM_LT_TEA_COUNT]= ++lt_tea_count;
            eeprom_write_long_int(EEPROM_LT_TEA_DLY_COUNT,setting1[EEPROM_LT_TEA_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_LT_TEA_COUNT,setting1[EEPROM_LT_TEA_COUNT]);
            lt_tea_dly_count= eeprom_read_long_int(EEPROM_LT_TEA_DLY_COUNT);
            lt_tea_count= eeprom_read_long_int(EEPROM_LT_TEA_COUNT);
            sett_conv(27,lt_tea_count);
            sett_conv(34,lt_tea_dly_count);
            l_tea_flag=0;
        }
        if(bk_tea_flag)
        {
            if(bk_tea_dly_count>=99999)
                bk_tea_dly_count=0;
            if(bk_tea_count>=999999)
                bk_tea_count=0;
            setting1[EEPROM_BK_TEA_DLY_COUNT]= ++bk_tea_dly_count;
            setting1[EEPROM_BK_TEA_COUNT]= ++bk_tea_count;
            eeprom_write_long_int(EEPROM_BK_TEA_DLY_COUNT,setting1[EEPROM_BK_TEA_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_BK_TEA_COUNT,setting1[EEPROM_BK_TEA_COUNT]);
            bk_tea_dly_count= eeprom_read_long_int(EEPROM_BK_TEA_DLY_COUNT);
            bk_tea_count= eeprom_read_long_int(EEPROM_BK_TEA_COUNT);
            sett_conv(28,bk_tea_count);
            sett_conv(35,bk_tea_dly_count);
            bk_tea_flag=0;
        }
        if(bk_coff_flag)
        {
            if(bk_coff_dly_count>=99999)
                bk_coff_dly_count=0;
            if(bk_coff_count>=999999)
                bk_coff_count=0;
            setting1[EEPROM_BK_COFF_DLY_COUNT]= ++bk_coff_dly_count;
            setting1[EEPROM_BK_COFF_COUNT]= ++bk_coff_count;
            eeprom_write_long_int(EEPROM_BK_COFF_DLY_COUNT,setting1[EEPROM_BK_COFF_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_BK_COFF_COUNT,setting1[EEPROM_BK_COFF_COUNT]);
            bk_coff_dly_count= eeprom_read_long_int(EEPROM_BK_COFF_DLY_COUNT);
            bk_coff_count= eeprom_read_long_int(EEPROM_BK_COFF_COUNT);
            sett_conv(29,bk_coff_count);
            sett_conv(36,bk_coff_dly_count);
            bk_coff_flag=0;
        }
        if(mk_flag)
        {
            if(milk_dly_count>=99999)
                milk_dly_count=0;
            if(milk_count>=999999)
                milk_count=0;
            setting1[EEPROM_MILK_DLY_COUNT]= ++milk_dly_count;
            setting1[EEPROM_MILK_COUNT]= ++milk_count;
            eeprom_write_long_int(EEPROM_MILK_DLY_COUNT,setting1[EEPROM_MILK_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_MILK_COUNT,setting1[EEPROM_MILK_COUNT]);
            milk_dly_count= eeprom_read_long_int(EEPROM_MILK_DLY_COUNT);
            milk_count= eeprom_read_long_int(EEPROM_MILK_COUNT);
            sett_conv(30,milk_count);
            sett_conv(37,milk_dly_count);
            mk_flag=0;
        }
        if(hw_flag)
        {
            if(hw_dly_count>=99999)
                hw_dly_count=0;
            if(hw_count>=999999)
                hw_count=0;
            setting1[EEPROM_HW_DLY_COUNT]= ++hw_dly_count;
            setting1[EEPROM_HW_COUNT]= ++hw_count;
            eeprom_write_long_int(EEPROM_HW_DLY_COUNT,setting1[EEPROM_HW_DLY_COUNT]);
            eeprom_write_long_int(EEPROM_HW_COUNT,setting1[EEPROM_HW_COUNT]);
            hw_dly_count= eeprom_read_long_int(EEPROM_HW_DLY_COUNT);
            hw_count= eeprom_read_long_int(EEPROM_HW_COUNT);
            sett_conv(31,hw_count);
            sett_conv(38,hw_dly_count);
            hw_flag=0;
        }
        if(tea_brew_count_flag)
        {
            if(tea_brew_count>=999999)
                tea_brew_count=0;
            setting1[EEPROM_TEA_BREW_COUNT] = ++tea_brew_count;
            eeprom_write_long_int(EEPROM_TEA_BREW_COUNT,setting1[EEPROM_TEA_BREW_COUNT]);
            tea_brew_count = eeprom_read_long_int(EEPROM_TEA_BREW_COUNT);
            sett_conv(40,tea_brew_count);
            tea_brew_count_flag=0;
        }
        if(coff_brew_count_flag)
        {
            if(tea_brew_count>=999999)
                coff_brew_count=0;
            setting1[EEPROM_COFF_BREW_COUNT] = ++coff_brew_count;
            eeprom_write_long_int(EEPROM_COFF_BREW_COUNT,setting1[EEPROM_COFF_BREW_COUNT]);
            coff_brew_count = eeprom_read_long_int(EEPROM_COFF_BREW_COUNT);
            sett_conv(41,coff_brew_count);
            coff_brew_count_flag=0;
        }
        if(reset_brew_cnt_flag)
        {
            sett_conv(40,tea_brew_count);
            sett_conv(41,coff_brew_count);
            reset_brew_cnt_flag=0;
        }
        if(reset_dly_cnt_flag)
        {
            sett_conv(32,st_coff_dly_count);
            sett_conv(33,lt_coff_dly_count);
            sett_conv(34,lt_tea_dly_count);
            sett_conv(35,bk_tea_dly_count);
            sett_conv(36,bk_coff_dly_count);
            sett_conv(37,milk_dly_count);
            sett_conv(38,hw_dly_count);
            reset_dly_cnt_flag=0;
        }
        if(reset_total_cnt_flag)
        {
            sett_conv(25,st_coff_count);
            sett_conv(26,lt_coff_count);
            sett_conv(27,lt_tea_count);
            sett_conv(28,bk_tea_count);
            sett_conv(29,bk_coff_count);
            sett_conv(30,milk_count);
            sett_conv(31,hw_count);
            reset_dly_cnt_flag=0;
        }

        if(count_value_flag)
        {
            sett_conv(32,st_coff_dly_count);
            sett_conv(33,lt_coff_dly_count);
            sett_conv(34,lt_tea_dly_count);
            sett_conv(35,bk_tea_dly_count);
            sett_conv(36,bk_coff_dly_count);
            sett_conv(37,milk_dly_count);
            sett_conv(38,hw_dly_count);
            sett_conv(25,st_coff_count);
            sett_conv(26,lt_coff_count);
            sett_conv(27,lt_tea_count);
            sett_conv(28,bk_tea_count);
            sett_conv(29,bk_coff_count);
            sett_conv(30,milk_count);
            sett_conv(31,hw_count);
            count_value_flag=0;
        }

        if(all_drink_count>=9999999)
            all_drink_count=0;
        setting1[EEPROM_ALL_DRINK_COUNT]=st_coff_count+lt_coff_count+lt_tea_count+bk_tea_count+bk_coff_count+milk_count+hw_count;
        if(setting1[EEPROM_ALL_DRINK_COUNT]>=9999999)
            setting1[EEPROM_ALL_DRINK_COUNT]=0;
        eeprom_write_long_int(EEPROM_ALL_DRINK_COUNT,setting1[EEPROM_ALL_DRINK_COUNT]);
        all_drink_count=eeprom_read_long_int(EEPROM_ALL_DRINK_COUNT);
        sett_conv(39,all_drink_count);


        tx_length = tx_data;
        uart_tx_buffer[3] = (unsigned char)tx_length-6;
        chk_sum = (unsigned char)check_sum((unsigned char)tx_length);
        uart_tx_buffer[tx_length++] = chk_sum;
        memcpy(temp_tx_buff,uart_tx_buffer,sizeof(uart_tx_buffer));
        tx_len = add_stuff_byte((unsigned char)tx_length);
        uart_tx_buffer[tx_len++] = 0x23;
       // uart_tx_buffer[3] = (unsigned char)tx_len-6;
        Keypad_Uart.p_api->write(Keypad_Uart.p_ctrl,uart_tx_buffer,tx_len);
        send_count=0;
    }
}


void sett_conv(unsigned char ssid, unsigned int value)
{
   unsigned  char temp[20];
   unsigned int len;

    len = sprintf(temp, "%u:%u|", ssid, value);

    for (int i = 0; i < len; i++)
        uart_tx_buffer[tx_data++] = temp[i];
}



void string_convert()
{
    unsigned int i,j=0;
    for(i=0;i<strlen(string_data);i++)
    {
        if(string_data[i]==':')
        {
            ssid = atoi(string_value);
            memset(string_value,0,sizeof(string_value));
            j =0;
        }
        else if(string_data[i]=='|')
        {
            sett_value= atoi(string_value);
            memset(string_value,0,sizeof(string_value));
            j =0;
            settings();
        }
        else
        {
            string_value[j++]=string_data[i];
        }
    }
}


void settings()
{

  switch(ssid)
  {
      case 1:
          setting[EEPROM_SC_DEC_ON_TIME] = sett_value;
          write_eeprom(EEPROM_SC_DEC_ON_TIME,(unsigned char)setting[EEPROM_SC_DEC_ON_TIME]);
          sc_dec_on_time=read_eeprom(EEPROM_SC_DEC_ON_TIME);//setting[EEPROM_SC_DEC_ON_TIME];
          break;
      case 2:
          setting[EEPROM_SC_MK_ON_TIME] = sett_value;
          write_eeprom(EEPROM_SC_MK_ON_TIME,(unsigned char)setting[EEPROM_SC_MK_ON_TIME]);
          sc_mk_on_time=read_eeprom(EEPROM_SC_MK_ON_TIME);//setting[EEPROM_SC_MK_ON_TIME];
          break;
      case 3:
          setting[EEPROM_LC_DEC_ON_TIME] = sett_value;
          write_eeprom(EEPROM_LC_DEC_ON_TIME,(unsigned char)setting[EEPROM_LC_DEC_ON_TIME]);
          lc_dec_on_time=read_eeprom(EEPROM_LC_DEC_ON_TIME);//setting[EEPROM_LC_DEC_ON_TIME];
          break;
      case 4:
          setting[EEPROM_LC_MK_ON_TIME] = sett_value;
          write_eeprom(EEPROM_LC_MK_ON_TIME,(unsigned char)setting[EEPROM_LC_MK_ON_TIME]);
          lc_mk_on_time=read_eeprom(EEPROM_LC_MK_ON_TIME);//setting[EEPROM_LC_MK_ON_TIME];
          break;
      case 5:
          setting[EEPROM_BC_DEC_ON_TIME] = sett_value;
          write_eeprom(EEPROM_BC_DEC_ON_TIME,(unsigned char)setting[EEPROM_BC_DEC_ON_TIME]);
          bc_dec_on_time=read_eeprom(EEPROM_BC_DEC_ON_TIME);//setting[EEPROM_BC_DEC_ON_TIME];
          break;
      case 6:
          setting[EEPROM_BC_WAT_ON_TIME] = sett_value;
          write_eeprom(EEPROM_BC_WAT_ON_TIME,(unsigned char)setting[EEPROM_BC_WAT_ON_TIME]);
          bc_wat_on_time=read_eeprom(EEPROM_BC_WAT_ON_TIME);//setting[EEPROM_BC_WAT_ON_TIME];
          break;
      case 7:
          setting[EEPROM_COFFEE_DEC_REV] = sett_value;
          write_eeprom(EEPROM_COFFEE_DEC_REV,(unsigned char)setting[EEPROM_COFFEE_DEC_REV]);
          coffee_dec_rev=read_eeprom(EEPROM_COFFEE_DEC_REV);//setting[EEPROM_COFFEE_DEC_REV];
          break;
      case 8:
          setting[EEPROM_LT_DEC_ON_TIME] = sett_value;
          write_eeprom(EEPROM_LT_DEC_ON_TIME,(unsigned char)setting[EEPROM_LT_DEC_ON_TIME]);
          lt_dec_on_time=read_eeprom(EEPROM_LT_DEC_ON_TIME);//setting[EEPROM_LT_DEC_ON_TIME];
          break;
      case 9:
          setting[EEPROM_LT_MK_ON_TIME] = sett_value;
          write_eeprom(EEPROM_LT_MK_ON_TIME,(unsigned char)setting[EEPROM_LT_MK_ON_TIME]);
          lt_mk_on_time=read_eeprom(EEPROM_LT_MK_ON_TIME);//setting[EEPROM_LT_MK_ON_TIME];
          break;
      case 10:
          setting[EEPROM_BT_DEC_ON_TIME] = sett_value;
          write_eeprom(EEPROM_BT_DEC_ON_TIME,(unsigned char)setting[EEPROM_BT_DEC_ON_TIME]);
          bt_dec_on_time=read_eeprom(EEPROM_BT_DEC_ON_TIME);//setting[EEPROM_BT_DEC_ON_TIME];
          break;
      case 11:
          setting[EEPROM_BT_WAT_ON_TIME] = sett_value;
          write_eeprom(EEPROM_BT_WAT_ON_TIME,(unsigned char)setting[EEPROM_BT_WAT_ON_TIME]);
          bt_wat_on_time=read_eeprom(EEPROM_BT_WAT_ON_TIME);//setting[EEPROM_BT_WAT_ON_TIME];
          break;
      case 12:
          setting[EEPROM_TEA_DEC_REV] = sett_value;
          write_eeprom(EEPROM_TEA_DEC_REV,(unsigned char)setting[EEPROM_TEA_DEC_REV]);
          tea_dec_rev=read_eeprom(EEPROM_TEA_DEC_REV);//setting[EEPROM_TEA_DEC_REV];
          break;
      case 13:
          setting[EEPROM_MK_ON_TIME] = sett_value;
          write_eeprom(EEPROM_MK_ON_TIME,(unsigned char)setting[EEPROM_MK_ON_TIME]);
          mk_on_time=read_eeprom(EEPROM_MK_ON_TIME);//setting[EEPROM_MK_ON_TIME];
          break;
      case 14:
          setting[EEPROM_MK_EX_TIME] = sett_value;
          write_eeprom(EEPROM_MK_EX_TIME,(unsigned char)setting[EEPROM_MK_EX_TIME]);
          milk_ex_time=read_eeprom(EEPROM_MK_EX_TIME);//setting[EEPROM_MK_EX_TIME];
          break;
      case 15:
          setting[EEPROM_MK_REV_TIME] = sett_value;
          write_eeprom(EEPROM_MK_REV_TIME,(unsigned char)setting[EEPROM_MK_REV_TIME]);
          milk_rev_time=read_eeprom(EEPROM_MK_REV_TIME);//setting[EEPROM_MK_REV_TIME];
          break;
      case 16:
          setting[EEPROM_HW_ON_TIME] = sett_value;
          write_eeprom(EEPROM_HW_ON_TIME,(unsigned char)setting[EEPROM_HW_ON_TIME]);
          hw_on_time=read_eeprom(EEPROM_HW_ON_TIME);//setting[EEPROM_HW_ON_TIME];
          break;
      case 17:
          setting[EEPROM_TEA_DEC_LTR] = sett_value;
          write_eeprom(EEPROM_TEA_DEC_LTR,(unsigned char)setting[EEPROM_TEA_DEC_LTR]);
          tea_dec_ltr=read_eeprom(EEPROM_TEA_DEC_LTR);//setting[EEPROM_TEA_DEC_LTR];
            break;
      case 18:
          setting[EEPROM_TEA_DEC_1LTR_TM] = sett_value;
          write_eeprom(EEPROM_TEA_DEC_1LTR_TM,(unsigned char)setting[EEPROM_TEA_DEC_1LTR_TM]);
          tea_dec_1ltr_tm=read_eeprom(EEPROM_TEA_DEC_1LTR_TM);//setting[EEPROM_TEA_DEC_1LTR_TM];
          break;
      case 19:
          setting[EEPROM_TEA_DEC_3LTR_TM] = sett_value;
          write_eeprom(EEPROM_TEA_DEC_3LTR_TM,(unsigned char)setting[EEPROM_TEA_DEC_3LTR_TM]);
          tea_dec_3ltr_tm=read_eeprom(EEPROM_TEA_DEC_3LTR_TM);//setting[EEPROM_TEA_DEC_3LTR_TM];
          break;
      case 20:
          setting[EEPROM_COFFEE_DEC_LTR] = sett_value;
          write_eeprom(EEPROM_COFFEE_DEC_LTR,(unsigned char)setting[EEPROM_COFFEE_DEC_LTR]);
          coffee_dec_ltr=read_eeprom(EEPROM_COFFEE_DEC_LTR);//setting[EEPROM_COFFEE_DEC_LTR];
          break;
      case 21:
          setting[EEPROM_COFF_DEC_1LTR_TM] = sett_value;
          write_eeprom(EEPROM_COFF_DEC_1LTR_TM,(unsigned char)setting[EEPROM_COFF_DEC_1LTR_TM]);
          coff_dec_1ltr_tm=read_eeprom(EEPROM_COFF_DEC_1LTR_TM);//setting[EEPROM_COFF_DEC_1LTR_TM];
          break;
      case 22:
          setting[EEPROM_COFF_DEC_3LTR_TM] = sett_value;
          write_eeprom(EEPROM_COFF_DEC_3LTR_TM,(unsigned char)setting[EEPROM_COFF_DEC_3LTR_TM]);//22
          coff_dec_3ltr_tm=read_eeprom(EEPROM_COFF_DEC_3LTR_TM);//setting[EEPROM_COFF_DEC_3LTR_TM];
          break;
      case 23:
          setting[EEPROM_HTR_ERR_TM] = sett_value;
          eeprom_write_int(EEPROM_HTR_ERR_TM,setting[EEPROM_HTR_ERR_TM]);
          htr_err_tm=eeprom_read_int(EEPROM_HTR_ERR_TM);
          //write_eeprom(23,setting[EEPROM_HTR_ERR_TM]);
          //htr_err_tm=read_eeprom(EEPROM_HTR_ERR_TM);//setting[EEPROM_HTR_ERR_TM];
          break;
      case 24:
          setting[EEPROM_BLR_DRN_TM] = sett_value;
          write_eeprom(EEPROM_BLR_DRN_TM,(unsigned char)setting[EEPROM_BLR_DRN_TM]);
          blr_drn_tm=read_eeprom(EEPROM_BLR_DRN_TM);//setting[EEPROM_BLR_DRN_TM];
          break;
  }
}
