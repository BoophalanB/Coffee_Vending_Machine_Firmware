/*
 * Refilling.c
 *
 *  Created on: Jul 29, 2025
 *      Author: Dell
 */

#include "XVARIABLES.H"
#include "MACROS.H"

void refill();
extern void send_data_fun();

void refill()
{
    if((!refill_err_flag)&&(!boiler_drain)&&(initial_refill_flag))
    {
        if((!read_flag)&&(initial_refill_flag))
           {
               channel_flag=1;

               //***********maximum rod adc reading*****************//
               ADC_Interrupt_0.p_api->read(ADC_Interrupt_0.p_ctrl,ADC_REG_CHANNEL_2,&water_level_max);

           }
        else if((read_flag)&&(initial_refill_flag))
           {
               channel_flag=0;

               //***********minimum rod adc reading*****************//
               ADC_Interrupt_0.p_api->read(ADC_Interrupt_0.p_ctrl,ADC_REG_CHANNEL_2,&water_level_min);
           }

        //***********initial time water level process*****************//
         if(one_time_wl_done_flag)
         {
           if(((water_level_min > 2300)||(water_level_max > 2300))&&(!on_off_refill_cycle))
           {
               g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_08,&PIN_STATUS);
               if(!PIN_STATUS)
               {
                   if(refill_on_delay < 200)
                        refill_on_delay++;
                   if (refill_on_delay >= 30)
                    {
                        REFILL_ON;
                        refill_done_flag=0;
                        refill_flag=1;
                        refill_off_delay = 0;
                    }
               }
               if(refill_cycle_count>7)
               {
                   REFILL_OFF;
                   refill_err_flag=1;
                   transmit_uart_data[REFILLING_ERR] = REFILLING_ERR;
                   send_data_fun();
                   BUZZER_ON;
               }
           }
           else
           {
              refill_on_delay = 0;
           }
         }
         //***********run time water level on process*****************//
         if(!one_time_wl_done_flag)
         {
             if((((water_level_min > 3050)&&(water_level_max > 3050))||(!refill_done_flag))&&(!on_off_refill_cycle))
             {
                 g_ioport.p_api->pinRead(IOPORT_PORT_04_PIN_08,&PIN_STATUS);
                 if(!PIN_STATUS)
                 {
                     if(refill_on_delay < 200)
                         refill_on_delay++;
                     if (refill_on_delay >= 30)
                     {
                         REFILL_ON;
                         refill_done_flag=0;
                         refill_flag=1;
                         refill_off_delay = 0;
                     }
                 }
                 if(refill_cycle_count>6)
                  {
                      REFILL_OFF;
                      refill_err_flag=1;
                      transmit_uart_data[REFILLING_ERR] = REFILLING_ERR;
                      send_data_fun();
                     // BUZZER_ON;
                  }
             }
             else
             {
                refill_on_delay = 0;
             }
         }
         //*********************Refill off**********************//
         if((water_level_min < 2300)&&(water_level_max < 2300)&&(!water_flag))
         {
             if(refill_off_delay < 200)
                refill_off_delay++;
             refill_on_delay = 0;
             if(refill_off_delay >= 30)
             {
                 REFILL_OFF;
                 refill_done_flag=1;
                 refill_flag=0;
                 one_min_counter=0;
                 if(one_time_wl_done_flag)
                   {
                       one_time_wl_done_flag =0;
                       transmit_uart_data[REFILLING_DONE] = REFILLING_DONE;
                       send_data_fun();
                       init_steam_flag1=1;
                   }
             }
         }
         else
         {
             refill_off_delay = 0;
         }
    }
}

