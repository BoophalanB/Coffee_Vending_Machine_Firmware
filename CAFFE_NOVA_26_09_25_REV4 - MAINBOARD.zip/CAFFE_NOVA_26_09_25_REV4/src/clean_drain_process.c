/*
 * clean_drain_process.c
 *
 *  Created on: Aug 8, 2025
 *      Author: Dell
 */


#include "XVARIABLES.H"
#include "MACROS.H"


void cleaning();
void draining();


void cleaning()
{
    switch(clean)
    {
        case 1:
            if((tea_clean)&&(!clean_delay))
            {
                TEA_DEC_FWD;
                tea_clean =0;
                t_clean_flag=0;
                clean_delay = 60; //one min
                next_clean=1;
            }
            else if((next_clean)&&(!clean_delay))
            {
                TEA_DEC_OFF;
                next_clean =0;
                clean=0;
                transmit_uart_data[STOP] = STOP;
                send_app_id = 5;
                send_fun_id = 1;
            }
            else if((next_clean)&&(clean_delay)&&(t_clean_flag))
            {
                TEA_DEC_OFF;
                next_clean =0;
                clean_delay=0;
                tea_clean=0;
                t_clean_flag=0;
                clean=0;
                transmit_uart_data[STOP] = STOP;
                send_app_id = 5;
                send_fun_id = 1;
            }
            break;
        case 2:
            if((coffee_clean)&&(!clean_delay))
            {
                COFF_DEC_FWD;
                coffee_clean =0;
                clean_delay = 60;//one min
                next_clean=1;
                c_clean_flag=0;
            }
            else if((next_clean)&&(!clean_delay))
            {
                COFF_DEC_OFF;
                next_clean =0;
                clean=0;
                transmit_uart_data[STOP] = STOP;
                send_app_id = 5;
                send_fun_id = 2;
            }
            else if((next_clean)&&(clean_delay)&&(c_clean_flag))
            {
                COFF_DEC_OFF;
                next_clean =0;
                c_clean_flag=0;
                clean_delay=0;
                coffee_clean=0;
                clean=0;
                transmit_uart_data[STOP] = STOP;
                send_app_id = 5;
                send_fun_id = 2;
            }
            break;
        case 3:
            if((milk_clean)&&(!clean_delay))
            {
                MILK_FWD;
                milk_clean =0;
                clean_delay = 60;//one min
                rev_set_flag=milk_rev_flag=one_min_ctr2=0;
                m_clean_flag=0;
                next_clean=1;
            }
            else if((next_clean)&&(!clean_delay))
            {
                MILK_OFF;
                next_clean =0;
                clean=0;
                transmit_uart_data[STOP] = STOP;
                send_app_id = 5;
                send_fun_id = 3;
            }
            else if((next_clean)&&(clean_delay)&&(m_clean_flag))
            {
                MILK_OFF;
                next_clean =0;
                milk_clean=0;
                clean_delay=0;
                m_clean_flag=0;
                clean=0;
                transmit_uart_data[STOP] = STOP;
                send_app_id = 5;
                send_fun_id = 3;
            }
            break;
    }
}

void draining()
{
    switch(drain)
        {
            case 1:
                if((boiler_drain)&&(!bclean_delay)&&(!next_bclean))
                {
                   WATER_ON;
                   bclean_delay=(blr_drn_tm*2)*60;
                   next_bclean=1;
                   drain_flag=0;
                }
                else if((next_bclean)&&(!bclean_delay))
                {
                    WATER_OFF;
                    boiler_drain=0;
                    drain=0;
                    next_bclean=0;
                    transmit_uart_data[STOP1] = STOP1;
                    send_app_id = 5;
                    send_fun_id = 4;
                    machine_restart_flag=1;
                    //BUZZER_ON;
                }
                else if((drain_flag)&&(next_bclean)&&(bclean_delay))
                {
                    WATER_OFF;
                    boiler_drain=0;
                    drain=drain_flag=bclean_delay=0;
                    next_bclean=0;
                    transmit_uart_data[STOP] = STOP;
                    send_app_id = 5;
                    send_fun_id = 4;
                }
                break;
        }
}
