/*
 * settings.c
 *
 *  Created on: Jul 26, 2025
 *      Author: Dell
 */
#include "XVARIABLES.H"
#include "MACROS.H"

const unsigned char default_sett_value[] =
{
    //       00   01   02   03   04   05   06   07   08   09

    /*00*/  0x00,0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x50,
    /*10*/  0x50,0x50,0x50,0x50,0x50,0x50,0x50,0x0f,0x50,0x00,
    /*20*/  0x50,0x00,0x0f,0x50,0x00,0x50,0x00,0xC8,0x00,0x50,
    /*30*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*40*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*50*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*60*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*70*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*80*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*90*/  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*100*/ 0x30,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*110*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*120*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*130*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*140*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*150*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*160*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*170*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*180*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*190*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*200*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*210*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*220*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*230*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    /*240*/ 0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
};
void init_setting();
extern void send_data_fun();
extern unsigned char read_eeprom(unsigned char mem_address);
extern void write_eeprom(unsigned char mem_address,unsigned int data);
extern void eeprom_write_int(unsigned char adress, unsigned int value);
extern unsigned int eeprom_read_int(unsigned char adress);
extern void eeprom_write_long_int(unsigned char mem_address, unsigned long int data);
extern unsigned long int eeprom_read_long_int(unsigned char mem_address);

void init_setting()
{
    unsigned char i;

    for(i=0; i<=10; i++)
    {
        default_value = read_eeprom(100);
        if(default_value==0x30)
        break;
    }
    if(default_value!=0x30)
    {
        transmit_uart_data[DEFAULT_VALUES] = DEFAULT_VALUES;
        send_data_fun();
        for(i = 0; i <=100; i++)
        {
            write_eeprom(i,default_sett_value[i]);
        }
    }
    //******************DRINKS SETTINGS***************//

    //*****************COFFEE SETTINGS****************//
    sc_dec_on_time   = read_eeprom(EEPROM_SC_DEC_ON_TIME);
    sc_mk_on_time    = read_eeprom(EEPROM_SC_MK_ON_TIME);
    lc_dec_on_time   = read_eeprom(EEPROM_LC_DEC_ON_TIME);
    lc_mk_on_time    = read_eeprom(EEPROM_LC_MK_ON_TIME);
    bc_dec_on_time   = read_eeprom(EEPROM_BC_DEC_ON_TIME);
    bc_wat_on_time   = read_eeprom(EEPROM_BC_WAT_ON_TIME);
    coffee_dec_rev   = read_eeprom(EEPROM_COFFEE_DEC_REV);

    //******************TEA SETTINGS******************//
    lt_dec_on_time   = read_eeprom(EEPROM_LT_DEC_ON_TIME);
    lt_mk_on_time    = read_eeprom(EEPROM_LT_MK_ON_TIME);
    bt_dec_on_time   = read_eeprom(EEPROM_BT_DEC_ON_TIME);
    bt_wat_on_time   = read_eeprom(EEPROM_BT_WAT_ON_TIME);
    tea_dec_rev      = read_eeprom(EEPROM_TEA_DEC_REV);

    //*****************MILK SETTINGS******************//
    mk_on_time       = read_eeprom(EEPROM_MK_ON_TIME);
    milk_ex_time     = read_eeprom(EEPROM_MK_EX_TIME);
    milk_rev_time    = read_eeprom(EEPROM_MK_REV_TIME);

    //**************HOT WATER SETTINGS****************//
    hw_on_time       = read_eeprom(EEPROM_HW_ON_TIME);

    //******************BREWING SETTINGS***************//

    //*****************TEA BREW SETTINGS***************//
    tea_dec_ltr      = read_eeprom(EEPROM_TEA_DEC_LTR);
    tea_dec_1ltr_tm  = read_eeprom(EEPROM_TEA_DEC_1LTR_TM);
    tea_dec_3ltr_tm  = read_eeprom(EEPROM_TEA_DEC_3LTR_TM);

    //****************COFF BREW SETTINGS***************//
    coffee_dec_ltr   = read_eeprom(EEPROM_COFFEE_DEC_LTR);
    coff_dec_1ltr_tm = read_eeprom(EEPROM_COFF_DEC_1LTR_TM);
    coff_dec_3ltr_tm = read_eeprom(EEPROM_COFF_DEC_3LTR_TM);

    //******************OTHER SETTINGS***************//
    htr_err_tm       = eeprom_read_int(EEPROM_HTR_ERR_TM);//23
    blr_drn_tm       = read_eeprom(EEPROM_BLR_DRN_TM);

    //******************COUNT SETTINGS***************//
    st_coff_count    = eeprom_read_long_int(EEPROM_ST_COFF_COUNT);
    lt_coff_count    = eeprom_read_long_int(EEPROM_LT_COFF_COUNT);
    lt_tea_count     = eeprom_read_long_int(EEPROM_LT_TEA_COUNT);
    bk_tea_count     = eeprom_read_long_int(EEPROM_BK_TEA_COUNT);
    bk_coff_count    = eeprom_read_long_int(EEPROM_BK_COFF_COUNT);
    milk_count       = eeprom_read_long_int(EEPROM_MILK_COUNT);
    hw_count         = eeprom_read_long_int(EEPROM_HW_COUNT);

    st_coff_dly_count= eeprom_read_long_int(EEPROM_ST_COFF_DLY_COUNT);
    lt_coff_dly_count= eeprom_read_long_int(EEPROM_LT_COFF_DLY_COUNT);
    lt_tea_dly_count = eeprom_read_long_int(EEPROM_LT_TEA_DLY_COUNT);
    bk_tea_dly_count = eeprom_read_long_int(EEPROM_BK_TEA_DLY_COUNT);
    bk_coff_dly_count= eeprom_read_long_int(EEPROM_BK_COFF_DLY_COUNT);
    milk_dly_count   = eeprom_read_long_int(EEPROM_MILK_DLY_COUNT);
    hw_dly_count     = eeprom_read_long_int(EEPROM_HW_DLY_COUNT);
    all_drink_count  = eeprom_read_long_int(EEPROM_ALL_DRINK_COUNT);

    coff_brew_count  = eeprom_read_long_int(EEPROM_COFF_BREW_COUNT);
    tea_brew_count   = eeprom_read_long_int(EEPROM_TEA_BREW_COUNT);

    settings_read_done_flag =1;
}
