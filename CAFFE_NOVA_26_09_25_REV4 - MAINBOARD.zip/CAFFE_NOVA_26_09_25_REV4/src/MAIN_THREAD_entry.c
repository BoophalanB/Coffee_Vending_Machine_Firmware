#include "MAIN_THREAD.h"
#include "VARIABLES.H"
#include "MACROS.H"

#define SDA_HIGH  g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_11,IOPORT_LEVEL_HIGH)
#define SDA_LOW   g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_11,IOPORT_LEVEL_LOW)

#define SCL_HIGH  g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_10,IOPORT_LEVEL_HIGH)
#define SCL_LOW   g_ioport.p_api->pinWrite(IOPORT_PORT_02_PIN_10,IOPORT_LEVEL_LOW)

extern void req_sett();
extern void init_setting();
extern void refill();
extern void heating();
extern void drink_process();
extern void brewing();
extern void brewing_process();
extern void cleaning();
extern void draining();
extern void send_data_fun();
extern void drinks_count_value();
extern void rev_fun();
extern void steam_flush();
extern void err_fun();

/* Main Thread entry function */
void MAIN_THREAD_entry(void)
{
    /* TODO: add your own code here */
    gpt_Timer_Interrupt.p_api->open(gpt_Timer_Interrupt.p_ctrl,gpt_Timer_Interrupt.p_cfg);
    gpt_Timer_Interrupt.p_api->start(gpt_Timer_Interrupt.p_ctrl);

    ADC_Interrupt_0.p_api->open(ADC_Interrupt_0.p_ctrl,ADC_Interrupt_0.p_cfg);
    ADC_Interrupt_0.p_api->scanCfg(ADC_Interrupt_0.p_ctrl,ADC_Interrupt_0.p_channel_cfg);
    ADC_Interrupt_0.p_api->scanStart(ADC_Interrupt_0.p_ctrl);

    machine_restart_flag=0;
    refill_err_flag=0;
    heater_err_flag=0;
    while (1)
    {
        if((!machine_restart_flag)&&(!refill_err_flag)&&(!heater_err_flag))
        {
            refill();
            heating();
            brewing_process();
            brewing();
            drink_process();
            cleaning();
            draining();
            drinks_count_value();
            steam_flush();
            rev_fun();
        }
        if((refill_err_flag)||(heater_err_flag))
        {
            err_fun();
        }
        tx_thread_sleep (1);
    }
}

void TIMER_INTERRUPT (timer_callback_args_t *p_args)
{
    switch(p_args ->event )
    {
        case TIMER_EVENT_EXPIRED :

            //***************FOR REFILL ROD PWM****************//
            if(++fifty_microsec_counter>=50)// <--change as per need 200hz(50)//(400 hz(25))
            {
                fifty_microsec_counter=0;
                if(!water_level_toggle_flag)
                {
                    water_level_toggle_flag=1;
                    P_HIGH;
                }
                else if(water_level_toggle_flag)
                {
                    water_level_toggle_flag=0;
                    P_LOW;
                }
            }
            //***************FOR REFILL ROD PWM****************//

            //***************FOR READ ADC MIN MAX ROD FOR REFILL TOGGLE****************//

            if(++two_sec_counter>=10000)//<--change as per need 250 micro sec--5//250 milli sec--(5000) // 500 milli sec---10000//two sec --40000
            {
                two_sec_counter = 0;
                    if(!channel_flag)
                    {
                        read_flag=0;
                        A_CHANNEL_HIGH;//MAX
                    }
                    else if(channel_flag)
                    {
                        read_flag=1;
                        A_CHANNEL_LOW;//MIN
                    }
            }
            //***************FOR READ ADC MIN MAX ROD FOR REFILL TOGGLE****************//

            if(++one_msec_counter>=20)
            {
                one_msec_counter=0;
                if(transmit_delay>0)
                    transmit_delay--;
            }
            if(++ten_msec_counter>=200)
            {
                ten_msec_counter=0;
                if(eeprom_ten_msec_delay>0)
                    eeprom_ten_msec_delay--;
            }

            //***************FOR PROCESS****************//
            if(++fifty_msec_counter>=1000)
            {
                fifty_msec_counter=0;
                //***************FOR DRINK & STEAM PROCESS****************//
                if(on_delay>0)
                   on_delay--;
                if(on_delay1>0)
                   on_delay1--;
                //***************FOR MILK REV PROCESS****************//
                if(on_delay2>0)
                   on_delay2--;
                //***************FOR BREW****************//
                if(tea_dec_on_time>0)
                    tea_dec_on_time--;
                if(coff_dec_on_time>0)
                    coff_dec_on_time--;
                //***************FOR DRAIN****************//
                if(bclean_delay>0)
                    bclean_delay--;

                //***************FOR HEATING ERROR****************//
                if((curr_state==0)&&(inital_heating_flag))
                {
                    if((one_time_steam_flag)&&(++one_min_ctr4>=12000))//8 min--->9600//10--->12000
                    {
                        one_min_ctr4=0;
                        steam_flush_flag=1;
                    }
                    if(++one_min_ctr1>=(htr_err_tm*2)*60)
                    {
                        one_min_ctr1=0;
                        inital_heating_flag=0;
                        HEATER_OFF;
                        heater_err_flag=1;
                        transmit_uart_data[HEATING_ERR] = HEATING_ERR;
                      //  BUZZER_ON;
                        send_data_fun();
                    }
                }
                //***************FOR HEATING ERROR****************//
            }

            if(++one_sec_counter>=20000)
            {
                one_sec_counter =0;
                //***************FOR REFILL CYCLE****************//
                if(!refill_done_flag)
                {
                    if(!refill_err_flag)
                    {
                        if(refill_flag)
                        {
                            if((++one_min_counter>60)&&(!on_off_refill_cycle))
                            {
                                one_min_counter =0;
                                on_off_refill_cycle = 1;
                                REFILL_OFF;
                                refill_flag=0;
                            }
                        }
                            if(on_off_refill_cycle)
                            {
                                if(++five_sec_counter>20)
                                {
                                    five_sec_counter=0;
                                    ++refill_cycle_count;
                                    refill_flag=1;
                                    on_off_refill_cycle =0;
                                    REFILL_ON;
                                }
                            }
                    }
                }
                //***************FOR REFILL CYCLE****************//

                //***************FOR HEART BEAT****************//
                if(++one_min_ctr>=120)//4 min--240
                {
                    one_min_ctr=0;
                    transmit_uart_data[HEART_BEAT] = HEART_BEAT;
                    send_data_fun();
                }
                //***************FOR HEART BEAT****************//

                //***************FOR MILK PUMP REV****************//
                if(rev_set_flag)
                {
                    if((!drink_process_id)||(drink_process_id==4)||(drink_process_id==5)||(drink_process_id==7)||(drink_process_id==8))
                    {
                        if(++one_min_ctr2>=60)
                        {
                            one_min_ctr2=0;
                            rev_flag=0;
                            rev_set_flag=0;
                            milk_rev_flag=1;
                        }
                    }
                    else
                        one_min_ctr2=0;
                }
                //***************FOR MILK PUMP REV****************//


                //***************FOR HEATING DELAY****************//
                if(stable_flag)
                {
                    if(stable_ctr < 5)
                        stable_ctr++;
                }
                //***************FOR HEATING DELAY****************//

                //***************FOR STEAM FLUSH****************//
                if((steam_flag)&&(!st_flush_flag))
                {
                    if((!drink_process_id)&&(!drain))
                    {
                        if(++one_min_ctr3>60*5)//5 MIN
                            {
                                one_min_ctr3=0;
                                st_flush_flag=1;
                            }
                    }
                    else
                        one_min_ctr3=0;
                }
                //***************FOR STEAM FLUSH****************//

                if(clean_delay>0)
                    clean_delay--;
            }
        break;
        default:
            break;
    }
}
